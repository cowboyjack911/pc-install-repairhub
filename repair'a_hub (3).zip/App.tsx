





import React, { useState, useMemo, useEffect } from 'react';
import { User } from './types';
import { DUMMY_TICKETS, DUMMY_CUSTOMERS, DUMMY_INVENTORY_ITEMS, PRODUCTS, defaultNotificationPreferences, DUMMY_TAX_SETTINGS, DUMMY_PAYMENT_METHOD_SETTINGS, DUMMY_SUPPLIERS, DUMMY_PURCHASE_ORDERS, DUMMY_EXPENSES, DUMMY_GIFT_CARDS, DUMMY_APPOINTMENTS, DUMMY_USERS, MESSAGE_TEMPLATES } from './constants';
// FIX: Omit is a built-in type and does not need to be imported.
import { Ticket, TicketStatus, Customer, InventoryItem, Product, CartItem, NotificationPreferences, ShippingAddress, BusinessInfo, TaxSettings, PaymentMethodSettings, Supplier, PurchaseOrder, POStatus, Expense, GiftCard, Appointment, PCBuildConfiguration, AppointmentStatus, MessageTemplate } from './types';
import StaffView from './StaffView';

const App: React.FC = () => {
  const [tickets, setTickets] = useState<Ticket[]>(DUMMY_TICKETS);
  const [customers, setCustomers] = useState<Customer[]>(DUMMY_CUSTOMERS);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(DUMMY_INVENTORY_ITEMS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(DUMMY_SUPPLIERS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(DUMMY_PURCHASE_ORDERS);
  const [expenses, setExpenses] = useState<Expense[]>(DUMMY_EXPENSES);
  const [giftCards, setGiftCards] = useState<GiftCard[]>(DUMMY_GIFT_CARDS);
  const [appointments, setAppointments] = useState<Appointment[]>(DUMMY_APPOINTMENTS);
  const [messageTemplates, setMessageTemplates] = useState<MessageTemplate[]>(MESSAGE_TEMPLATES);
  const [currentUser, setCurrentUser] = useState<User>(DUMMY_USERS[0]); // Default to Admin for demo
  
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>({
    name: 'Repair\'a Hub',
    tagline: 'Fixing Your World',
    logoUrl: undefined,
  });
  const [taxSettings, setTaxSettings] = useState<TaxSettings>(DUMMY_TAX_SETTINGS);
  const [paymentMethodSettings, setPaymentMethodSettings] = useState<PaymentMethodSettings>(DUMMY_PAYMENT_METHOD_SETTINGS);

  // Simulate checking for appointment reminders periodically
  useEffect(() => {
    const reminderInterval = setInterval(() => {
        const now = new Date();
        
        appointments.forEach(appt => {
            const timeDiff = appt.start.getTime() - now.getTime();
            const hoursDiff = timeDiff / (1000 * 60 * 60);

            // Check for appointments in the next 24 hours. In a real app, you'd track if a reminder has already been sent.
            if (hoursDiff > 0 && hoursDiff <= 24 && appt.status === AppointmentStatus.SCHEDULED) {
                console.log(`[SIMULATED REMINDER] Sending reminder to ${appt.customer.name} for their appointment at ${appt.start.toLocaleString()}`);
            }
        });
    }, 60000); // Check every minute

    return () => clearInterval(reminderInterval);
  }, [appointments]);


  // === HANDLERS FOR StaffView ===
  const handleUpdateBusinessInfo = (newInfo: BusinessInfo) => setBusinessInfo(newInfo);
  const handleUpdateTaxSettings = (newSettings: TaxSettings) => setTaxSettings(newSettings);
  const handleUpdatePaymentMethodSettings = (newSettings: PaymentMethodSettings) => setPaymentMethodSettings(newSettings);
  
  const handleLogout = async () => alert("User switching is handled in the main App component for this demo.");

  const handleAddNewCustomer = (customerData: Omit<Customer, 'id'>): Customer => {
    const newCustomer: Customer = {
      ...customerData,
      id: `cust_${crypto.randomUUID()}`,
      notificationPreferences: defaultNotificationPreferences,
    };
    setCustomers(prev => [...prev, newCustomer]);
    return newCustomer;
  };
  
  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setCustomers(prev => prev.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
  };
  
  const handleDeleteCustomer = (customerId: string) => {
    if (window.confirm('Are you sure you want to delete this customer? This action cannot be undone.')) {
        setCustomers(prev => prev.filter(c => c.id !== customerId));
    }
  };

  const handleAddSupplier = (supplierData: Omit<Supplier, 'id'>) => {
    const newSupplier: Supplier = { ...supplierData, id: `sup_${crypto.randomUUID()}`};
    setSuppliers(prev => [newSupplier, ...prev]);
  };
  
  const handleUpdateSupplier = (updatedSupplier: Supplier) => {
    setSuppliers(prev => prev.map(s => s.id === updatedSupplier.id ? updatedSupplier : s));
  };
  
  const handleDeleteSupplier = (supplierId: string) => {
    if (window.confirm('Are you sure you want to delete this supplier?')) {
        setSuppliers(prev => prev.filter(s => s.id !== supplierId));
    }
  };
  
  const handleAddPurchaseOrder = (poData: Omit<PurchaseOrder, 'id'>) => {
    const newPO: PurchaseOrder = { ...poData, id: `po_${crypto.randomUUID()}`};
    setPurchaseOrders(prev => [newPO, ...prev].sort((a,b) => b.createdAt.getTime() - a.createdAt.getTime()));
  };

  const handleReceivePOItems = (poId: string, receivedQuantities: Record<string, number>) => {
    setPurchaseOrders(prevPOs => prevPOs.map(po => {
      if (po.id === poId) {
        let allItemsReceived = true;
        const updatedItems = po.items.map(item => {
          const received = receivedQuantities[item.itemId] || 0;
          const newTotalReceived = item.quantityReceived + received;
          if (newTotalReceived < item.quantityOrdered) {
            allItemsReceived = false;
          }
          return { ...item, quantityReceived: newTotalReceived };
        });
        
        // Update inventory
        setInventoryItems(prevInv => {
            let newInv = [...prevInv];
            Object.entries(receivedQuantities).forEach(([itemId, quantity]) => {
                newInv = newInv.map(invItem => invItem.id === itemId ? { ...invItem, quantity: invItem.quantity + quantity, lastReceivedDate: new Date() } : invItem);
            });
            return newInv;
        });

        const newStatus = allItemsReceived ? POStatus.RECEIVED : POStatus.PARTIALLY_RECEIVED;
        return { ...po, items: updatedItems, status: newStatus };
      }
      return po;
    }));
  };

  const handleAddExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = { ...expenseData, id: `exp_${crypto.randomUUID()}`};
    setExpenses(prev => [newExpense, ...prev].sort((a,b) => b.date.getTime() - a.date.getTime()));
  };

  const handleUpdateExpense = (updatedExpense: Expense) => {
    setExpenses(prev => prev.map(e => e.id === updatedExpense.id ? updatedExpense : e));
  };

  const handleDeleteExpense = (expenseId: string) => {
    if (window.confirm('Are you sure you want to delete this expense?')) {
        setExpenses(prev => prev.filter(e => e.id !== expenseId));
    }
  };

  const handleAddGiftCard = (value: number) => {
    const newCard: GiftCard = {
      id: `GC-${new Date().getFullYear()}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
      initialValue: value,
      balance: value,
      status: 'active',
      createdAt: new Date(),
    };
    setGiftCards(prev => [newCard, ...prev]);
  };
  
  const handleRedeemGiftCard = (code: string, amountUsed: number) => {
    setGiftCards(prev => prev.map(card => {
        if (card.id === code) {
            const newBalance = card.balance - amountUsed;
            return { ...card, balance: newBalance, status: newBalance <= 0 ? 'depleted' : 'active' };
        }
        return card;
    }));
  };
  
  const handleAdjustStock = (itemId: string, newQuantity: number, reason: string) => {
    // Here you would also log the stock adjustment reason
    console.log(`Stock for item ${itemId} adjusted to ${newQuantity}. Reason: ${reason}`);
    setInventoryItems(prev => prev.map(item => item.id === itemId ? { ...item, quantity: newQuantity } : item));
  };
  
  const handleAddAppointment = (appointmentData: Omit<Appointment, 'id'>) => {
    const newAppointment: Appointment = { ...appointmentData, id: `appt_${crypto.randomUUID()}`};
    setAppointments(prev => [newAppointment, ...prev]);
  };

  const handleUpdateAppointment = (updatedAppointment: Appointment) => {
    setAppointments(prev => prev.map(a => a.id === updatedAppointment.id ? updatedAppointment : a));
  };

  const handleDeleteAppointment = (appointmentId: string) => {
    if (window.confirm('Are you sure you want to delete this appointment?')) {
        setAppointments(prev => prev.filter(a => a.id !== appointmentId));
    }
  };

  const handleAddMessageTemplate = (templateData: Omit<MessageTemplate, 'id'>) => {
    const newTemplate: MessageTemplate = { ...templateData, id: `tpl_${crypto.randomUUID()}` };
    setMessageTemplates(prev => [newTemplate, ...prev]);
  };
  
  const handleUpdateMessageTemplate = (updatedTemplate: MessageTemplate) => {
      setMessageTemplates(prev => prev.map(t => t.id === updatedTemplate.id ? updatedTemplate : t));
  };
  
  const handleDeleteMessageTemplate = (templateId: string) => {
      if (window.confirm('Are you sure you want to delete this message template?')) {
          setMessageTemplates(prev => prev.filter(t => t.id !== templateId));
      }
  };

  return (
      <>
      {/* Demo UI for switching users */}
      <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 bg-yellow-300 text-black px-3 py-1 rounded-full text-xs shadow-lg">
          <label htmlFor="user-switcher" className="font-bold mr-2">DEMO: Switch User Role</label>
          <select id="user-switcher" value={currentUser.uid} onChange={e => setCurrentUser(DUMMY_USERS.find(u => u.uid === e.target.value) || DUMMY_USERS[0])} className="bg-transparent font-semibold border-0 focus:ring-0">
              {DUMMY_USERS.map(user => (
                  <option key={user.uid} value={user.uid}>{user.displayName} ({user.role})</option>
              ))}
          </select>
      </div>
      <StaffView
        user={currentUser}
        users={DUMMY_USERS}
        onLogout={handleLogout}
        businessInfo={businessInfo}
        onUpdateBusinessInfo={handleUpdateBusinessInfo}
        tickets={tickets}
        customers={customers}
        inventoryItems={inventoryItems}
        setTickets={setTickets}
        setCustomers={setCustomers}
        setInventoryItems={setInventoryItems}
        taxSettings={taxSettings}
        onUpdateTaxSettings={handleUpdateTaxSettings}
        paymentMethodSettings={paymentMethodSettings}
        onUpdatePaymentMethodSettings={handleUpdatePaymentMethodSettings}
        onAddNewCustomer={handleAddNewCustomer}
        onUpdateCustomer={handleUpdateCustomer}
        onDeleteCustomer={handleDeleteCustomer}
        suppliers={suppliers}
        onAddSupplier={handleAddSupplier}
        onUpdateSupplier={handleUpdateSupplier}
        onDeleteSupplier={handleDeleteSupplier}
        purchaseOrders={purchaseOrders}
        onAddPurchaseOrder={handleAddPurchaseOrder}
        onReceivePOItems={handleReceivePOItems}
        expenses={expenses}
        onAddExpense={handleAddExpense}
        onUpdateExpense={handleUpdateExpense}
        onDeleteExpense={handleDeleteExpense}
        giftCards={giftCards}
        onAddGiftCard={handleAddGiftCard}
        onRedeemGiftCard={handleRedeemGiftCard}
        // FIX: Pass `handleAdjustStock` function to `onAdjustStock` prop.
        onAdjustStock={handleAdjustStock}
        appointments={appointments}
        onAddAppointment={handleAddAppointment}
        onUpdateAppointment={handleUpdateAppointment}
        onDeleteAppointment={handleDeleteAppointment}
        messageTemplates={messageTemplates}
        onAddMessageTemplate={handleAddMessageTemplate}
        onUpdateMessageTemplate={handleUpdateMessageTemplate}
        onDeleteMessageTemplate={handleDeleteMessageTemplate}
      />
      </>
    );
};

export default App;