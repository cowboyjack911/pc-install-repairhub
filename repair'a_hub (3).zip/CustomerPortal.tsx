

import React, { useState } from 'react';
import { User } from './services/firebaseService';
import { Customer, Product, Ticket, NotificationPreferences, ShippingAddress, BusinessInfo, TicketStatus, PCBuildConfiguration } from './types';
import Logo from './components/Logo';
import PortalHeader from './components/portal/PortalHeader';
import PortalTicketCard from './components/portal/PortalTicketCard';
import PlusIcon from './components/icons/PlusIcon';
import BookRepairModal from './components/portal/BookRepairModal';
import PortalSettingsModal from './components/portal/PortalSettingsModal';
import TruckIcon from './components/icons/TruckIcon';
import MailInRepairModal from './components/portal/MailInRepairModal';
import PortalStatCard from './components/portal/PortalStatCard';
import WrenchScrewdriverIcon from './components/icons/WrenchScrewdriverIcon';
import CheckBadgeIcon from './components/icons/CheckBadgeIcon';
import WalletIcon from './components/icons/WalletIcon';
import PCBuilder from './components/portal/PCBuilder';
import CustomBuildIcon from './components/icons/CustomBuildIcon';

interface CustomerPortalProps {
  businessInfo: BusinessInfo;
  customer: Customer;
  user: User;
  tickets: Ticket[];
  products: Product[];
  onLogout: () => void;
  onBookRepair: (repairData: { product: Product; deviceModel: string; issue: string }) => void;
  onUpdatePreferences: (customerId: string, preferences: NotificationPreferences) => void;
  onStartMailInRepair: (repairData: { product: Product; deviceModel: string; issue: string; shippingAddress: ShippingAddress; }) => void;
  onApproveQuote: (ticketId: string) => void;
  onDeclineQuote: (ticketId: string) => void;
  onStartPCBuild: (configuration: PCBuildConfiguration) => void;
}

const CustomerPortal: React.FC<CustomerPortalProps> = ({ 
  businessInfo, customer, user, tickets, products, onLogout, onBookRepair, 
  onUpdatePreferences, onStartMailInRepair, onApproveQuote, onDeclineQuote, onStartPCBuild 
}) => {
  const [isBookModalOpen, setIsBookModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isMailInModalOpen, setIsMailInModalOpen] = useState(false);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);

  const activeTickets = tickets.filter(t => t.status !== TicketStatus.COMPLETED && t.status !== TicketStatus.CANCELLED);
  const pastTickets = tickets.filter(t => t.status === TicketStatus.COMPLETED || t.status === TicketStatus.CANCELLED);

  const handlePCBuildSubmit = (configuration: PCBuildConfiguration) => {
    onStartPCBuild(configuration);
    setIsBuilderOpen(false);
  };


  return (
    <>
      <div className="min-h-screen bg-dark-bg text-dark-text-primary font-sans">
        <header className="bg-dark-panel shadow-md">
          <div className="max-w-screen-xl mx-auto py-3 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
            <Logo businessInfo={businessInfo} />
            <PortalHeader user={user} onLogout={onLogout} onOpenSettings={() => setIsSettingsModalOpen(true)} />
          </div>
        </header>
        <main className="max-w-screen-xl mx-auto py-8 sm:px-6 lg:px-8">
          <div className="px-4 sm:px-0">
             {/* New Welcome Header */}
            <div className="md:flex md:items-center md:justify-between">
              <div className="flex-1 min-w-0">
                <h1 className="text-2xl font-bold leading-7 text-dark-text-primary sm:text-3xl sm:truncate">
                  Welcome back, {customer.name.split(' ')[0]}!
                </h1>
                <p className="mt-1 text-sm text-dark-text-secondary">
                  Here's a summary of your account and repairs.
                </p>
              </div>
              <div className="mt-4 flex md:mt-0 md:ml-4 flex-wrap gap-4">
                 <button
                    onClick={() => setIsMailInModalOpen(true)}
                    className="flex items-center justify-center gap-2 rounded-lg bg-dark-panel-light px-5 py-3 text-dark-text-primary transition hover:bg-dark-border font-bold"
                    type="button"
                  >
                    <TruckIcon className="w-5 h-5" />
                    <span className="text-sm font-medium">Start a Mail-in Repair</span>
                  </button>
                 <button
                    onClick={() => setIsBookModalOpen(true)}
                    className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
                    type="button"
                  >
                    <PlusIcon className="w-5 h-5" />
                    <span className="text-sm font-medium">Book a New Repair</span>
                  </button>
              </div>
            </div>

             {/* New Stat Cards Section */}
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
                <PortalStatCard 
                    title="Active Repairs"
                    value={activeTickets.length.toString()}
                    icon={WrenchScrewdriverIcon}
                />
                <PortalStatCard 
                    title="Completed Repairs"
                    value={pastTickets.length.toString()}
                    icon={CheckBadgeIcon}
                />
                 <PortalStatCard 
                    title="Store Credit"
                    value={`A$${(customer.storeCredit || 0).toFixed(2)}`}
                    icon={WalletIcon}
                />
            </div>

            {/* PC Builder Card */}
            <div className="mt-10">
              <div className="bg-dark-panel rounded-lg shadow-lg overflow-hidden">
                  <div className="p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="flex-1">
                          <h2 className="text-xl font-bold text-dark-text-primary">Have a dream PC in mind?</h2>
                          <p className="mt-1 text-dark-text-secondary">Use our interactive builder to configure your perfect machine and submit it for a quote.</p>
                      </div>
                      <button
                          onClick={() => setIsBuilderOpen(true)}
                          className="flex-shrink-0 flex items-center justify-center gap-2 rounded-lg bg-brand-green px-6 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold text-base"
                          type="button"
                      >
                          <CustomBuildIcon className="w-6 h-6" />
                          <span>Build Your Custom PC</span>
                      </button>
                  </div>
              </div>
            </div>

            {/* Active Repairs Section */}
            <div className="mt-10">
                <h2 className="text-xl font-semibold text-dark-text-primary">Active Repairs</h2>
                <div className="mt-4">
                    {activeTickets.length > 0 ? (
                        <div className="space-y-4">
                            {activeTickets.map(ticket => (
                                <PortalTicketCard 
                                    key={ticket.id} 
                                    ticket={ticket} 
                                    onApprove={onApproveQuote}
                                    onDecline={onDeclineQuote}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 bg-dark-panel rounded-lg">
                            <h3 className="text-xl font-medium text-dark-text-primary">No active repairs.</h3>
                            <p className="mt-2 text-base text-dark-text-secondary">
                                All caught up! Book a new repair to get started.
                            </p>
                        </div>
                    )}
                </div>
            </div>
            
            {/* Repair History Section */}
            <div className="mt-10">
                <h2 className="text-xl font-semibold text-dark-text-primary">Repair History</h2>
                <div className="mt-4">
                    {pastTickets.length > 0 ? (
                        <div className="space-y-4">
                            {pastTickets.map(ticket => (
                                <PortalTicketCard 
                                    key={ticket.id} 
                                    ticket={ticket} 
                                    onApprove={onApproveQuote}
                                    onDecline={onDeclineQuote}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-10 bg-dark-panel rounded-lg">
                            <p className="text-base text-dark-text-secondary">
                                Your past repairs will appear here.
                            </p>
                        </div>
                    )}
                </div>
            </div>
            
          </div>
        </main>
      </div>
      <BookRepairModal 
        isOpen={isBookModalOpen}
        onClose={() => setIsBookModalOpen(false)}
        products={products}
        onBookRepair={onBookRepair}
      />
      <MailInRepairModal
        isOpen={isMailInModalOpen}
        onClose={() => setIsMailInModalOpen(false)}
        products={products}
        onStartMailIn={onStartMailInRepair}
      />
      <PortalSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        customer={customer}
        onSave={onUpdatePreferences}
      />
      <PCBuilder 
        isOpen={isBuilderOpen}
        onClose={() => setIsBuilderOpen(false)}
        onSubmit={handlePCBuildSubmit}
      />
    </>
  );
};

export default CustomerPortal;