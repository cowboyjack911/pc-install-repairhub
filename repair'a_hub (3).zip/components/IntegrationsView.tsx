import React, { useState, useMemo } from 'react';
import SearchIcon from './icons/SearchIcon';
import PhoneProIcon from './icons/PhoneProIcon';
import M360Icon from './icons/M360Icon';
import SquareIcon from './icons/SquareIcon';
import ZapierIcon from './icons/ZapierIcon';
import QuickbooksIcon from './icons/QuickbooksIcon';
import PuzzlePieceIcon from './icons/PuzzlePieceIcon';

const ALL_INTEGRATIONS = [
    {
        name: 'Integrated Phone System (Powered By 3CX)',
        description: 'With a single number for calls & 2-way text messages, get all the customer info on your RD POS system. Full call recording, mobile app, pop up notifications and a lot more.',
        icon: <PhoneProIcon className="h-8 w-8 text-green-500" />,
        status: 'Recommended',
        connected: false,
        category: 'VOIP'
    },
    {
        name: 'M360 Integration',
        description: 'Allows you to fetch diagnostic test results within RepairDesk. You can access real-time diagnostic reports within tickets (new interface) and trade-in modules.',
        icon: <M360Icon className="h-8 w-8 text-purple-500" />,
        status: 'Recommended',
        connected: false,
        category: 'Productivity'
    },
    {
        name: 'Square',
        description: 'A fully integrated in-person payment solution that allow your customers to pay with debit or credit card, chip card (EMV) using Square Terminal.',
        icon: <SquareIcon className="h-8 w-8 text-blue-600" />,
        status: null,
        connected: true,
        category: 'Payments'
    },
    {
        name: 'Zapier',
        description: 'Automate your repair shop by connecting RepairDesk with over 3,000+ apps. No coding required.',
        icon: <ZapierIcon className="h-8 w-8 text-orange-500" />,
        status: null,
        connected: false,
        category: 'Productivity'
    },
    {
        name: 'QuickBooks',
        description: 'Sync your invoices, inventory and payments through Quickbooks. Store data on cloud and sync with devices in a matter of clicks.',
        icon: <QuickbooksIcon className="h-8 w-8 text-green-600" />,
        status: null,
        connected: false,
        category: 'Accounting'
    },
     {
        name: 'Appointments Pro',
        description: 'Simplify the process for your customers to request quotes and schedule appointments.',
        icon: <PuzzlePieceIcon className="h-8 w-8 text-gray-400" />,
        status: 'Recommended',
        connected: false,
        category: 'Productivity'
    },
    {
        name: 'RepairDesk SMS',
        description: 'Send real-time job notifications, appointment reminders, enable two-way messaging, and send bulk SMS to engage customers better & improve customer satisfaction.',
        icon: <PuzzlePieceIcon className="h-8 w-8 text-gray-400" />,
        status: null,
        connected: false,
        category: 'SMS'
    },
    {
        name: 'Xero',
        description: "Xero simplifies your store's accounting by automatically sending invoices from RepairDesk to your Xero accounting system.",
        icon: <PuzzlePieceIcon className="h-8 w-8 text-blue-400" />,
        status: null,
        connected: true,
        category: 'Accounting'
    }
];

const IntegrationCard = ({ integration }: { integration: typeof ALL_INTEGRATIONS[0] }) => (
    <div className="bg-dark-panel rounded-lg shadow-lg p-6 flex flex-col justify-between transition-all duration-300 hover:shadow-brand-green/20 hover:ring-1 hover:ring-dark-border">
        <div>
            <div className="flex justify-between items-start">
                <div className="bg-white p-2 rounded-md inline-block">{integration.icon}</div>
                {integration.status && <span className="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded-full font-medium">{integration.status}</span>}
            </div>
            <h3 className="text-base font-bold text-dark-text-primary mt-4">{integration.name}</h3>
            <p className="text-sm text-dark-text-secondary mt-2 mb-4 flex-grow">{integration.description}</p>
        </div>
        <div className="border-t border-dark-border pt-4 mt-auto">
            <button className={`font-bold text-sm float-right  ${integration.connected ? 'text-dark-text-tertiary cursor-default' : 'text-brand-green hover:text-brand-green-darker'}`}>
                {integration.connected ? 'Connected' : 'Connect'}
            </button>
        </div>
    </div>
);

const IntegrationsView: React.FC = () => {
    const [activeTab, setActiveTab] = useState('Most Popular');
    const [searchTerm, setSearchTerm] = useState('');

    const filteredIntegrations = useMemo(() => {
        let integrations = ALL_INTEGRATIONS;

        if (activeTab === 'Most Popular') {
            integrations = integrations.filter(i => i.status === 'Recommended');
        } else if (activeTab !== 'All') {
            integrations = integrations.filter(i => i.category === activeTab);
        }

        if (searchTerm) {
            integrations = integrations.filter(i =>
                i.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                i.description.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        return integrations;
    }, [activeTab, searchTerm]);

    const tabs = ['Most Popular', 'All', 'Payments', 'Accounting', 'Marketing', 'Vendor', 'SMS', 'Productivity', 'VOIP'];

    return (
        <div>
            <div className="flex flex-wrap justify-end items-center gap-4">
                <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
                    </div>
                    <input
                      type="text"
                      placeholder="Search Integration"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-64 focus:ring-brand-green focus:border-brand-green"
                    />
                </div>
            </div>

            <div className="mt-4 border-b border-dark-border">
                <nav className="-mb-px flex space-x-6 overflow-x-auto">
                    {tabs.map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors
                                ${activeTab === tab 
                                    ? 'border-brand-green text-brand-green' 
                                    : 'border-transparent text-dark-text-secondary hover:text-white'
                                }
                            `}
                        >
                            {tab}
                        </button>
                    ))}
                </nav>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
                {filteredIntegrations.map(int => <IntegrationCard key={int.name} integration={int} />)}
            </div>
             {filteredIntegrations.length === 0 && (
                <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-16 bg-dark-panel rounded-lg mt-6">
                    <h3 className="text-xl font-medium text-dark-text-primary">No integrations found.</h3>
                    <p className="mt-2 text-base text-dark-text-secondary">
                      Try a different search term or filter.
                    </p>
                </div>
            )}
        </div>
    );
};

export default IntegrationsView;