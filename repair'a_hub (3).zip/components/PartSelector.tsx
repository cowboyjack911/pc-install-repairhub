import React, { useState, useMemo } from 'react';
import { InventoryItem, UsedPart } from '../types';
import SearchIcon from './icons/SearchIcon';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';

interface PartSelectorProps {
  inventory: InventoryItem[];
  selectedParts: UsedPart[];
  onPartsChange: (parts: UsedPart[]) => void;
}

const PartSelector: React.FC<PartSelectorProps> = ({ inventory, selectedParts, onPartsChange }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredInventory = useMemo(() => {
    if (!searchTerm) return [];
    // Don't show items that are already selected
    const selectedIds = new Set(selectedParts.map(p => p.itemId));
    return inventory.filter(
      item =>
        !selectedIds.has(item.id) &&
        (item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.sku.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [inventory, searchTerm, selectedParts]);

  const addPart = (item: InventoryItem) => {
    const newPart: UsedPart = {
      itemId: item.id,
      name: item.name,
      sku: item.sku,
      quantityUsed: 1,
      cost: item.cost,
    };
    onPartsChange([...selectedParts, newPart]);
  };

  const removePart = (itemId: string) => {
    onPartsChange(selectedParts.filter(p => p.itemId !== itemId));
  };
  
  const updatePartQuantity = (itemId: string, quantity: number) => {
    if (quantity < 1) return;
    onPartsChange(
      selectedParts.map(p => (p.itemId === itemId ? { ...p, quantityUsed: quantity } : p))
    );
  };


  return (
    <div>
      <h3 className="text-lg font-semibold text-dark-text-primary mb-2">Parts Used</h3>
      
      {/* Selected Parts */}
      <div className="space-y-2 mb-4">
        {selectedParts.length > 0 ? selectedParts.map(part => (
          <div key={part.itemId} className="flex items-center justify-between bg-dark-bg p-2 rounded-md">
            <div>
                <p className="text-sm font-medium text-dark-text-primary">{part.name}</p>
                <p className="text-xs text-dark-text-tertiary">SKU: {part.sku}</p>
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="number"
                value={part.quantityUsed}
                onChange={e => updatePartQuantity(part.itemId, parseInt(e.target.value, 10))}
                className="w-16 bg-dark-panel-light border-dark-border rounded-md text-center text-sm py-1"
                min="1"
              />
              <button onClick={() => removePart(part.itemId)} className="text-red-400/80 hover:text-red-400">
                <TrashIcon className="w-5 h-5"/>
              </button>
            </div>
          </div>
        )) : (
            <p className="text-sm text-dark-text-tertiary">No parts added yet.</p>
        )}
      </div>

      {/* Add Part Search */}
      <div>
        <label htmlFor="partSearch" className="block text-sm font-medium text-dark-text-secondary">Add Part</label>
        <div className="relative mt-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
          </div>
          <input
            type="text"
            id="partSearch"
            placeholder="Search by name or SKU..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="bg-dark-bg border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full focus:ring-brand-green focus:border-brand-green"
          />
        </div>
        {searchTerm && (
          <div className="mt-2 max-h-40 overflow-y-auto bg-dark-bg rounded-md border border-dark-border">
            {filteredInventory.length > 0 ? filteredInventory.map(item => (
              <div key={item.id} className="flex items-center justify-between p-2 hover:bg-dark-panel-light">
                <div>
                  <p className="text-sm font-medium text-dark-text-primary">{item.name}</p>
                  <p className="text-xs text-dark-text-secondary">SKU: {item.sku} | In Stock: {item.quantity}</p>
                </div>
                <button onClick={() => addPart(item)} className="text-brand-green hover:text-brand-green-darker">
                  <PlusIcon className="w-6 h-6"/>
                </button>
              </div>
            )) : <p className="p-2 text-sm text-dark-text-tertiary">No results found.</p>}
          </div>
        )}
      </div>
    </div>
  );
};

export default PartSelector;