import React from 'react';
import { PRODUCTS } from '../constants';
import { Product } from '../types';

interface ProductGridProps {
    onProductSelect: (product: Product) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ onProductSelect }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {PRODUCTS.map((product) => (
        <button 
            key={product.id} 
            onClick={() => onProductSelect(product)}
            className="group aspect-square bg-dark-panel-light rounded-lg flex flex-col items-center justify-center p-2 text-center hover:bg-dark-border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-brand-green"
        >
            <product.icon className="w-8 h-8 sm:w-10 sm:h-10 text-dark-text-secondary group-hover:text-white transition-colors" />
            <span className="mt-2 text-xs sm:text-sm font-medium text-dark-text-primary">{product.name}</span>
        </button>
      ))}
    </div>
  );
};

export default ProductGrid;
