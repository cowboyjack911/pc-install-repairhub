
import React, { useState, useEffect } from 'react';
import { Customer } from '../types';
import CloseIcon from './icons/CloseIcon';

interface StoreCreditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Customer, newBalance: number) => void;
  customer: Customer | null;
}

const StoreCreditModal: React.FC<StoreCreditModalProps> = ({ isOpen, onClose, onSave, customer }) => {
  const [amount, setAmount] = useState('');
  const [action, setAction] = useState<'add' | 'use'>('add');

  useEffect(() => {
    if (!isOpen) {
      setAmount('');
      setAction('add');
    }
  }, [isOpen]);

  if (!isOpen || !customer) return null;

  const currentBalance = customer.storeCredit || 0;

  const handleSave = () => {
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      alert('Please enter a valid positive amount.');
      return;
    }

    let newBalance = currentBalance;
    if (action === 'add') {
      newBalance += numericAmount;
    } else {
      if (numericAmount > currentBalance) {
        alert('Cannot use more credit than available.');
        return;
      }
      newBalance -= numericAmount;
    }
    
    onSave(customer, newBalance);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-sm">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Adjust Store Credit</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6">
          <div className="text-center mb-6">
            <p className="text-sm text-dark-text-secondary">Current Balance for {customer.name}</p>
            <p className="text-3xl font-bold text-brand-green">${currentBalance.toFixed(2)}</p>
          </div>

          <div className="flex rounded-md shadow-sm mb-4" role="group">
            <button
              type="button"
              onClick={() => setAction('add')}
              className={`px-4 py-2 w-full text-sm font-medium border rounded-l-lg transition-colors ${action === 'add' ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border hover:bg-dark-panel-light'}`}
            >
              Add Credit
            </button>
            <button
              type="button"
              onClick={() => setAction('use')}
              className={`px-4 py-2 w-full text-sm font-medium border rounded-r-lg transition-colors ${action === 'use' ? 'bg-red-500 text-white border-red-500' : 'bg-dark-bg text-white border-dark-border hover:bg-dark-panel-light'}`}
            >
              Use Credit
            </button>
          </div>

          <div>
            <label htmlFor="creditAmount" className="sr-only">Amount</label>
            <input
              type="number"
              id="creditAmount"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
              placeholder="0.00"
              step="0.01"
              min="0"
              autoFocus
            />
          </div>
        </main>
        
        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border"
            >
                Cancel
            </button>
            <button
                onClick={handleSave}
                className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
            >
                Update Balance
            </button>
        </footer>
      </div>
    </div>
  );
};

export default StoreCreditModal;
