
import React from 'react';
import { Ticket } from '../../types';

interface TicketInvoiceProps {
    ticket: Ticket;
    businessInfo: { name: string; tagline: string; };
}

const TicketInvoice: React.FC<TicketInvoiceProps> = ({ ticket, businessInfo }) => {
    return (
        <div className="bg-white text-black p-8 font-sans text-sm">
            <header className="flex justify-between items-start pb-4 border-b border-gray-300">
                <div>
                    <h1 className="text-3xl font-bold text-gray-800">{businessInfo.name}</h1>
                    <p className="text-gray-600">{businessInfo.tagline}</p>
                </div>
                <div className="text-right">
                    <h2 className="text-2xl font-semibold uppercase text-gray-700">{ticket.status === 'Completed' ? 'Receipt' : 'Invoice'}</h2>
                    <p><strong>Ticket #:</strong> {ticket.id.substring(0, 8)}</p>
                    <p><strong>Date:</strong> {new Date(ticket.createdAt).toLocaleDateString()}</p>
                </div>
            </header>
            <section className="my-6 grid grid-cols-2 gap-4">
                <div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-800">Customer Info:</h3>
                    <p>{ticket.customer.name}</p>
                    <p>{ticket.customer.phone}</p>
                    <p>{ticket.customer.email}</p>
                </div>
                {ticket.shippingAddress && (
                     <div>
                        <h3 className="text-lg font-semibold mb-2 text-gray-800">Shipping Address:</h3>
                        <p>{ticket.shippingAddress.street}</p>
                        <p>{ticket.shippingAddress.city}, {ticket.shippingAddress.state} {ticket.shippingAddress.zip}</p>
                    </div>
                )}
            </section>
            <section>
                <table className="w-full text-left">
                    <thead className="bg-gray-100 border-b-2 border-gray-300">
                        <tr>
                            <th className="p-2 font-semibold">Item/Service Description</th>
                            <th className="p-2 text-right font-semibold">Qty</th>
                            <th className="p-2 text-right font-semibold">Unit Price</th>
                            <th className="p-2 text-right font-semibold">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        {ticket.items.map(item => (
                            <tr key={item.cartItemId} className="border-b border-gray-200">
                                <td className="p-2 align-top">
                                    <p className="font-semibold">{item.name}</p>
                                    <p className="text-gray-600 text-xs">{item.issue}</p>
                                </td>
                                <td className="p-2 text-right align-top">{item.quantity}</td>
                                <td className="p-2 text-right align-top">${item.unitPrice.toFixed(2)}</td>
                                <td className="p-2 text-right align-top">${(item.quantity * item.unitPrice).toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </section>
            <section className="flex justify-end mt-6">
                <div className="w-full max-w-xs">
                    <div className="flex justify-between p-2">
                        <span className="text-gray-600">Subtotal:</span>
                        <span>${ticket.subtotal.toFixed(2)}</span>
                    </div>
                     <div className="flex justify-between p-2">
                        <span className="text-gray-600">Discount:</span>
                        <span>-${ticket.discount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between p-2">
                        <span className="text-gray-600">Tax:</span>
                        <span>${ticket.tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between p-2 mt-2 bg-gray-100 font-bold text-lg border-t-2 border-gray-300">
                        <span>Total Due:</span>
                        <span>${ticket.total.toFixed(2)}</span>
                    </div>
                </div>
            </section>
            {ticket.paymentDetails && (
                 <section className="mt-4 text-sm">
                    <h3 className="text-lg font-semibold mb-2 text-gray-800">Payment Details:</h3>
                    <p><strong>Payment Method:</strong> {ticket.paymentDetails.method}</p>
                    <p><strong>Transaction ID:</strong> {ticket.paymentDetails.transactionId}</p>
                </section>
            )}
             <footer className="mt-8 pt-4 border-t border-gray-300 text-center text-xs text-gray-500">
                <p>Thank you for your business!</p>
            </footer>
        </div>
    );
};

export default TicketInvoice;
