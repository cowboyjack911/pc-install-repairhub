
import React from 'react';
import { Ticket } from '../types';
import CloseIcon from './icons/CloseIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import PrinterIcon from './icons/PrinterIcon';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  ticket: Ticket | null;
  // FIX: Add onPrintTicket prop for printing functionality.
  onPrintTicket: (ticket: Ticket) => void;
}

const ReceiptModal: React.FC<ReceiptModalProps> = ({ isOpen, onClose, ticket, onPrintTicket }) => {
  if (!isOpen || !ticket) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-md">
        <main className="p-6">
          <div className="text-center">
             <CheckCircleIcon className="h-12 w-12 text-brand-green mx-auto" />
             <h2 className="mt-4 text-2xl font-bold text-dark-text-primary">Payment Successful</h2>
             <p className="text-sm text-dark-text-secondary mt-1">Transaction ID: {ticket.paymentDetails?.transactionId}</p>
          </div>

          <div className="my-6 border-t border-b border-dashed border-dark-border py-4">
             <h3 className="text-lg font-semibold text-center text-dark-text-primary mb-4">Sale Summary</h3>
             {/* Items */}
             <div className="space-y-2 text-sm">
                {ticket.items.map(item => (
                    <div key={item.cartItemId} className="flex justify-between items-start">
                        <span className="text-dark-text-secondary pr-2">{item.quantity}x {item.name}</span>
                        <span className="text-dark-text-primary font-medium flex-shrink-0">${(item.unitPrice * item.quantity).toFixed(2)}</span>
                    </div>
                ))}
             </div>
             {/* Totals */}
             <div className="mt-4 pt-4 border-t border-dark-border space-y-2 text-sm">
                <div className="flex justify-between text-dark-text-secondary"><span>Subtotal</span><span>${ticket.subtotal.toFixed(2)}</span></div>
                <div className="flex justify-between text-dark-text-secondary"><span>Tax</span><span>${ticket.tax.toFixed(2)}</span></div>
                <div className="flex justify-between font-bold text-lg text-dark-text-primary"><span>Total</span><span>${ticket.total.toFixed(2)}</span></div>
             </div>
             {/* Payment Details */}
             <div className="mt-4 pt-4 border-t border-dark-border space-y-2 text-sm">
                <div className="flex justify-between text-dark-text-secondary"><span>Paid via {ticket.paymentDetails?.method}</span><span>${(ticket.paymentDetails?.amountTendered || ticket.total).toFixed(2)}</span></div>
                {ticket.paymentDetails?.method === 'cash' && (
                   <div className="flex justify-between text-dark-text-secondary"><span>Change Due</span><span>${(ticket.paymentDetails.changeGiven || 0).toFixed(2)}</span></div>
                )}
             </div>
          </div>
        </main>

        <footer className="p-4 grid grid-cols-2 gap-3 bg-dark-panel-light/50 rounded-b-2xl">
            <button
                // FIX: Add onClick handler to trigger printing.
                onClick={() => onPrintTicket(ticket)}
                className="col-span-1 flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold bg-dark-panel-light text-dark-text-primary hover:bg-dark-border transition"
            >
                <PrinterIcon className="h-5 w-5" />
                <span>Print Receipt</span>
            </button>
            <button
                onClick={onClose}
                className="col-span-1 rounded-lg px-4 py-3 text-sm font-semibold bg-dark-accent-blue text-white hover:bg-blue-700 transition"
            >
                New Sale
            </button>
        </footer>
      </div>
    </div>
  );
};

export default ReceiptModal;
