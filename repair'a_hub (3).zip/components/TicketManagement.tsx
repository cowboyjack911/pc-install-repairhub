

import React from 'react';
// FIX: Import User type
import { Ticket, TicketStatus, User } from '../types';
import TicketList from './TicketList';
import PlusIcon from './icons/PlusIcon';

interface TicketManagementProps {
  tickets: Ticket[];
  onAddTicket: () => void;
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
  onAddQuote: (ticketId: string) => void;
  onAddNote: (ticketId: string, noteContent: string) => void;
  onPrintTicket: (ticket: Ticket) => void;
  onSendMessage: (ticket: Ticket) => void;
  // FIX: Add props for technician assignment
  user: User;
  technicians: User[];
  onAssignTechnician: (ticketId: string, technicianId: string) => void;
}

const TicketManagement: React.FC<TicketManagementProps> = ({ tickets, onAddTicket, onUpdateStatus, onAddQuote, onAddNote, onPrintTicket, onSendMessage, user, technicians, onAssignTechnician }) => {
  return (
    <>
      <div className="sm:flex sm:items-center sm:justify-between">
        <div>
          {/* Title is handled by StaffHeader */}
        </div>
        
        <button
          onClick={onAddTicket}
          className="mt-4 sm:mt-0 flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-bg focus:ring-brand-green font-bold"
          type="button"
        >
          <PlusIcon className="w-5 h-5" />
          <span className="text-sm font-medium">Add New Ticket</span>
        </button>
      </div>

      <div className="mt-8">
        <TicketList 
          tickets={tickets} 
          onUpdateStatus={onUpdateStatus} 
          onAddQuote={onAddQuote}
          onAddNote={onAddNote}
          onPrintTicket={onPrintTicket}
          onSendMessage={onSendMessage}
          // FIX: Pass technician assignment props down
          user={user}
          technicians={technicians}
          onAssignTechnician={onAssignTechnician}
        />
      </div>
    </>
  );
};

export default TicketManagement;