
import React, { useState, useEffect } from 'react';
import { Ticket, MessageTemplate } from '../../types';
import { MESSAGE_TEMPLATES } from '../../constants';
import CloseIcon from '../icons/CloseIcon';
import PaperAirplaneIcon from '../icons/PaperAirplaneIcon';

interface MessageCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  ticket: Ticket | null;
  onSend: (ticketId: string, method: 'SMS' | 'Email', message: string) => void;
}

const MessageCustomerModal: React.FC<MessageCustomerModalProps> = ({ isOpen, onClose, ticket, onSend }) => {
  const [method, setMethod] = useState<'SMS' | 'Email'>('SMS');
  const [message, setMessage] = useState('');
  const [templateId, setTemplateId] = useState('');

  useEffect(() => {
    if (isOpen) {
      setMessage('');
      setTemplateId('');
    }
  }, [isOpen]);
  
  const handleTemplateChange = (id: string) => {
    setTemplateId(id);
    const template = MESSAGE_TEMPLATES.find(t => t.id === id);
    if (template && ticket) {
      const personalizedMessage = template.body
        .replace('[Customer Name]', ticket.customer.name.split(' ')[0])
        .replace('[Device Model]', ticket.items[0]?.deviceModel || 'your device')
        .replace('$[Ticket Total]', `$${ticket.total.toFixed(2)}`);
      setMessage(personalizedMessage);
    } else if (id === '') {
        setMessage('');
    }
  };

  const handleSend = () => {
    if (!ticket || !message.trim()) {
      alert("Message cannot be empty.");
      return;
    }
    onSend(ticket.id, method, message.trim());
  };
  
  if (!isOpen || !ticket) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <div>
            <h2 className="text-xl font-bold text-dark-text-primary">Send Message to {ticket.customer.name}</h2>
            <p className="text-sm text-dark-text-secondary">Ticket #{ticket.id.substring(0,8)}</p>
          </div>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6 space-y-4">
          <div className="flex rounded-md shadow-sm" role="group">
            <button
              type="button"
              onClick={() => setMethod('SMS')}
              className={`px-4 py-2 w-full text-sm font-medium border rounded-l-lg transition-colors ${method === 'SMS' ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border hover:bg-dark-panel-light'}`}
            >
              SMS
            </button>
            <button
              type="button"
              onClick={() => setMethod('Email')}
              className={`px-4 py-2 w-full text-sm font-medium border rounded-r-lg transition-colors ${method === 'Email' ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border hover:bg-dark-panel-light'}`}
            >
              Email
            </button>
          </div>
          
          <div>
              <label htmlFor="template" className="block text-sm font-medium text-dark-text-secondary">Message Template</label>
              <select 
                id="template" 
                value={templateId} 
                onChange={e => handleTemplateChange(e.target.value)}
                className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
              >
                <option value="">-- Custom Message --</option>
                {MESSAGE_TEMPLATES.map(template => (
                  <option key={template.id} value={template.id}>{template.title}</option>
                ))}
              </select>
          </div>

          <div>
            <label htmlFor="message" className="block text-sm font-medium text-dark-text-secondary">Message</label>
            <textarea
              id="message"
              rows={6}
              value={message}
              onChange={e => {
                  setMessage(e.target.value);
                  setTemplateId(''); // Deselect template if user types
              }}
              className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
              placeholder="Type your message here..."
            />
          </div>
        </main>
        
        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl">
          <button
            onClick={handleSend}
            className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-2.5 text-dark-bg transition hover:bg-brand-green-darker font-bold text-sm"
          >
            <PaperAirplaneIcon className="w-5 h-5" />
            <span>Send Message</span>
          </button>
        </footer>
      </div>
    </div>
  );
};

export default MessageCustomerModal;
