import React, { useState, useEffect } from 'react';
import { PaymentMethodSettings } from '../../types';
import CashIcon from '../icons/CashIcon';
import CreditCardIcon from '../icons/CreditCardIcon';
import AfterpayIcon from '../icons/AfterpayIcon';
import SquareIcon from '../icons/SquareIcon';
import StoreCreditIcon from '../icons/StoreCreditIcon';

interface PaymentMethodsSettingsProps {
    settings: PaymentMethodSettings;
    onUpdate: (newSettings: PaymentMethodSettings) => void;
}

const paymentOptions = [
    { key: 'cash' as const, name: 'Cash', description: 'Accept physical cash payments.', icon: CashIcon },
    { key: 'card' as const, name: 'Card', description: 'Accept debit and credit card payments.', icon: CreditCardIcon },
    { key: 'afterpay' as const, name: 'Afterpay', description: 'Allow customers to pay in installments.', icon: AfterpayIcon },
    { key: 'square' as const, name: 'Square', description: 'Process payments through Square hardware.', icon: SquareIcon },
    { key: 'storeCredit' as const, name: 'Store Credit', description: 'Allow customers to pay with store credit.', icon: StoreCreditIcon },
];

const ToggleSwitch: React.FC<{ enabled: boolean; onChange: (enabled: boolean) => void }> = ({ enabled, onChange }) => {
    return (
        <button
            type="button"
            className={`${enabled ? 'bg-brand-green' : 'bg-dark-panel-light'} relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2 focus:ring-offset-dark-panel`}
            role="switch"
            aria-checked={enabled}
            onClick={() => onChange(!enabled)}
        >
            <span
                aria-hidden="true"
                className={`${enabled ? 'translate-x-5' : 'translate-x-0'} pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
            />
        </button>
    );
};


const PaymentMethodsSettings: React.FC<PaymentMethodsSettingsProps> = ({ settings, onUpdate }) => {
    const [currentSettings, setCurrentSettings] = useState(settings);

    useEffect(() => {
        setCurrentSettings(settings);
    }, [settings]);

    const handleToggle = (key: keyof PaymentMethodSettings) => {
        setCurrentSettings(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const handleSave = () => {
        onUpdate(currentSettings);
        alert('Payment methods saved!');
    };

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
            <div className="space-y-6">
                <div className="divide-y divide-dark-border">
                    {paymentOptions.map((option) => (
                        <div key={option.key} className="flex items-center justify-between py-5">
                            <div className="flex items-center gap-4">
                                <div className="bg-dark-panel-light p-3 rounded-full">
                                    <option.icon className="h-6 w-6 text-brand-green" />
                                </div>
                                <div>
                                    <h3 className="text-base font-bold text-dark-text-primary">{option.name}</h3>
                                    <p className="text-sm text-dark-text-secondary mt-1">{option.description}</p>
                                </div>
                            </div>
                            <ToggleSwitch enabled={currentSettings[option.key]} onChange={() => handleToggle(option.key)} />
                        </div>
                    ))}
                </div>
                <div className="pt-6 border-t border-dark-border flex justify-end">
                    <button
                        onClick={handleSave}
                        className="px-5 py-2.5 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
                    >
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PaymentMethodsSettings;
