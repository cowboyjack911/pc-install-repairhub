import React, { useState, useEffect } from 'react';
import { TaxSettings, TaxRule } from '../../types';
import TrashIcon from '../icons/TrashIcon';
import PlusIcon from '../icons/PlusIcon';

interface TaxSettingsProps {
    settings: TaxSettings;
    onUpdate: (newSettings: TaxSettings) => void;
}

const TaxSettings: React.FC<TaxSettingsProps> = ({ settings, onUpdate }) => {
    const [baseRate, setBaseRate] = useState(settings.baseRate);
    const [rules, setRules] = useState<TaxRule[]>(settings.rules);

    useEffect(() => {
        setBaseRate(settings.baseRate);
        setRules(settings.rules);
    }, [settings]);

    const handleSave = () => {
        onUpdate({ baseRate, rules });
        alert('Tax settings saved!');
    };
    
    const handleRuleChange = (id: string, field: keyof TaxRule, value: string | number | boolean) => {
        setRules(currentRules => currentRules.map(rule => {
            if (rule.id === id) {
                // Ensure rate is parsed as a number
                const updatedValue = field === 'rate' ? parseFloat(value as string) || 0 : value;
                return { ...rule, [field]: updatedValue };
            }
            return rule;
        }));
    };

    const handleAddRule = () => {
        const newRule: TaxRule = {
            id: `rule_${crypto.randomUUID()}`,
            name: 'New Tax Rule',
            rate: 0,
            isEnabled: true,
        };
        setRules([...rules, newRule]);
    };

    const handleDeleteRule = (id: string) => {
        if (window.confirm('Are you sure you want to delete this tax rule?')) {
            setRules(currentRules => currentRules.filter(rule => rule.id !== id));
        }
    };

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
            <div className="space-y-8">
                {/* Base Tax Rate Section */}
                <div>
                    <h2 className="text-lg font-semibold text-dark-text-primary mb-2">Base Tax Rate</h2>
                    <p className="text-sm text-dark-text-secondary mb-4">This is the default tax rate applied to all sales unless overridden by a specific rule.</p>
                    <div className="max-w-xs">
                        <label htmlFor="baseRate" className="block text-sm font-medium text-dark-text-secondary">Base Rate (%)</label>
                        <input 
                            type="number" 
                            id="baseRate" 
                            value={baseRate} 
                            onChange={e => setBaseRate(parseFloat(e.target.value) || 0)}
                            className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green"
                            step="0.01"
                        />
                    </div>
                </div>

                {/* Tax Rules Section */}
                <div className="pt-6 border-t border-dark-border">
                    <div className="flex justify-between items-center mb-4">
                        <div>
                           <h2 className="text-lg font-semibold text-dark-text-primary">Tax Rules</h2>
                           <p className="text-sm text-dark-text-secondary mt-1">Add specific tax rules for different products, services, or locations.</p>
                        </div>
                        <button
                            onClick={handleAddRule}
                            className="flex items-center justify-center gap-2 rounded-lg bg-dark-accent-blue px-4 py-2 text-white transition hover:bg-blue-700 font-bold text-sm"
                        >
                            <PlusIcon className="w-5 h-5" />
                            <span>Add Rule</span>
                        </button>
                    </div>

                    <div className="space-y-4">
                        {rules.length > 0 ? rules.map(rule => (
                            <div key={rule.id} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center bg-dark-panel-light p-4 rounded-md">
                                <div className="md:col-span-5">
                                    <label className="block text-xs font-medium text-dark-text-secondary mb-1">Rule Name</label>
                                    <input 
                                        type="text" 
                                        value={rule.name}
                                        onChange={e => handleRuleChange(rule.id, 'name', e.target.value)}
                                        className="block w-full text-sm bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green"
                                    />
                                </div>
                                <div className="md:col-span-3">
                                    <label className="block text-xs font-medium text-dark-text-secondary mb-1">Rate (%)</label>
                                    <input 
                                        type="number" 
                                        value={rule.rate}
                                        onChange={e => handleRuleChange(rule.id, 'rate', e.target.value)}
                                        className="block w-full text-sm bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green"
                                        step="0.01"
                                    />
                                </div>
                                <div className="md:col-span-2 flex items-center mt-5">
                                    <label className="flex items-center space-x-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            className="h-5 w-5 rounded bg-dark-bg border-dark-border text-brand-green focus:ring-brand-green"
                                            checked={rule.isEnabled}
                                            onChange={e => handleRuleChange(rule.id, 'isEnabled', e.target.checked)}
                                        />
                                        <span className="text-sm text-dark-text-secondary">Enabled</span>
                                    </label>
                                </div>
                                <div className="md:col-span-2 text-right mt-5">
                                     <button
                                        onClick={() => handleDeleteRule(rule.id)}
                                        className="text-red-400 hover:text-red-300 p-2 rounded-md hover:bg-red-500/10"
                                        aria-label="Delete rule"
                                     >
                                        <TrashIcon className="w-5 h-5" />
                                    </button>
                                </div>
                            </div>
                        )) : (
                             <div className="text-center py-8 border-2 border-dashed border-dark-border rounded-lg">
                                <p className="text-dark-text-secondary">No tax rules have been created yet.</p>
                             </div>
                        )}
                    </div>
                </div>

                {/* Save Button */}
                <div className="pt-6 border-t border-dark-border flex justify-end">
                    <button
                        onClick={handleSave}
                        className="px-5 py-2.5 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
                    >
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TaxSettings;
