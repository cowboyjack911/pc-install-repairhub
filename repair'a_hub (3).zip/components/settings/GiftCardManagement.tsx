
import React, { useState, useMemo } from 'react';
import { GiftCard } from '../../types';
import SearchIcon from '../icons/SearchIcon';

interface GiftCardManagementProps {
  giftCards: GiftCard[];
}

const GiftCardManagement: React.FC<GiftCardManagementProps> = ({ giftCards }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredGiftCards = useMemo(() => {
    if (!searchTerm) return giftCards;
    return giftCards.filter(
      card => card.id.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [giftCards, searchTerm]);

  return (
    <>
      <div>
        {/* Search Bar */}
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by gift card code..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-72 focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        {/* Gift Cards Table */}
        <div className="mt-4 overflow-x-auto">
          <div className="align-middle inline-block min-w-full">
            <div className="shadow overflow-hidden border-b border-dark-border rounded-lg">
              <table className="min-w-full divide-y divide-dark-border">
                <thead className="bg-dark-panel">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Code</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Initial Value</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Current Balance</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Date Issued</th>
                  </tr>
                </thead>
                <tbody className="bg-dark-panel-light divide-y divide-dark-border">
                  {filteredGiftCards.map((card) => (
                    <tr key={card.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-dark-text-primary">{card.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">${card.initialValue.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-brand-green">${card.balance.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${card.status === 'active' ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-300'}`}>
                          {card.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{card.createdAt.toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {filteredGiftCards.length === 0 && (
          <div className="text-center py-16 bg-dark-panel rounded-lg mt-4">
            <h3 className="text-xl font-medium text-dark-text-primary">No gift cards found.</h3>
            <p className="mt-2 text-base text-dark-text-secondary">
              Sell gift cards from the Point of Sale screen to see them here.
            </p>
          </div>
        )}
      </div>
    </>
  );
};

export default GiftCardManagement;
