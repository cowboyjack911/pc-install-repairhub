

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Supplier, Omit } from '../../types';
import PlusIcon from '../icons/PlusIcon';
import SearchIcon from '../icons/SearchIcon';
import PencilIcon from '../icons/PencilIcon';
import TrashIcon from '../icons/TrashIcon';
import SupplierModal from './SupplierModal';

interface SupplierManagementProps {
  suppliers: Supplier[];
  onAdd: (supplierData: Omit<Supplier, 'id'>) => void;
  onUpdate: (supplier: Supplier) => void;
  onDelete: (supplierId: string) => void;
}

const SupplierManagement: React.FC<SupplierManagementProps> = ({ suppliers, onAdd, onUpdate, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSuppliers = useMemo(() => {
    if (!searchTerm) return suppliers;
    return suppliers.filter(
      s =>
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.contactPerson?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [suppliers, searchTerm]);

  const handleOpenModal = (supplier: Supplier | null = null) => {
    setEditingSupplier(supplier);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingSupplier(null);
    setIsModalOpen(false);
  };

  const handleSave = (supplierData: Omit<Supplier, 'id'> | Supplier) => {
    if ('id' in supplierData) {
      onUpdate(supplierData);
    } else {
      onAdd(supplierData);
    }
    handleCloseModal();
  };

  return (
    <>
      <div>
        {/* Header */}
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>{/* Title handled by StaffHeader */}</div>
          <div className="flex items-center gap-4 mt-4 sm:mt-0">
            <button
              onClick={() => handleOpenModal()}
              className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
              type="button"
            >
              <PlusIcon className="w-5 h-5" />
              <span className="text-sm font-medium">Add New Supplier</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by supplier name..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-72 focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        {/* Suppliers Table */}
        <div className="mt-4 overflow-x-auto">
          <div className="align-middle inline-block min-w-full">
            <div className="shadow overflow-hidden border-b border-dark-border rounded-lg">
              <table className="min-w-full divide-y divide-dark-border">
                <thead className="bg-dark-panel">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Supplier Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Contact Person</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Contact Info</th>
                    <th scope="col" className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody className="bg-dark-panel-light divide-y divide-dark-border">
                  {filteredSuppliers.map((supplier) => (
                    <tr key={supplier.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-dark-text-primary">{supplier.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{supplier.contactPerson || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">
                        <div>{supplier.phone || '-'}</div>
                        <div>{supplier.email || '-'}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                        <button onClick={() => handleOpenModal(supplier)} className="text-dark-accent-blue hover:text-blue-400" aria-label="Edit Supplier"><PencilIcon className="w-5 h-5"/></button>
                        <button onClick={() => onDelete(supplier.id)} className="text-red-400 hover:text-red-300" aria-label="Delete Supplier"><TrashIcon className="w-5 h-5"/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {filteredSuppliers.length === 0 && (
          <div className="text-center py-16 bg-dark-panel rounded-lg mt-4">
            <h3 className="text-xl font-medium text-dark-text-primary">No suppliers found.</h3>
            <p className="mt-2 text-base text-dark-text-secondary">
              Click "Add New Supplier" to get started.
            </p>
          </div>
        )}
      </div>
      <SupplierModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSave}
        supplier={editingSupplier}
      />
    </>
  );
};

export default SupplierManagement;