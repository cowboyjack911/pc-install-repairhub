
import React from 'react';
import { TicketStatus } from '../../types';
import { STATUS_COLORS } from '../../constants';
import StatusBadge from '../StatusBadge';
import PlusIcon from '../icons/PlusIcon';

const OrderStatusSettings: React.FC = () => {
    const statuses = Object.values(TicketStatus);

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-dark-text-primary mb-2">Ticket Status Management</h2>
            <p className="text-sm text-dark-text-secondary mb-6">Customize the statuses for your repair tickets. Drag and drop to reorder.</p>

            <div className="space-y-3">
                {statuses.map(status => (
                    <div key={status} className="flex items-center justify-between bg-dark-panel-light p-4 rounded-md cursor-grab">
                        <div className="flex items-center gap-4">
                            {/* Drag Handle Icon could go here */}
                            <span className="text-gray-500">::</span>
                            <span className="font-medium text-dark-text-primary">{status}</span>
                        </div>
                        <StatusBadge status={status} />
                    </div>
                ))}
            </div>

            <div className="mt-6 border-t border-dark-border pt-6">
                <button
                    className="flex items-center justify-center gap-2 rounded-lg bg-dark-accent-blue px-4 py-2 text-white transition hover:bg-blue-700 font-bold text-sm"
                    onClick={() => alert('This functionality is for demonstration purposes.')}
                >
                    <PlusIcon className="w-5 h-5" />
                    <span>Add New Status</span>
                </button>
            </div>
        </div>
    );
};

export default OrderStatusSettings;
