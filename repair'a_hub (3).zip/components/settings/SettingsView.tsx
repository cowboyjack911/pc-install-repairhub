import React from 'react';
// Fix: Import NavItem from types.ts instead of constants/navigation.ts, as it is not exported from there.
import { SIDEBAR_NAV_ITEMS } from '../../constants/navigation';
import { NavItem } from '../../types';

interface SettingsViewProps {
  onNavigate: (itemId: string) => void;
}

const SettingsCard: React.FC<{ item: NavItem; onNavigate: (itemId: string) => void }> = ({ item, onNavigate }) => (
  <button
    onClick={() => item.view && onNavigate(item.id)}
    className="group block text-left w-full bg-dark-panel p-6 rounded-lg shadow-lg transition-all duration-300 hover:shadow-brand-green/20 hover:ring-1 hover:ring-dark-border h-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-bg focus:ring-brand-green"
    disabled={!item.view}
    aria-label={`Navigate to ${item.label} settings`}
  >
    <div className="flex items-start gap-4">
      <div className="bg-dark-panel-light p-3 rounded-full flex-shrink-0">
        <item.icon className="h-6 w-6 text-brand-green" />
      </div>
      <div>
        <h3 className="text-base font-bold text-dark-text-primary">{item.label}</h3>
        {item.description && <p className="text-sm text-dark-text-secondary mt-1">{item.description}</p>}
      </div>
    </div>
  </button>
);

const SettingsView: React.FC<SettingsViewProps> = ({ onNavigate }) => {
  const settingsNav = SIDEBAR_NAV_ITEMS.find(item => item.id === 'settings');
  const settingsItems = settingsNav?.subItems || [];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {settingsItems.map(item => (
        <SettingsCard key={item.id} item={item} onNavigate={onNavigate} />
      ))}
    </div>
  );
};

export default SettingsView;