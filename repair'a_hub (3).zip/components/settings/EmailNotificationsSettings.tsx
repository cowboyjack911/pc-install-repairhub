

import React, { useState } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { MessageTemplate, Omit } from '../../types';
import PlusIcon from '../icons/PlusIcon';
import PencilIcon from '../icons/PencilIcon';
import TrashIcon from '../icons/TrashIcon';
import MessageTemplateModal from './MessageTemplateModal';

interface EmailNotificationsSettingsProps {
  templates: MessageTemplate[];
  onAdd: (templateData: Omit<MessageTemplate, 'id'>) => void;
  onUpdate: (template: MessageTemplate) => void;
  onDelete: (templateId: string) => void;
}

const EmailNotificationsSettings: React.FC<EmailNotificationsSettingsProps> = ({ templates, onAdd, onUpdate, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplate | null>(null);

  const handleOpenModal = (template: MessageTemplate | null = null) => {
    setEditingTemplate(template);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingTemplate(null);
    setIsModalOpen(false);
  };

  const handleSave = (templateData: Omit<MessageTemplate, 'id'> | MessageTemplate) => {
    if ('id' in templateData) {
      onUpdate(templateData);
    } else {
      onAdd(templateData);
    }
    handleCloseModal();
  };

  return (
    <>
      <div className="sm:flex sm:items-center sm:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-dark-text-primary">Email & Notification Templates</h2>
          <p className="mt-1 text-sm text-dark-text-secondary">Manage the templates used for sending SMS and email notifications to customers.</p>
        </div>
        <button
          onClick={() => handleOpenModal()}
          className="mt-4 sm:mt-0 flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
          type="button"
        >
          <PlusIcon className="w-5 h-5" />
          <span className="text-sm font-medium">Add New Template</span>
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map(template => (
          <div key={template.id} className="bg-dark-panel p-5 rounded-lg shadow-lg flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-dark-text-primary">{template.title}</h3>
              <p className="text-sm text-dark-text-secondary mt-2 border-l-2 border-dark-border pl-3 italic">{template.body}</p>
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => handleOpenModal(template)} className="text-dark-accent-blue hover:text-blue-400 p-2 rounded-md hover:bg-dark-panel-light"><PencilIcon className="w-5 h-5"/></button>
              <button onClick={() => onDelete(template.id)} className="text-red-400 hover:text-red-300 p-2 rounded-md hover:bg-dark-panel-light"><TrashIcon className="w-5 h-5"/></button>
            </div>
          </div>
        ))}
      </div>

      <MessageTemplateModal 
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSave}
        template={editingTemplate}
      />
    </>
  );
};

export default EmailNotificationsSettings;