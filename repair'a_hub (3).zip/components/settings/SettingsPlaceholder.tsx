import React from 'react';
import WrenchScrewdriverIcon from '../icons/WrenchScrewdriverIcon';

const SettingsPlaceholder: React.FC = () => {
  return (
    <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
      <div className="text-center py-12 bg-dark-bg rounded-lg border border-dashed border-dark-border">
          <WrenchScrewdriverIcon className="mx-auto h-12 w-12 text-dark-border" />
          <h3 className="mt-4 text-xl font-medium text-dark-text-primary">Coming Soon</h3>
          <p className="mt-2 text-base text-dark-text-secondary">
            This settings section is under construction.
          </p>
      </div>
    </div>
  );
};

export default SettingsPlaceholder;