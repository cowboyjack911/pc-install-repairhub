

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Expense, Omit } from '../../types';
import PlusIcon from '../icons/PlusIcon';
import SearchIcon from '../icons/SearchIcon';
import PencilIcon from '../icons/PencilIcon';
import TrashIcon from '../icons/TrashIcon';
import ExpenseModal from './ExpenseModal';

interface ExpenseManagementProps {
  expenses: Expense[];
  onAdd: (expenseData: Omit<Expense, 'id'>) => void;
  onUpdate: (expense: Expense) => void;
  onDelete: (expenseId: string) => void;
}

const ExpenseManagement: React.FC<ExpenseManagementProps> = ({ expenses, onAdd, onUpdate, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredExpenses = useMemo(() => {
    if (!searchTerm) return expenses;
    return expenses.filter(
      e =>
        e.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [expenses, searchTerm]);

  const handleOpenModal = (expense: Expense | null = null) => {
    setEditingExpense(expense);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingExpense(null);
    setIsModalOpen(false);
  };

  const handleSave = (expenseData: Omit<Expense, 'id'> | Expense) => {
    if ('id' in expenseData) {
      onUpdate(expenseData);
    } else {
      onAdd(expenseData);
    }
    handleCloseModal();
  };

  return (
    <>
      <div>
        {/* Header */}
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>{/* Title handled by StaffHeader */}</div>
          <div className="flex items-center gap-4 mt-4 sm:mt-0">
            <button
              onClick={() => handleOpenModal()}
              className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
              type="button"
            >
              <PlusIcon className="w-5 h-5" />
              <span className="text-sm font-medium">Add New Expense</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by description or category..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-72 focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        {/* Expenses Table */}
        <div className="mt-4 overflow-x-auto">
          <div className="align-middle inline-block min-w-full">
            <div className="shadow overflow-hidden border-b border-dark-border rounded-lg">
              <table className="min-w-full divide-y divide-dark-border">
                <thead className="bg-dark-panel">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Date</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Category</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Description</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Amount</th>
                    <th scope="col" className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody className="bg-dark-panel-light divide-y divide-dark-border">
                  {filteredExpenses.map((expense) => (
                    <tr key={expense.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{expense.date.toLocaleDateString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{expense.category}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-dark-text-primary">{expense.description}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-primary font-semibold">${expense.amount.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                        <button onClick={() => handleOpenModal(expense)} className="text-dark-accent-blue hover:text-blue-400" aria-label="Edit Expense"><PencilIcon className="w-5 h-5"/></button>
                        <button onClick={() => onDelete(expense.id)} className="text-red-400 hover:text-red-300" aria-label="Delete Expense"><TrashIcon className="w-5 h-5"/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {filteredExpenses.length === 0 && (
          <div className="text-center py-16 bg-dark-panel rounded-lg mt-4">
            <h3 className="text-xl font-medium text-dark-text-primary">No expenses found.</h3>
            <p className="mt-2 text-base text-dark-text-secondary">
              Click "Add New Expense" to get started.
            </p>
          </div>
        )}
      </div>
      <ExpenseModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSave}
        expense={editingExpense}
      />
    </>
  );
};

export default ExpenseManagement;