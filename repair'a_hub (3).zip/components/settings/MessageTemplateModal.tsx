

import React, { useState, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { MessageTemplate, Omit } from '../../types';
import CloseIcon from '../icons/CloseIcon';

interface MessageTemplateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (template: Omit<MessageTemplate, 'id'> | MessageTemplate) => void;
  template: MessageTemplate | null;
}

const PLACEHOLDERS = ['[Customer Name]', '[Device Model]', '$[Ticket Total]'];

const MessageTemplateModal: React.FC<MessageTemplateModalProps> = ({ isOpen, onClose, onSave, template }) => {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const isEditing = !!template;

  useEffect(() => {
    if (isOpen) {
      setTitle(template?.title || '');
      setBody(template?.body || '');
    }
  }, [isOpen, template]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !body) {
      alert("Please fill in all fields.");
      return;
    }
    const templateData = { title, body };

    if (isEditing && template) {
      onSave({ ...templateData, id: template.id });
    } else {
      onSave(templateData);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <h2 className="text-xl font-bold text-dark-text-primary">
              {isEditing ? 'Edit Template' : 'Add New Template'}
            </h2>
            <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white transition-colors">
              <CloseIcon className="h-6 w-6" />
            </button>
          </header>

          <main className="p-6 space-y-4">
            <div>
              <label htmlFor="templateTitle" className="block text-sm font-medium text-dark-text-secondary">Template Title</label>
              <input type="text" id="templateTitle" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
            <div>
              <label htmlFor="templateBody" className="block text-sm font-medium text-dark-text-secondary">Template Body</label>
              <textarea id="templateBody" rows={5} value={body} onChange={e => setBody(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
            <div>
                <p className="text-xs text-dark-text-tertiary">Available placeholders:</p>
                <div className="flex flex-wrap gap-2 mt-1">
                    {PLACEHOLDERS.map(p => <code key={p} className="text-xs bg-dark-bg p-1 rounded">{p}</code>)}
                </div>
            </div>
          </main>

          <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker">Save Template</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default MessageTemplateModal;