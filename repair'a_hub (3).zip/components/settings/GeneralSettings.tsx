import React, { useState, useEffect } from 'react';
import { BusinessInfo } from '../../types';

interface GeneralSettingsProps {
    businessInfo: BusinessInfo;
    onUpdate: (newInfo: BusinessInfo) => void;
}

const GeneralSettings: React.FC<GeneralSettingsProps> = ({ businessInfo, onUpdate }) => {
  const [name, setName] = useState(businessInfo.name);
  const [tagline, setTagline] = useState(businessInfo.tagline);
  const [logoUrl, setLogoUrl] = useState(businessInfo.logoUrl);

  useEffect(() => {
    setName(businessInfo.name);
    setTagline(businessInfo.tagline);
    setLogoUrl(businessInfo.logoUrl);
  }, [businessInfo]);

  const handleSave = () => {
    onUpdate({ name, tagline, logoUrl });
    alert('Business information updated!');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveLogo = () => {
    setLogoUrl(undefined);
  };

  return (
    <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
        <div className="space-y-6">
            <div>
                <label htmlFor="businessName" className="block text-sm font-medium text-dark-text-secondary">Business Name</label>
                <input type="text" id="businessName" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green" />
            </div>
            <div>
                <label htmlFor="tagline" className="block text-sm font-medium text-dark-text-secondary">Tagline</label>
                <input type="text" id="tagline" value={tagline} onChange={e => setTagline(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green" />
            </div>
            
            <div>
                <label className="block text-sm font-medium text-dark-text-secondary">Business Logo</label>
                <div className="mt-2 flex items-center gap-6">
                    <div className="w-24 h-24 bg-dark-bg rounded-md flex items-center justify-center border border-dark-border">
                        {logoUrl ? (
                            <img src={logoUrl} alt="Logo Preview" className="max-h-full max-w-full" />
                        ) : (
                            <span className="text-xs text-dark-text-tertiary">No Logo</span>
                        )}
                    </div>
                    <div className="flex items-center gap-3">
                        <label htmlFor="logo-upload" className="cursor-pointer bg-dark-panel-light px-4 py-2 text-sm font-medium text-dark-text-primary rounded-md hover:bg-dark-border">
                            Upload
                        </label>
                        <input id="logo-upload" name="logo-upload" type="file" className="sr-only" accept="image/*" onChange={handleLogoUpload} />
                        {logoUrl && (
                             <button onClick={handleRemoveLogo} className="text-sm text-red-400 hover:text-red-300">Remove</button>
                        )}
                    </div>
                </div>
            </div>

            <div className="pt-6 border-t border-dark-border flex justify-end">
                <button
                    onClick={handleSave}
                    className="px-5 py-2.5 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
                >
                    Save Changes
                </button>
            </div>
        </div>
    </div>
  );
};

export default GeneralSettings;