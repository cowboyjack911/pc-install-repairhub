

import React, { useState, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Supplier, Omit } from '../../types';
import CloseIcon from '../icons/CloseIcon';

interface SupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (supplierData: Omit<Supplier, 'id'> | Supplier) => void;
  supplier: Supplier | null;
}

const SupplierModal: React.FC<SupplierModalProps> = ({ isOpen, onClose, onSave, supplier }) => {
  const [name, setName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const isEditing = !!supplier;

  useEffect(() => {
    if (isOpen) {
      setName(supplier?.name || '');
      setContactPerson(supplier?.contactPerson || '');
      setPhone(supplier?.phone || '');
      setEmail(supplier?.email || '');
      setAddress(supplier?.address || '');
      setNotes(supplier?.notes || '');
    }
  }, [isOpen, supplier]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) {
      alert("Supplier name is required.");
      return;
    }
    const supplierData = { name, contactPerson, phone, email, address, notes };

    if (isEditing && supplier) {
      onSave({ ...supplierData, id: supplier.id });
    } else {
      onSave(supplierData);
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <h2 className="text-xl font-bold text-dark-text-primary">
              {isEditing ? 'Edit Supplier' : 'Add New Supplier'}
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="text-dark-text-tertiary hover:text-white transition-colors"
            >
              <CloseIcon className="h-6 w-6" />
            </button>
          </header>

          <main className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto">
            <div className="md:col-span-2">
              <label htmlFor="supplierName" className="block text-sm font-medium text-dark-text-secondary">Supplier Name</label>
              <input type="text" id="supplierName" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
            <div>
              <label htmlFor="contactPerson" className="block text-sm font-medium text-dark-text-secondary">Contact Person</label>
              <input type="text" id="contactPerson" value={contactPerson} onChange={e => setContactPerson(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-dark-text-secondary">Phone Number</label>
              <input type="tel" id="phone" value={phone} onChange={e => setPhone(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="email" className="block text-sm font-medium text-dark-text-secondary">Email Address</label>
              <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="address" className="block text-sm font-medium text-dark-text-secondary">Address</label>
              <input type="text" id="address" value={address} onChange={e => setAddress(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="notes" className="block text-sm font-medium text-dark-text-secondary">Notes</label>
              <textarea id="notes" rows={3} value={notes} onChange={e => setNotes(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
          </main>

          <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker">
              Save Supplier
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default SupplierModal;