

import React, { useState, useMemo, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Supplier, InventoryItem, Omit, PurchaseOrder, POItem, POStatus } from '../types';
import CloseIcon from './icons/CloseIcon';
import SearchIcon from './icons/SearchIcon';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';

interface PurchaseOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  suppliers: Supplier[];
  inventoryItems: InventoryItem[];
  onSave: (poData: Omit<PurchaseOrder, 'id'>) => void;
}

const PurchaseOrderModal: React.FC<PurchaseOrderModalProps> = ({ isOpen, onClose, suppliers, inventoryItems, onSave }) => {
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [items, setItems] = useState<POItem[]>([]);
  const [itemSearchTerm, setItemSearchTerm] = useState('');

  const resetState = () => {
    setSelectedSupplierId('');
    setItems([]);
    setItemSearchTerm('');
  };

  const handleClose = () => {
    resetState();
    onClose();
  };

  const filteredInventory = useMemo(() => {
    if (!itemSearchTerm) return [];
    const selectedIds = new Set(items.map(i => i.itemId));
    return inventoryItems.filter(
      item =>
        !selectedIds.has(item.id) &&
        (item.name.toLowerCase().includes(itemSearchTerm.toLowerCase()) ||
          item.sku.toLowerCase().includes(itemSearchTerm.toLowerCase()))
    );
  }, [inventoryItems, itemSearchTerm, items]);

  const handleAddItem = (invItem: InventoryItem) => {
    const newItem: POItem = {
      itemId: invItem.id,
      name: invItem.name,
      sku: invItem.sku,
      quantityOrdered: 1,
      quantityReceived: 0,
      cost: invItem.cost,
    };
    setItems(prev => [...prev, newItem]);
    setItemSearchTerm('');
  };

  const handleUpdateItem = (itemId: string, field: 'quantityOrdered' | 'cost', value: number) => {
    if (value < 0) return;
    setItems(prev => prev.map(item => item.itemId === itemId ? { ...item, [field]: value } : item));
  };
  
  const handleRemoveItem = (itemId: string) => {
    setItems(prev => prev.filter(item => item.itemId !== itemId));
  };

  const totalCost = useMemo(() => {
    return items.reduce((sum, item) => sum + item.cost * item.quantityOrdered, 0);
  }, [items]);

  const handleSubmit = (status: POStatus.DRAFT | POStatus.ORDERED) => {
    if (!selectedSupplierId) {
      alert('Please select a supplier.');
      return;
    }
    if (items.length === 0) {
      alert('Please add at least one item to the purchase order.');
      return;
    }
    const supplier = suppliers.find(s => s.id === selectedSupplierId);
    if (!supplier) return;

    onSave({
      supplier,
      items,
      status,
      createdAt: new Date(),
      totalCost,
    });
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border flex-shrink-0">
          <h2 className="text-xl font-bold text-dark-text-primary">New Purchase Order</h2>
          <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6 overflow-y-auto flex-grow">
          {/* Supplier Selection */}
          <div className="mb-6">
            <label htmlFor="supplier" className="block text-sm font-medium text-dark-text-secondary">Supplier</label>
            <select
              id="supplier"
              value={selectedSupplierId}
              onChange={e => setSelectedSupplierId(e.target.value)}
              className="mt-1 block w-full md:w-1/2 bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
            >
              <option value="" disabled>Select a supplier</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          {/* Items Table */}
          <div>
             <h3 className="text-lg font-semibold text-dark-text-primary mb-2">Items</h3>
             <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-dark-border">
                    <thead className="bg-dark-panel-light">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider w-2/5">Item</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">SKU</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Qty</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Cost</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody className="bg-dark-bg divide-y divide-dark-border">
                        {items.map(item => (
                            <tr key={item.itemId}>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-primary">{item.name}</td>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-secondary">{item.sku}</td>
                                <td className="px-4 py-2">
                                    <input type="number" value={item.quantityOrdered} onChange={e => handleUpdateItem(item.itemId, 'quantityOrdered', parseInt(e.target.value) || 0)} className="w-20 bg-dark-panel-light border-dark-border rounded-md text-sm py-1 px-2"/>
                                </td>
                                <td className="px-4 py-2">
                                     <input type="number" value={item.cost} step="0.01" onChange={e => handleUpdateItem(item.itemId, 'cost', parseFloat(e.target.value) || 0)} className="w-24 bg-dark-panel-light border-dark-border rounded-md text-sm py-1 px-2"/>
                                </td>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-secondary">${(item.quantityOrdered * item.cost).toFixed(2)}</td>
                                <td className="px-4 py-2">
                                    <button onClick={() => handleRemoveItem(item.itemId)} className="text-red-400 hover:text-red-300"><TrashIcon className="w-5 h-5"/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
          </div>
          
          {/* Item Search */}
          <div className="mt-4">
            <label htmlFor="itemSearch" className="block text-sm font-medium text-dark-text-secondary">Add Item to PO</label>
            <div className="relative mt-1">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                id="itemSearch"
                placeholder="Search inventory by name or SKU..."
                value={itemSearchTerm}
                onChange={e => setItemSearchTerm(e.target.value)}
                className="bg-dark-bg border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full focus:ring-brand-green focus:border-brand-green"
              />
            </div>
            {itemSearchTerm && (
              <div className="mt-2 max-h-40 overflow-y-auto bg-dark-bg rounded-md border border-dark-border">
                {filteredInventory.length > 0 ? filteredInventory.map(invItem => (
                  <div key={invItem.id} className="flex items-center justify-between p-2 hover:bg-dark-panel-light">
                    <div>
                      <p className="text-sm font-medium text-dark-text-primary">{invItem.name}</p>
                      <p className="text-xs text-dark-text-secondary">SKU: {invItem.sku} | In Stock: {invItem.quantity}</p>
                    </div>
                    <button onClick={() => handleAddItem(invItem)} className="text-brand-green hover:text-brand-green-darker"><PlusIcon className="w-6 h-6"/></button>
                  </div>
                )) : <p className="p-2 text-sm text-dark-text-tertiary">No results found.</p>}
              </div>
            )}
          </div>

        </main>

        <footer className="flex justify-between items-center p-4 bg-dark-panel-light/50 rounded-b-2xl flex-shrink-0">
          <div className="text-lg font-bold text-dark-text-primary">
            Total: ${totalCost.toFixed(2)}
          </div>
          <div className="space-x-3">
            <button onClick={() => handleSubmit(POStatus.DRAFT)} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">Save as Draft</button>
            <button onClick={() => handleSubmit(POStatus.ORDERED)} className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker">Save as Ordered</button>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default PurchaseOrderModal;