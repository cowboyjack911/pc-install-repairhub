
import React, { useState, useEffect } from 'react';
import { PurchaseOrder, POItem } from '../types';
import CloseIcon from './icons/CloseIcon';

interface ReceivePOModalProps {
  isOpen: boolean;
  onClose: () => void;
  purchaseOrder: PurchaseOrder | null;
  onReceive: (poId: string, receivedQuantities: Record<string, number>) => void;
}

const ReceivePOModal: React.FC<ReceivePOModalProps> = ({ isOpen, onClose, purchaseOrder, onReceive }) => {
  const [receivedQuantities, setReceivedQuantities] = useState<Record<string, number>>({});

  useEffect(() => {
    if (isOpen && purchaseOrder) {
      // Initialize the state with 0 for each item
      const initialQuantities: Record<string, number> = {};
      purchaseOrder.items.forEach(item => {
        initialQuantities[item.itemId] = 0;
      });
      setReceivedQuantities(initialQuantities);
    } else {
      setReceivedQuantities({});
    }
  }, [isOpen, purchaseOrder]);
  
  const handleQuantityChange = (itemId: string, value: string, maxReceivable: number) => {
    const numericValue = parseInt(value, 10);
    if (isNaN(numericValue) || numericValue < 0) {
      setReceivedQuantities(prev => ({ ...prev, [itemId]: 0 }));
    } else {
      setReceivedQuantities(prev => ({ ...prev, [itemId]: Math.min(numericValue, maxReceivable) }));
    }
  };

  const handleReceiveAll = () => {
    if (!purchaseOrder) return;
    const allQuantities: Record<string, number> = {};
    purchaseOrder.items.forEach(item => {
        allQuantities[item.itemId] = item.quantityOrdered - item.quantityReceived;
    });
    setReceivedQuantities(allQuantities);
  };

  const handleSubmit = () => {
    if (!purchaseOrder) return;
    
    // Filter out items where 0 quantity was entered
    const finalQuantities: Record<string, number> = {};
    Object.entries(receivedQuantities).forEach(([itemId, quantity]) => {
      if (quantity > 0) {
        finalQuantities[itemId] = quantity;
      }
    });

    if (Object.keys(finalQuantities).length === 0) {
        alert("Please enter a quantity for at least one item to receive.");
        return;
    }
    
    onReceive(purchaseOrder.id, finalQuantities);
    onClose();
  };

  if (!isOpen || !purchaseOrder) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Receive Items for PO #{purchaseOrder.id.substring(0, 8)}</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6 overflow-y-auto">
            <div className="flex justify-end mb-4">
                <button onClick={handleReceiveAll} className="text-sm font-medium text-brand-green hover:text-brand-green-darker">
                    Receive All Remaining
                </button>
            </div>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-dark-border">
                    <thead className="bg-dark-panel-light">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider w-2/5">Item</th>
                            <th className="px-4 py-2 text-center text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Ordered</th>
                            <th className="px-4 py-2 text-center text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Received</th>
                            <th className="px-4 py-2 text-center text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Receiving Now</th>
                        </tr>
                    </thead>
                    <tbody className="bg-dark-bg divide-y divide-dark-border">
                        {purchaseOrder.items.map(item => {
                            const maxReceivable = item.quantityOrdered - item.quantityReceived;
                            return (
                                <tr key={item.itemId}>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-primary">{item.name}</td>
                                    <td className="px-4 py-2 text-center whitespace-nowrap text-sm text-dark-text-secondary">{item.quantityOrdered}</td>
                                    <td className="px-4 py-2 text-center whitespace-nowrap text-sm text-dark-text-secondary">{item.quantityReceived}</td>
                                    <td className="px-4 py-2 text-center">
                                        <input 
                                            type="number" 
                                            value={receivedQuantities[item.itemId] || 0}
                                            onChange={(e) => handleQuantityChange(item.itemId, e.target.value, maxReceivable)}
                                            className="w-24 bg-dark-panel-light border-dark-border rounded-md text-sm py-1 px-2 text-center"
                                            max={maxReceivable}
                                            min="0"
                                            disabled={maxReceivable <= 0}
                                        />
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </main>

        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
          <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">Cancel</button>
          <button onClick={handleSubmit} className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker">Receive Items</button>
        </footer>
      </div>
    </div>
  );
};

export default ReceivePOModal;
