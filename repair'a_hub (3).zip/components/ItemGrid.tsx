
import React from 'react';

// A generic item type that can represent Product, Manufacturer, or DeviceModel
interface GridItem {
    id: string;
    name: string;
    icon?: React.ElementType;
    price?: number;
}

interface ItemGridProps<T extends GridItem> {
    items: T[];
    onItemSelect: (item: T) => void;
    isMultiSelect?: boolean;
    selectedIds?: string[];
}

const ItemGrid = <T extends GridItem>({ items, onItemSelect, isMultiSelect = false, selectedIds = [] }: ItemGridProps<T>) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {items.map((item) => {
        const isSelected = selectedIds.includes(item.id);
        return (
            <button 
                key={item.id} 
                onClick={() => onItemSelect(item)}
                className={`relative group aspect-square bg-dark-panel-light rounded-lg flex flex-col items-center justify-center p-2 text-center hover:bg-dark-border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-green border-2 ${isSelected ? 'border-brand-green' : 'border-transparent'}`}
            >
                {isMultiSelect && (
                    <div className="absolute top-2 left-2 w-5 h-5 bg-dark-bg border-2 border-dark-text-tertiary rounded flex items-center justify-center">
                        {isSelected && <div className="w-2.5 h-2.5 bg-brand-green rounded-sm" />}
                    </div>
                )}
                {item.price != null && (
                    <span className={`absolute top-2 right-2 text-xs font-bold px-1.5 py-0.5 rounded-full ${isMultiSelect ? 'bg-dark-panel' : 'bg-brand-green text-dark-bg'}`}>
                        ${item.price.toFixed(2)}
                    </span>
                )}
                {item.icon && <item.icon className="w-8 h-8 sm:w-10 sm:h-10 text-dark-text-secondary group-hover:text-white transition-colors" />}
                <span className={`text-xs sm:text-sm font-medium text-dark-text-primary ${item.icon ? 'mt-2' : ''}`}>{item.name}</span>
            </button>
        )
      })}
    </div>
  );
};

export default ItemGrid;
