import React, { useState } from 'react';
import CloseIcon from './icons/CloseIcon';

interface AddQuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (ticketId: string, price: number) => void;
  ticketId: string | null;
}

const AddQuoteModal: React.FC<AddQuoteModalProps> = ({ isOpen, onClose, onSave, ticketId }) => {
  const [price, setPrice] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketId || !price || parseFloat(price) <= 0) {
      alert("Please enter a valid price.");
      return;
    }
    onSave(ticketId, parseFloat(price));
    setPrice('');
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-sm">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <h2 className="text-xl font-bold text-dark-text-primary">Add Quote</h2>
            <button
              type="button"
              onClick={onClose}
              className="text-dark-text-tertiary hover:text-white transition-colors"
            >
              <CloseIcon className="h-6 w-6" />
            </button>
          </header>

          <main className="p-6">
            <div>
              <label htmlFor="quotePrice" className="block text-sm font-medium text-dark-text-secondary">Repair Price ($)</label>
              <input
                type="number"
                id="quotePrice"
                value={price}
                onChange={e => setPrice(e.target.value)}
                step="0.01"
                min="0"
                className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
                required
                autoFocus
              />
            </div>
          </main>

          <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker">
              Save Quote
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default AddQuoteModal;