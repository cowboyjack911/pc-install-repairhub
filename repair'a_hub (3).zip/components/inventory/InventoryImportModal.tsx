import React, { useState } from 'react';
import CloseIcon from '../icons/CloseIcon';
import ArrowUpTrayIcon from '../icons/ArrowUpTrayIcon';

interface InventoryImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (file: File) => void;
}

const InventoryImportModal: React.FC<InventoryImportModalProps> = ({ isOpen, onClose, onImport }) => {
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleSubmit = () => {
    if (file) {
      onImport(file);
      onClose();
    } else {
      alert("Please select a file to import.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Import Inventory</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6">
          <p className="text-sm text-dark-text-secondary mb-4">
            Upload a CSV file to bulk import inventory items. The file should have the following columns in order: <code className="bg-dark-bg p-1 rounded-md text-xs">name</code>, <code className="bg-dark-bg p-1 rounded-md text-xs">sku</code>, <code className="bg-dark-bg p-1 rounded-md text-xs">quantity</code>, <code className="bg-dark-bg p-1 rounded-md text-xs">cost</code>.
          </p>
          
          <div 
            className="mt-4 flex justify-center rounded-lg border-2 border-dashed border-dark-border px-6 py-10"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            <div className="text-center">
              <ArrowUpTrayIcon className="mx-auto h-12 w-12 text-dark-text-tertiary" />
              <div className="mt-4 flex text-sm leading-6 text-dark-text-secondary">
                <label
                  htmlFor="file-upload"
                  className="relative cursor-pointer rounded-md font-semibold text-brand-green focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-green focus-within:ring-offset-2 focus-within:ring-offset-dark-panel hover:text-brand-green-darker"
                >
                  <span>Upload a file</span>
                  <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept=".csv" />
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs leading-5 text-dark-text-tertiary">CSV up to 10MB</p>
              {file && (
                <p className="mt-4 text-sm font-medium text-dark-text-primary">{file.name}</p>
              )}
            </div>
          </div>
          <a href="/sample_inventory.csv" download className="mt-4 inline-block text-sm text-brand-green hover:text-brand-green-darker">
            Download sample CSV file
          </a>
        </main>
        
        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-transparent border border-dark-border rounded-md shadow-sm hover:bg-dark-border"
            >
              Cancel
            </button>
            <button
                onClick={handleSubmit}
                disabled={!file}
                className="ml-3 px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker disabled:bg-gray-500 disabled:cursor-not-allowed"
            >
                Import Items
            </button>
        </footer>
      </div>
    </div>
  );
};

export default InventoryImportModal;
