
import React, { useState, useEffect } from 'react';
import { InventoryItem } from '../../types';
import CloseIcon from '../icons/CloseIcon';

interface StockAdjustmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (itemId: string, newQuantity: number, reason: string) => void;
  item: InventoryItem | null;
}

const REASONS = ['Stocktake', 'Damaged Item', 'Lost/Stolen', 'Inbound Shipment', 'Return', 'Other'];

const StockAdjustmentModal: React.FC<StockAdjustmentModalProps> = ({ isOpen, onClose, onSave, item }) => {
  const [newQuantity, setNewQuantity] = useState('');
  const [reason, setReason] = useState(REASONS[0]);

  useEffect(() => {
    if (isOpen && item) {
      setNewQuantity(item.quantity.toString());
      setReason(REASONS[0]);
    }
  }, [isOpen, item]);

  if (!isOpen || !item) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const quantity = parseInt(newQuantity, 10);
    if (isNaN(quantity) || quantity < 0) {
      alert("Please enter a valid quantity.");
      return;
    }
    onSave(item.id, quantity, reason);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-md">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <div>
                <h2 className="text-xl font-bold text-dark-text-primary">Adjust Stock</h2>
                <p className="text-sm text-dark-text-secondary">{item.name}</p>
            </div>
            <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
          </header>
          <main className="p-6 space-y-4">
            <div>
                <p className="text-sm text-center text-dark-text-secondary">Current Quantity on Hand: <span className="font-bold text-lg text-brand-green">{item.quantity}</span></p>
            </div>
            <div>
              <label htmlFor="newQuantity" className="block text-sm font-medium text-dark-text-secondary">New Quantity</label>
              <input type="number" id="newQuantity" value={newQuantity} onChange={e => setNewQuantity(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green" required />
            </div>
            <div>
              <label htmlFor="reason" className="block text-sm font-medium text-dark-text-secondary">Reason for Adjustment</label>
              <select id="reason" value={reason} onChange={e => setReason(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green" required>
                {REASONS.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
          </main>
          <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green rounded-md hover:bg-brand-green-darker">Save Adjustment</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default StockAdjustmentModal;
