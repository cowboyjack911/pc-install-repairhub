

import React, { useState, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Appointment, Omit, Customer, AppointmentStatus } from '../../types';
import CloseIcon from '../icons/CloseIcon';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment | null;
  customers: Customer[];
  onSave: (data: Omit<Appointment, 'id'> | Appointment) => void;
  onDelete: (appointmentId: string) => void;
}

const AppointmentModal: React.FC<AppointmentModalProps> = ({ isOpen, onClose, appointment, customers, onSave, onDelete }) => {
  const [customerId, setCustomerId] = useState('');
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<AppointmentStatus>(AppointmentStatus.SCHEDULED);
  const isEditing = !!appointment;

  useEffect(() => {
    if (isOpen) {
        if (appointment) {
            setCustomerId(appointment.customer.id);
            setDate(appointment.start.toISOString().split('T')[0]);
            setStartTime(appointment.start.toTimeString().slice(0, 5));
            setEndTime(appointment.end.toTimeString().slice(0, 5));
            setTitle(appointment.title);
            setNotes(appointment.notes || '');
            setStatus(appointment.status);
        } else {
            // Reset for new appointment
            setCustomerId('');
            setDate(new Date().toISOString().split('T')[0]);
            setStartTime('10:00');
            setEndTime('11:00');
            setTitle('');
            setNotes('');
            setStatus(AppointmentStatus.SCHEDULED);
        }
    }
  }, [isOpen, appointment]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedCustomer = customers.find(c => c.id === customerId);
    if (!selectedCustomer || !date || !startTime || !endTime || !title) {
      alert("Please fill in all required fields.");
      return;
    }

    const start = new Date(`${date}T${startTime}`);
    const end = new Date(`${date}T${endTime}`);

    const appointmentData = { customer: selectedCustomer, start, end, title, notes, status };

    if (isEditing && appointment) {
      onSave({ ...appointmentData, id: appointment.id });
    } else {
      onSave(appointmentData);
    }
  };

  const handleDelete = () => {
    if (appointment) {
      onDelete(appointment.id);
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <h2 className="text-xl font-bold text-dark-text-primary">{isEditing ? 'Edit Appointment' : 'New Appointment'}</h2>
            <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
          </header>

          <main className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
            <div>
              <label htmlFor="customer" className="block text-sm font-medium text-dark-text-secondary">Customer</label>
              <select id="customer" value={customerId} onChange={e => setCustomerId(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required>
                <option value="" disabled>Select a customer</option>
                {customers.filter(c => c.id !== 'cust_walkin').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
                <div>
                    <label htmlFor="date" className="block text-sm font-medium text-dark-text-secondary">Date</label>
                    <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required />
                </div>
                <div>
                    <label htmlFor="startTime" className="block text-sm font-medium text-dark-text-secondary">Start Time</label>
                    <input type="time" id="startTime" value={startTime} onChange={e => setStartTime(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required />
                </div>
                <div>
                    <label htmlFor="endTime" className="block text-sm font-medium text-dark-text-secondary">End Time</label>
                    <input type="time" id="endTime" value={endTime} onChange={e => setEndTime(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required />
                </div>
            </div>

            <div>
              <label htmlFor="title" className="block text-sm font-medium text-dark-text-secondary">Title / Purpose</label>
              <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" placeholder="e.g., iPhone Screen Repair Drop-off" required />
            </div>

            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-dark-text-secondary">Notes</label>
              <textarea id="notes" rows={3} value={notes} onChange={e => setNotes(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" />
            </div>

            <div>
              <label htmlFor="status" className="block text-sm font-medium text-dark-text-secondary">Status</label>
              <select id="status" value={status} onChange={e => setStatus(e.target.value as AppointmentStatus)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required>
                {Object.values(AppointmentStatus).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </main>

          <footer className="flex justify-between p-4 bg-dark-panel-light/50 rounded-b-2xl">
            <div>
              {isEditing && (
                <button type="button" onClick={handleDelete} className="px-4 py-2 text-sm font-medium text-red-400 hover:text-red-300">Delete</button>
              )}
            </div>
            <div className="space-x-3">
              <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border">Cancel</button>
              <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker">Save Appointment</button>
            </div>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default AppointmentModal;