

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Appointment, AppointmentStatus, Customer, Omit } from '../../types';
import PlusIcon from '../icons/PlusIcon';
import ChevronLeftIcon from '../icons/ChevronLeftIcon';
import ChevronRightIcon from '../icons/ChevronRightIcon';
import { APPOINTMENT_STATUS_COLORS } from '../../constants';
import AppointmentModal from './AppointmentModal';

interface AppointmentsViewProps {
  appointments: Appointment[];
  customers: Customer[];
  onAddAppointment: (appointmentData: Omit<Appointment, 'id'>) => void;
  onUpdateAppointment: (appointment: Appointment) => void;
  onDeleteAppointment: (appointmentId: string) => void;
}

const getStartOfWeek = (date: Date) => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
  return new Date(d.setDate(diff));
};

const AppointmentsView: React.FC<AppointmentsViewProps> = ({ appointments, customers, onAddAppointment, onUpdateAppointment, onDeleteAppointment }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);

  const startOfWeek = useMemo(() => getStartOfWeek(currentDate), [currentDate]);
  
  const weekDays = useMemo(() => {
    return Array.from({ length: 7 }).map((_, i) => {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      return day;
    });
  }, [startOfWeek]);
  
  const appointmentsByDay = useMemo(() => {
    const grouped: Record<string, Appointment[]> = {};
    weekDays.forEach(day => {
        grouped[day.toISOString().split('T')[0]] = [];
    });
    appointments.forEach(appt => {
        const dayKey = appt.start.toISOString().split('T')[0];
        if (grouped[dayKey]) {
            grouped[dayKey].push(appt);
        }
    });
    return grouped;
  }, [appointments, weekDays]);

  const handlePrevWeek = () => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setDate(prev.getDate() - 7);
      return newDate;
    });
  };

  const handleNextWeek = () => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setDate(prev.getDate() + 7);
      return newDate;
    });
  };

  const handleOpenModal = (appointment: Appointment | null) => {
    setSelectedAppointment(appointment);
    setIsModalOpen(true);
  };
  
  const handleSaveAppointment = (data: Omit<Appointment, 'id'> | Appointment) => {
    if ('id' in data) {
      onUpdateAppointment(data);
    } else {
      onAddAppointment(data);
    }
    setIsModalOpen(false);
  };


  return (
    <>
      <div>
        {/* Header */}
        <div className="sm:flex sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
                <button onClick={handlePrevWeek} className="p-2 rounded-md hover:bg-dark-panel-light"><ChevronLeftIcon className="w-6 h-6"/></button>
                <h2 className="text-xl font-semibold text-dark-text-primary text-center w-48">
                    {startOfWeek.toLocaleString('default', { month: 'long', year: 'numeric' })}
                </h2>
                <button onClick={handleNextWeek} className="p-2 rounded-md hover:bg-dark-panel-light"><ChevronRightIcon className="w-6 h-6"/></button>
            </div>
            <div className="flex items-center gap-4 mt-4 sm:mt-0">
                <button
                onClick={() => handleOpenModal(null)}
                className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
                type="button"
                >
                <PlusIcon className="w-5 h-5" />
                <span className="text-sm font-medium">New Appointment</span>
                </button>
            </div>
        </div>

        {/* Calendar Grid */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-7 gap-px bg-dark-border border border-dark-border rounded-lg overflow-hidden">
            {weekDays.map(day => {
                const dayKey = day.toISOString().split('T')[0];
                const dayAppointments = appointmentsByDay[dayKey] || [];
                const isToday = day.toDateString() === new Date().toDateString();
                return (
                    <div key={dayKey} className="bg-dark-panel min-h-[60vh]">
                        <div className={`p-2 border-b border-dark-border ${isToday ? 'bg-dark-accent-blue/20' : ''}`}>
                            <p className={`text-sm font-semibold text-center ${isToday ? 'text-dark-accent-blue' : 'text-dark-text-primary'}`}>{day.toLocaleString('default', { weekday: 'short' })}</p>
                            <p className={`text-2xl font-bold text-center ${isToday ? 'text-dark-accent-blue' : 'text-dark-text-primary'}`}>{day.getDate()}</p>
                        </div>
                        <div className="p-2 space-y-2">
                           {dayAppointments.sort((a,b) => a.start.getTime() - b.start.getTime()).map(appt => {
                               const statusColor = APPOINTMENT_STATUS_COLORS[appt.status];
                               return(
                                <button key={appt.id} onClick={() => handleOpenModal(appt)} className={`w-full text-left p-2 rounded-md ${statusColor.bg} hover:ring-2 hover:ring-brand-green transition-all`}>
                                    <p className="text-xs font-bold text-dark-text-primary">{appt.start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                                    <p className={`text-sm font-semibold ${statusColor.text}`}>{appt.title}</p>
                                    <p className="text-xs text-dark-text-secondary">{appt.customer.name}</p>
                                </button>
                           )})}
                        </div>
                    </div>
                )
            })}
        </div>
      </div>
      <AppointmentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        appointment={selectedAppointment}
        customers={customers}
        onSave={handleSaveAppointment}
        onDelete={onDeleteAppointment}
      />
    </>
  );
};

export default AppointmentsView;