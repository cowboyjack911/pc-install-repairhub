import React from 'react';
import { Customer } from '../types';
import SearchIcon from './icons/SearchIcon';
import PlusIcon from './icons/PlusIcon';
import EllipsisVerticalIcon from './icons/EllipsisVerticalIcon';

interface CustomerInfoProps {
  customer: Customer;
  onOpenCustomerSearch: () => void;
  onOpenCustomerAdd: () => void;
  onOpenCustomerDetail: () => void;
  onOpenActions: () => void;
}

const CustomerInfo: React.FC<CustomerInfoProps> = ({ customer, onOpenCustomerSearch, onOpenCustomerAdd, onOpenCustomerDetail, onOpenActions }) => {
  return (
    <div className="flex items-center justify-between p-4 bg-dark-panel-light rounded-lg flex-shrink-0">
      <button
        onClick={onOpenCustomerDetail}
        className="flex items-center gap-4 group disabled:cursor-default"
        disabled={customer.id === 'cust_walkin'}
        aria-label="View customer details"
      >
        <div className="w-12 h-12 bg-dark-bg rounded-full flex items-center justify-center text-brand-green font-bold text-xl">
            {customer.name.charAt(0).toUpperCase()}
        </div>
        <div className="text-left">
          <h2 className="text-lg font-bold text-dark-text-primary transition-colors group-hover:disabled:text-dark-text-primary group-hover:text-brand-green">{customer.name}</h2>
        </div>
      </button>

      <div className="flex items-center gap-2">
         <button
          onClick={onOpenActions}
          className="p-2 rounded-md hover:bg-dark-bg text-dark-text-tertiary hover:text-white"
          aria-label="More actions"
        >
            <EllipsisVerticalIcon className="w-6 h-6" />
        </button>
        <button
          onClick={onOpenCustomerSearch}
          className="p-3 rounded-md bg-dark-bg hover:bg-dark-border text-dark-text-primary"
          aria-label="Search for customer"
        >
            <SearchIcon className="w-5 h-5" />
        </button>
        <button 
          onClick={onOpenCustomerAdd}
          className="p-3 rounded-md bg-dark-accent-blue hover:bg-blue-700 text-white" 
          aria-label="Add new customer"
        >
            <PlusIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default CustomerInfo;