import React, { useState, useEffect } from 'react';
import { Customer, NotificationPreferences, TicketStatus } from '../../types';
import CloseIcon from '../icons/CloseIcon';
import { STATUS_OPTIONS } from '../../constants';

interface PortalSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer;
  onSave: (customerId: string, preferences: NotificationPreferences) => void;
}

const PortalSettingsModal: React.FC<PortalSettingsModalProps> = ({ isOpen, onClose, customer, onSave }) => {
  const [preferences, setPreferences] = useState<NotificationPreferences | undefined>(customer.notificationPreferences);
  
  const relevantStatuses = STATUS_OPTIONS.filter(s => s !== TicketStatus.SAVED && s !== TicketStatus.CANCELLED);

  useEffect(() => {
    setPreferences(customer.notificationPreferences);
  }, [customer]);

  const handleCheckboxChange = (status: TicketStatus, type: 'email' | 'sms') => {
    if (!preferences) return;
    const newPrefs = { ...preferences };
    newPrefs[status][type] = !newPrefs[status][type];
    setPreferences(newPrefs);
  };

  const handleSave = () => {
    if (preferences) {
      onSave(customer.id, preferences);
    }
    onClose();
  };

  if (!isOpen || !preferences) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Notification Preferences</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6 overflow-y-auto">
          <p className="text-sm text-dark-text-secondary mb-6">Choose how you'd like to be notified about updates to your repairs.</p>
          <div className="space-y-4">
            {relevantStatuses.map(status => (
              <div key={status} className="bg-dark-panel-light p-4 rounded-lg">
                <h3 className="font-semibold text-dark-text-primary">{status}</h3>
                <div className="mt-2 flex items-center space-x-8">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      className="rounded bg-dark-bg border-dark-border text-brand-green focus:ring-brand-green"
                      checked={preferences[status]?.email || false}
                      onChange={() => handleCheckboxChange(status, 'email')}
                    />
                    <span className="text-sm text-dark-text-secondary">Email</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      className="rounded bg-dark-bg border-dark-border text-brand-green focus:ring-brand-green"
                      checked={preferences[status]?.sms || false}
                      onChange={() => handleCheckboxChange(status, 'sms')}
                    />
                    <span className="text-sm text-dark-text-secondary">SMS</span>
                  </label>
                </div>
              </div>
            ))}
          </div>
        </main>
        
        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl">
          <button
            onClick={handleSave}
            className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
          >
            Save Preferences
          </button>
        </footer>
      </div>
    </div>
  );
};

export default PortalSettingsModal;
