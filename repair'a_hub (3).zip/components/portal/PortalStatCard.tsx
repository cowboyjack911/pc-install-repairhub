
import React from 'react';

interface PortalStatCardProps {
  title: string;
  value: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

const PortalStatCard: React.FC<PortalStatCardProps> = ({ title, value, icon: Icon }) => {
  return (
    <div className="bg-dark-panel p-5 rounded-lg shadow-lg flex items-center space-x-4">
      <div className="flex-shrink-0">
        <div className="bg-dark-panel-light p-3 rounded-full">
          <Icon className="h-6 w-6 text-brand-green" />
        </div>
      </div>
      <div>
        <dt className="text-sm font-medium text-dark-text-secondary truncate">{title}</dt>
        <dd className="mt-1 text-2xl font-semibold text-dark-text-primary">{value}</dd>
      </div>
    </div>
  );
};

export default PortalStatCard;
