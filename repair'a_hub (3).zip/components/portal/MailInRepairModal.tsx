import React, { useState } from 'react';
import { Product, ShippingAddress } from '../../types';
import CloseIcon from '../icons/CloseIcon';
import ProductGrid from '../ProductGrid';

interface MailInRepairModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onStartMailIn: (repairData: { product: Product; deviceModel: string; issue: string; shippingAddress: ShippingAddress; }) => void;
}

const MailInRepairModal: React.FC<MailInRepairModalProps> = ({ isOpen, onClose, products, onStartMailIn }) => {
  const [step, setStep] = useState(1);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [deviceModel, setDeviceModel] = useState('');
  const [issue, setIssue] = useState('');
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
      street: '', city: '', state: '', zip: '', country: 'USA'
  });
  const [trackingNumber, setTrackingNumber] = useState('');

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setStep(2);
  };
  
  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deviceModel || !issue) return;
    setStep(3);
  };
  
  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const { street, city, state, zip } = shippingAddress;
    if (!street || !city || !state || !zip) return;
    setStep(4);
  }

  const handleConfirm = () => {
    if (!selectedProduct) return;
    onStartMailIn({
        product: selectedProduct,
        deviceModel,
        issue,
        shippingAddress
    });
    // Simulate label generation
    setTrackingNumber(`1Z${Math.random().toString().slice(2, 18).toUpperCase()}`);
    setStep(5); // Go to final confirmation screen
  };
  
  const handleClose = () => {
    setStep(1);
    setSelectedProduct(null);
    setDeviceModel('');
    setIssue('');
    setShippingAddress({ street: '', city: '', state: '', zip: '', country: 'USA' });
    setTrackingNumber('');
    onClose();
  }

  const renderStepContent = () => {
      switch(step) {
          case 1:
              return (
                <>
                    <header className="flex items-center justify-between p-4 border-b border-dark-border">
                        <h2 className="text-xl font-bold text-dark-text-primary">Step 1: Select Service Type</h2>
                        <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
                    </header>
                    <main className="p-6 overflow-y-auto"><ProductGrid onProductSelect={handleProductSelect} /></main>
                </>
              );
          case 2:
              return (
                <form onSubmit={handleDetailsSubmit}>
                    <header className="flex items-center justify-between p-4 border-b border-dark-border">
                        <h2 className="text-xl font-bold text-dark-text-primary">Step 2: Device Details</h2>
                        <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
                    </header>
                    <main className="p-6 space-y-4">
                        <input type="text" placeholder="Device Model (e.g., iPhone 14 Pro)" value={deviceModel} onChange={e => setDeviceModel(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required />
                        <textarea placeholder="Describe the issue" rows={5} value={issue} onChange={e => setIssue(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" required />
                    </main>
                    <footer className="flex justify-between p-4 bg-dark-panel-light/50 rounded-b-2xl">
                        <button type="button" onClick={() => setStep(1)} className="px-4 py-2 text-sm font-medium border rounded-md">Back</button>
                        <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md">Next: Shipping</button>
                    </footer>
                </form>
              );
           case 3:
                return (
                 <form onSubmit={handleAddressSubmit}>
                    <header className="flex items-center justify-between p-4 border-b border-dark-border">
                        <h2 className="text-xl font-bold text-dark-text-primary">Step 3: Return Shipping Address</h2>
                        <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
                    </header>
                    <main className="p-6 grid grid-cols-2 gap-4">
                        <input type="text" placeholder="Street Address" value={shippingAddress.street} onChange={e => setShippingAddress(s => ({...s, street: e.target.value}))} className="col-span-2 mt-1 block w-full bg-dark-bg border-dark-border rounded-md" required />
                        <input type="text" placeholder="City" value={shippingAddress.city} onChange={e => setShippingAddress(s => ({...s, city: e.target.value}))} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md" required />
                        <input type="text" placeholder="State" value={shippingAddress.state} onChange={e => setShippingAddress(s => ({...s, state: e.target.value}))} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md" required />
                        <input type="text" placeholder="ZIP Code" value={shippingAddress.zip} onChange={e => setShippingAddress(s => ({...s, zip: e.target.value}))} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md" required />
                        <input type="text" placeholder="Country" value={shippingAddress.country} onChange={e => setShippingAddress(s => ({...s, country: e.target.value}))} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md" required />
                    </main>
                    <footer className="flex justify-between p-4 bg-dark-panel-light/50 rounded-b-2xl">
                        <button type="button" onClick={() => setStep(2)} className="px-4 py-2 text-sm font-medium border rounded-md">Back</button>
                        <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md">Next: Confirm</button>
                    </footer>
                 </form>
                )
           case 4:
                return (
                    <>
                    <header className="flex items-center justify-between p-4 border-b border-dark-border">
                        <h2 className="text-xl font-bold text-dark-text-primary">Step 4: Confirmation</h2>
                        <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
                    </header>
                    <main className="p-6 text-sm space-y-4">
                        <p>Please review the details below and generate your pre-paid shipping label.</p>
                        <div className="bg-dark-panel-light p-4 rounded-lg space-y-2">
                            <p><strong className="text-dark-text-secondary">Device:</strong> {deviceModel}</p>
                            <p><strong className="text-dark-text-secondary">Issue:</strong> {issue}</p>
                            <p><strong className="text-dark-text-secondary">Return To:</strong> {`${shippingAddress.street}, ${shippingAddress.city}, ${shippingAddress.state} ${shippingAddress.zip}`}</p>
                        </div>
                    </main>
                    <footer className="flex justify-between p-4 bg-dark-panel-light/50 rounded-b-2xl">
                        <button type="button" onClick={() => setStep(3)} className="px-4 py-2 text-sm font-medium border rounded-md">Back</button>
                        <button onClick={handleConfirm} className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md">Generate Shipping Label</button>
                    </footer>
                    </>
                )
           case 5:
               return (
                    <>
                    <header className="flex items-center justify-between p-4 border-b border-dark-border">
                        <h2 className="text-xl font-bold text-dark-text-primary">Mail-in Started!</h2>
                        <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
                    </header>
                    <main className="p-6 text-center">
                        <p className="text-lg">Your shipping label has been generated!</p>
                        <p className="text-sm text-dark-text-secondary mt-2">Please package your device securely and attach the label. Drop it off at any authorized shipping center.</p>
                        <div className="mt-4 bg-dark-bg p-3 rounded-lg inline-block">
                           <p className="text-xs text-dark-text-secondary">Your Tracking Number:</p>
                           <p className="font-mono text-brand-green font-bold">{trackingNumber}</p>
                        </div>
                    </main>
                    <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl">
                        <button onClick={handleClose} className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md">Done</button>
                    </footer>
                    </>
               )
          default:
              return null;
      }
  }

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col">
          {renderStepContent()}
      </div>
    </div>
  );
};

export default MailInRepairModal;
