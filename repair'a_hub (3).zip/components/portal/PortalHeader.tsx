import React from 'react';
import { User } from '../../services/firebaseService';
import UserIcon from '../icons/UserIcon';
import CogIcon from '../icons/CogIcon';
import LogoutIcon from '../icons/LogoutIcon';

interface PortalHeaderProps {
  user: User;
  onLogout: () => void;
  onOpenSettings: () => void;
}

const PortalHeader: React.FC<PortalHeaderProps> = ({ user, onLogout, onOpenSettings }) => {
  const displayName = user.displayName || user.email?.split('@')[0] || 'Customer';
  
  return (
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-2">
        <UserIcon className="w-6 h-6 text-dark-text-secondary" />
        <span className="text-sm font-medium text-dark-text-primary hidden sm:block">
          Welcome, {displayName}
        </span>
      </div>
      <button
        onClick={onOpenSettings}
        className="p-2 rounded-full text-dark-text-tertiary hover:text-white hover:bg-dark-panel-light"
        aria-label="Settings"
      >
        <CogIcon className="h-5 w-5" />
      </button>
      <button
        onClick={onLogout}
        className="p-2 rounded-full text-dark-text-tertiary hover:text-white hover:bg-dark-panel-light"
        aria-label="Log Out"
      >
        <LogoutIcon className="h-5 w-5" />
      </button>
    </div>
  );
};

export default PortalHeader;