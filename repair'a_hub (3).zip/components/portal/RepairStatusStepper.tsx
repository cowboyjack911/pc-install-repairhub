
import React from 'react';
import { TicketStatus } from '../../types';
import CheckIcon from '../icons/CheckIcon';

const STEPS = [
  { status: TicketStatus.NEW, label: 'Submitted' },
  { status: TicketStatus.QUOTE_PENDING, label: 'Quote Ready' },
  { status: TicketStatus.IN_PROGRESS, label: 'In Progress' },
  { status: TicketStatus.COMPLETED, label: 'Completed' },
];

// A mapping to determine the order/index of each status
const statusOrder: { [key in TicketStatus]?: number } = {
    [TicketStatus.WAITING_FOR_ARRIVAL]: 0,
    [TicketStatus.NEW]: 0,
    [TicketStatus.QUOTE_PENDING]: 1,
    [TicketStatus.IN_PROGRESS]: 2,
    [TicketStatus.WAITING_for_PARTS]: 2, // Treated as "In Progress"
    [TicketStatus.COMPLETED]: 3,
};


const RepairStatusStepper: React.FC<{ currentStatus: TicketStatus }> = ({ currentStatus }) => {
    const currentIndex = statusOrder[currentStatus] ?? -1;

    // Don't show stepper for cancelled tickets
    if(currentStatus === TicketStatus.CANCELLED) return null;

    return (
        <div className="flex items-center justify-between">
            {STEPS.map((step, index) => {
                const isCompleted = index < currentIndex;
                const isCurrent = index === currentIndex;
                const isFuture = index > currentIndex;

                return (
                    <React.Fragment key={step.status}>
                        <div className="flex flex-col items-center text-center">
                            <div className={`
                                w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all duration-300
                                ${isCompleted ? 'bg-brand-green border-brand-green text-dark-bg' : ''}
                                ${isCurrent ? 'bg-dark-accent-blue border-dark-accent-blue text-white animate-pulse' : ''}
                                ${isFuture ? 'bg-dark-panel-light border-dark-border text-dark-text-tertiary' : ''}
                            `}>
                                {isCompleted ? <CheckIcon className="w-5 h-5"/> : <span className="font-bold">{index + 1}</span>}
                            </div>
                            <p className={`
                                mt-2 text-xs font-medium transition-colors
                                ${isFuture ? 'text-dark-text-tertiary' : 'text-dark-text-primary'}
                            `}>
                                {step.label}
                            </p>
                        </div>
                        {index < STEPS.length - 1 && (
                             <div className={`
                                flex-1 h-1 mx-2 rounded
                                ${isCompleted || isCurrent ? 'bg-brand-green' : 'bg-dark-border'}
                             `}></div>
                        )}
                    </React.Fragment>
                );
            })}
        </div>
    );
};

export default RepairStatusStepper;
