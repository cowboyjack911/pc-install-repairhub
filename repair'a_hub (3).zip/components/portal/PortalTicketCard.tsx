

import React from 'react';
import { Ticket, TicketStatus } from '../../types';
import RepairStatusStepper from './RepairStatusStepper';

interface PortalTicketCardProps {
  ticket: Ticket;
  onApprove: (ticketId: string) => void;
  onDecline: (ticketId: string) => void;
}

const PortalTicketCard: React.FC<PortalTicketCardProps> = ({ ticket, onApprove, onDecline }) => {
  const firstItem = ticket.items[0];
  const isQuotePending = ticket.status === TicketStatus.QUOTE_PENDING;
  const isActionable = isQuotePending;
  const isPastTicket = ticket.status === TicketStatus.COMPLETED || ticket.status === TicketStatus.CANCELLED;

  return (
    <div className={`bg-dark-panel rounded-lg shadow-md transition-all duration-300 ${isActionable ? 'ring-2 ring-brand-green' : 'border border-transparent'}`}>
      <div className="p-5">
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
          <div className="flex-1">
            <p className="text-sm text-dark-text-secondary">
              Ticket #{ticket.id.substring(0, 8)} &bull; {ticket.createdAt.toLocaleDateString()}
            </p>
            <p className="font-bold text-lg text-dark-text-primary mt-1">
              {firstItem?.name || 'Repair Request'}
            </p>
            <p className="text-sm text-dark-text-secondary mt-1">
              {firstItem?.issue || 'No details provided.'}
            </p>
          </div>
          <div className="flex-shrink-0 text-left sm:text-right">
             {!isPastTicket && !isQuotePending && (
                <div className="px-3 py-1 text-sm font-medium rounded-full bg-dark-panel-light text-dark-text-primary">
                    Status: {ticket.status}
                </div>
            )}
             {isQuotePending && (
                <div className="text-right">
                    <p className="text-sm text-dark-text-secondary">Quote Ready</p>
                    <p className="text-2xl font-bold text-brand-green mt-1">A${ticket.total.toFixed(2)}</p>
                </div>
            )}
            {isPastTicket && (
                 <div className={`px-3 py-1 text-sm font-medium rounded-full ${ticket.status === TicketStatus.COMPLETED ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                    {ticket.status}
                </div>
            )}
          </div>
        </div>
      </div>

      {!isPastTicket && (
        <div className="px-5 py-4 bg-dark-panel-light/50 rounded-b-lg">
          <RepairStatusStepper currentStatus={ticket.status} />
        </div>
      )}
      
      {isQuotePending && (
        <div className="p-4 bg-dark-panel-light/50 rounded-b-lg flex items-center justify-end gap-3">
            <button 
                onClick={() => onDecline(ticket.id)}
                className="px-4 py-2 text-sm font-medium text-red-400 bg-transparent border border-red-400/50 rounded-md hover:bg-red-500/10"
            >
                Decline Quote
            </button>
            <button 
                onClick={() => onApprove(ticket.id)}
                className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md hover:bg-brand-green-darker"
            >
                Approve & Start Repair
            </button>
        </div>
      )}

    </div>
  );
};

export default PortalTicketCard;