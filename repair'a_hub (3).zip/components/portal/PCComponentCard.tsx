

import React from 'react';
import { PCComponent } from '../../types';

interface PCComponentCardProps {
  component: PCComponent;
  onSelect: (component: PCComponent) => void;
  isSelected: boolean;
}

const PCComponentCard: React.FC<PCComponentCardProps> = ({ component, onSelect, isSelected }) => {
  return (
    <div className={`bg-dark-panel-light rounded-lg p-4 flex flex-col justify-between border-2 transition-all ${isSelected ? 'border-brand-green' : 'border-transparent hover:border-dark-border'}`}>
      <div>
        <div className="aspect-square w-full bg-dark-bg rounded-md mb-4 flex items-center justify-center">
            <img src={component.imageUrl} alt={component.name} className="w-full h-full object-contain p-2" />
        </div>
        <h4 className="font-bold text-base text-dark-text-primary h-12">{component.name}</h4>
        <p className="text-xs text-dark-text-secondary mt-1 h-10">{component.specs}</p>
      </div>
      <div className="mt-4 flex justify-between items-center">
        <p className="text-lg font-bold text-brand-green">A${component.price.toFixed(2)}</p>
        <button
          onClick={() => onSelect(component)}
          className={`px-4 py-2 text-sm font-bold rounded-md transition-colors ${isSelected ? 'bg-dark-border text-dark-text-secondary cursor-not-allowed' : 'bg-dark-accent-blue hover:bg-blue-700 text-white'}`}
          disabled={isSelected}
        >
          {isSelected ? 'Selected' : 'Select'}
        </button>
      </div>
    </div>
  );
};

export default PCComponentCard;