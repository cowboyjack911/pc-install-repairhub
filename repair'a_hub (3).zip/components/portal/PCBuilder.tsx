

import React, { useState, useMemo, useEffect } from 'react';
import { PCComponent, PCBuildConfiguration } from '../../types';
import { PC_COMPONENTS } from '../../constants';
import CloseIcon from '../icons/CloseIcon';
import PCComponentCard from './PCComponentCard';
import ChevronRightIcon from '../icons/ChevronRightIcon';

interface PCBuilderProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (configuration: PCBuildConfiguration) => void;
}

const CATEGORIES: PCComponent['category'][] = ['CPU', 'Motherboard', 'RAM', 'Storage', 'GPU', 'Case', 'PSU'];

const PCBuilder: React.FC<PCBuilderProps> = ({ isOpen, onClose, onSubmit }) => {
  const [configuration, setConfiguration] = useState<PCBuildConfiguration>({});
  const [activeCategory, setActiveCategory] = useState<PCComponent['category']>(CATEGORIES[0]);

  useEffect(() => {
    // Reset state when modal is closed/opened
    if (isOpen) {
      setConfiguration({});
      setActiveCategory(CATEGORIES[0]);
    }
  }, [isOpen]);

  const totalPrice = useMemo(() => {
    return Object.values(configuration).reduce((sum, component) => sum + (component?.price || 0), 0);
  }, [configuration]);

  const handleSelectComponent = (component: PCComponent) => {
    setConfiguration(prev => ({
      ...prev,
      [component.category]: component,
    }));
  };
  
  const handleSubmit = () => {
    // Basic validation: ensure at least one component is selected.
    if (Object.keys(configuration).length === 0) {
        alert("Please select at least one component for your build.");
        return;
    }
    onSubmit(configuration);
  };
  
  if (!isOpen) return null;

  const componentsForActiveCategory = PC_COMPONENTS.filter(c => c.category === activeCategory);

  return (
    <div className="fixed inset-0 bg-dark-bg z-50 flex flex-col font-sans animate-fade-in">
      {/* Header */}
      <header className="flex-shrink-0 bg-dark-panel shadow-md p-4 flex justify-between items-center">
        <h2 className="text-xl md:text-2xl font-bold text-dark-text-primary">Build Your Custom PC</h2>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm text-dark-text-secondary">Estimated Total</p>
            <p className="text-2xl font-bold text-brand-green">A${totalPrice.toFixed(2)}</p>
          </div>
          <button onClick={onClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="w-7 h-7" /></button>
        </div>
      </header>
      
      {/* Main Content */}
      <div className="flex-grow flex overflow-hidden">
        {/* Left Sidebar: Categories & Summary */}
        <aside className="w-1/3 xl:w-1/4 bg-dark-panel p-4 overflow-y-auto flex flex-col justify-between">
            <div>
                <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Components</h3>
                <div className="space-y-2">
                    {CATEGORIES.map(category => {
                        const selectedComponent = configuration[category];
                        return (
                            <button key={category} onClick={() => setActiveCategory(category)} className={`w-full p-3 rounded-lg text-left transition-colors flex justify-between items-center ${activeCategory === category ? 'bg-dark-accent-blue/20 ring-1 ring-dark-accent-blue' : 'bg-dark-panel-light hover:bg-dark-border'}`}>
                                <div>
                                    <p className="font-semibold text-dark-text-primary">{category}</p>
                                    {selectedComponent ? (
                                        <p className="text-xs text-brand-green truncate">{selectedComponent.name}</p>
                                    ) : (
                                        <p className="text-xs text-dark-text-secondary">Select a component...</p>
                                    )}
                                </div>
                                <ChevronRightIcon className="w-5 h-5 text-dark-text-tertiary"/>
                            </button>
                        )
                    })}
                </div>
            </div>
            <button
                onClick={handleSubmit}
                className="w-full mt-6 bg-brand-green text-dark-bg font-bold py-3 rounded-lg hover:bg-brand-green-darker transition-colors"
            >
                Submit Build Request
            </button>
        </aside>

        {/* Right Content: Component Selection */}
        <main className="flex-1 p-6 overflow-y-auto">
          <h3 className="text-2xl font-bold text-dark-text-primary mb-6">Select a {activeCategory}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {componentsForActiveCategory.map(component => (
              <PCComponentCard 
                key={component.id} 
                component={component} 
                onSelect={handleSelectComponent}
                isSelected={configuration[activeCategory]?.id === component.id}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  );
};

export default PCBuilder;