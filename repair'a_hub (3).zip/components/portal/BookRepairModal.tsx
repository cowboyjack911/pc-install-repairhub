import React, { useState } from 'react';
import { Product } from '../../types';
import CloseIcon from '../icons/CloseIcon';
import ProductGrid from '../ProductGrid';

interface BookRepairModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onBookRepair: (repairData: { product: Product; deviceModel: string; issue: string }) => void;
}

const BookRepairModal: React.FC<BookRepairModalProps> = ({ isOpen, onClose, products, onBookRepair }) => {
  const [step, setStep] = useState(1);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [deviceModel, setDeviceModel] = useState('');
  const [issue, setIssue] = useState('');

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setStep(2);
  };

  const handleBack = () => {
    setStep(1);
    setSelectedProduct(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !deviceModel || !issue) {
      alert("Please fill in all fields.");
      return;
    }
    onBookRepair({ product: selectedProduct, deviceModel, issue });
    handleClose();
  };
  
  const handleClose = () => {
    setStep(1);
    setSelectedProduct(null);
    setDeviceModel('');
    setIssue('');
    onClose();
  }

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">
            {step === 1 ? 'Step 1: Select Service Type' : `Step 2: Details for ${selectedProduct?.name}`}
          </h2>
          <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        {step === 1 && (
          <main className="p-6 overflow-y-auto">
            <ProductGrid onProductSelect={handleProductSelect} />
          </main>
        )}

        {step === 2 && (
          <form onSubmit={handleSubmit}>
            <main className="p-6 space-y-4">
              <div>
                <label htmlFor="deviceModel" className="block text-sm font-medium text-dark-text-secondary">Device Model (e.g., iPhone 14 Pro)</label>
                <input
                  type="text"
                  id="deviceModel"
                  value={deviceModel}
                  onChange={(e) => setDeviceModel(e.target.value)}
                  className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
                  required
                />
              </div>
              <div>
                <label htmlFor="issue" className="block text-sm font-medium text-dark-text-secondary">Describe the issue</label>
                <textarea
                  id="issue"
                  rows={5}
                  value={issue}
                  onChange={(e) => setIssue(e.target.value)}
                  className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
                  required
                />
              </div>
            </main>
            <footer className="flex justify-between p-4 bg-dark-panel-light/50 rounded-b-2xl">
              <button
                type="button"
                onClick={handleBack}
                className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border"
              >
                Back
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
              >
                Submit Request
              </button>
            </footer>
          </form>
        )}
      </div>
    </div>
  );
};

export default BookRepairModal;
