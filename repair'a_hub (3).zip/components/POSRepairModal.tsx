
import React, { useState, useEffect, useMemo } from 'react';
import { Product, InventoryItem, CartItem, Manufacturer, DeviceModel, RepairType, UsedPart, DiagnosticResult, SuggestedPart } from '../types';
import { MANUFACTURERS_BY_CATEGORY, COMMON_REPAIR_TYPES } from '../constants';
import { getAIDiagnosis } from '../services/geminiService';
import CloseIcon from './icons/CloseIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import ItemGrid from './ItemGrid';
import PartSelector from './PartSelector';
import AIIcon from './icons/AIIcon';
import AIDiagnosisResult from './AIDiagnosisResult';
import PhoneIcon from './icons/PhoneIcon';

interface POSRepairModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  inventoryItems: InventoryItem[];
  onAddToCart: (item: CartItem) => void;
}

type Step = 'manufacturer' | 'model' | 'details';

const POSRepairModal: React.FC<POSRepairModalProps> = ({ isOpen, onClose, product, inventoryItems, onAddToCart }) => {
  const [step, setStep] = useState<Step>('manufacturer');
  const [selectedManufacturer, setSelectedManufacturer] = useState<Manufacturer | null>(null);
  const [selectedModel, setSelectedModel] = useState<DeviceModel | null>(null);
  const [issue, setIssue] = useState('');
  const [price, setPrice] = useState('0');
  const [usedParts, setUsedParts] = useState<UsedPart[]>([]);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState<DiagnosticResult | null>(null);
  const [addedPartSKUs, setAddedPartSKUs] = useState<Set<string>>(new Set());

  const manufacturers = useMemo(() => {
    if (!product) return [];
    return MANUFACTURERS_BY_CATEGORY[product.id] || [];
  }, [product]);

  useEffect(() => {
    if (isOpen) {
      setStep('manufacturer');
      setSelectedManufacturer(null);
      setSelectedModel(null);
      setIssue('');
      setPrice('0');
      setUsedParts([]);
      setDiagnosisResult(null);
      setAddedPartSKUs(new Set());
    }
  }, [isOpen]);
  
  const handleSelectManufacturer = (man: Manufacturer) => {
    setSelectedManufacturer(man);
    setStep('model');
  };

  const handleSelectModel = (mod: DeviceModel) => {
    setSelectedModel(mod);
    setStep('details');
  };
  
  const handleSelectRepairType = (repair: RepairType) => {
    setPrice(repair.basePrice.toFixed(2));
    if (!issue.includes(repair.name)) {
        setIssue(prev => prev ? `${prev}, ${repair.name}` : repair.name);
    }
  };

  const handleRunDiagnosis = async () => {
    if (!selectedModel || !issue) return;
    setIsDiagnosing(true);
    setDiagnosisResult(null);
    try {
        const result = await getAIDiagnosis(selectedModel.name, issue, inventoryItems);
        setDiagnosisResult(result);
    } catch(err) {
        alert("Failed to get AI Diagnosis. Please check console for details.");
        console.error(err);
    } finally {
        setIsDiagnosing(false);
    }
  };

  const handleAddPartFromAI = (part: SuggestedPart) => {
    const inventoryItem = inventoryItems.find(i => i.sku === part.sku);
    if (inventoryItem && !addedPartSKUs.has(part.sku)) {
        const newPart: UsedPart = {
            itemId: inventoryItem.id,
            name: inventoryItem.name,
            sku: inventoryItem.sku,
            quantityUsed: 1,
            cost: inventoryItem.cost
        };
        setUsedParts(prev => [...prev, newPart]);
        setAddedPartSKUs(prev => new Set(prev).add(part.sku));
    }
  };

  const handlePartsChange = (newParts: UsedPart[]) => {
      setUsedParts(newParts);
      setAddedPartSKUs(new Set(newParts.map(p => p.sku)));
  };

  const handleAddToCart = () => {
    if (!product || !selectedManufacturer || !selectedModel || !issue) {
      alert("Please complete all repair details.");
      return;
    }

    const numericPrice = parseFloat(price);
    if (isNaN(numericPrice) || numericPrice < 0) {
      alert("Please enter a valid price.");
      return;
    }
    
    const totalCost = usedParts.reduce((sum, part) => sum + (part.cost * part.quantityUsed), 0);

    const cartItem: CartItem = {
      ...product,
      cartItemId: crypto.randomUUID(),
      name: `${selectedModel.name} Repair`,
      quantity: 1,
      unitPrice: numericPrice,
      cost: totalCost,
      tax: 0, // Will be calculated in POSView
      deviceMake: selectedManufacturer.name,
      deviceModel: selectedModel.name,
      issue,
      usedParts,
      icon: product.icon || PhoneIcon
    };

    onAddToCart(cartItem);
  };
  
  const renderContent = () => {
      switch(step) {
          case 'manufacturer':
              return <ItemGrid items={manufacturers} onItemSelect={handleSelectManufacturer} />;
          case 'model':
              return <ItemGrid items={selectedManufacturer?.models || []} onItemSelect={handleSelectModel} />;
          case 'details':
              return (
                  <div className="space-y-6">
                     <div>
                        <label htmlFor="issue" className="block text-sm font-medium text-dark-text-secondary">Issue Description</label>
                        <textarea id="issue" rows={3} value={issue} onChange={e => setIssue(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green" />
                        <button type="button" onClick={handleRunDiagnosis} disabled={!issue || isDiagnosing} className="mt-2 flex items-center justify-center gap-2 text-sm bg-brand-green hover:bg-brand-green-darker text-dark-bg font-bold py-2 px-3 rounded-lg disabled:bg-gray-500 disabled:cursor-wait">
                            <AIIcon className="h-4 w-4" />
                            {isDiagnosing ? 'Analyzing...' : 'Run AI Diagnosis'}
                        </button>
                        {diagnosisResult && <AIDiagnosisResult result={diagnosisResult} onAddPart={handleAddPartFromAI} addedPartSKUs={addedPartSKUs} />}
                    </div>
                    <PartSelector inventory={inventoryItems} selectedParts={usedParts} onPartsChange={handlePartsChange} />
                    <div>
                        <h3 className="text-lg font-semibold text-dark-text-primary mb-2">Common Repairs</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                            {COMMON_REPAIR_TYPES.map(r => (
                                <button key={r.id} onClick={() => handleSelectRepairType(r)} className="p-2 text-center text-sm bg-dark-panel-light rounded-md hover:bg-dark-border">
                                    <span className="font-semibold">{r.name}</span>
                                    <br/>
                                    <span className="text-xs text-brand-green">${r.basePrice.toFixed(2)}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="price" className="block text-sm font-medium text-dark-text-secondary">Repair Price ($)</label>
                        <input type="number" step="0.01" id="price" value={price} onChange={e => setPrice(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green" />
                    </div>
                  </div>
              )
      }
  }

  const handleBack = () => {
      if (step === 'details') setStep('model');
      if (step === 'model') setStep('manufacturer');
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border flex-shrink-0">
            <div className="flex items-center gap-2 text-dark-text-primary">
                <button onClick={() => setStep('manufacturer')} className="font-bold text-xl hover:text-brand-green">{product?.name}</button>
                {selectedManufacturer && <><ChevronRightIcon className="w-5 h-5" /><button onClick={() => setStep('model')} className="hover:text-brand-green">{selectedManufacturer.name}</button></>}
                {selectedModel && <><ChevronRightIcon className="w-5 h-5" /><span className="text-dark-text-secondary">{selectedModel.name}</span></>}
            </div>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
        </header>
        <main className="p-6 overflow-y-auto flex-grow">
            {renderContent()}
        </main>
        <footer className="flex justify-between items-center p-4 bg-dark-panel-light/50 rounded-b-2xl flex-shrink-0">
            <button onClick={handleBack} disabled={step === 'manufacturer'} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border disabled:opacity-50 disabled:cursor-not-allowed">Back</button>
            <button onClick={handleAddToCart} disabled={step !== 'details'} className="px-6 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker disabled:bg-gray-500 disabled:cursor-not-allowed">Add to Cart</button>
        </footer>
      </div>
    </div>
  );
};

export default POSRepairModal;
