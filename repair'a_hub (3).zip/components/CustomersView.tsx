

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Customer, Ticket, Omit } from '../types';
import PlusIcon from './icons/PlusIcon';
import SearchIcon from './icons/SearchIcon';
import PencilIcon from './icons/PencilIcon';
import TrashIcon from './icons/TrashIcon';
import CustomerAddModal from './CustomerAddModal';
import GiftIcon from './icons/GiftIcon';
import StoreCreditModal from './StoreCreditModal';

interface CustomersViewProps {
  customers: Customer[];
  tickets: Ticket[];
  onAddNewCustomer: (customerData: Omit<Customer, 'id'>) => Customer;
  onUpdateCustomer: (customer: Customer) => void;
  onDeleteCustomer: (customerId: string) => void;
}

const CustomersView: React.FC<CustomersViewProps> = ({ customers, tickets, onAddNewCustomer, onUpdateCustomer, onDeleteCustomer }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreditModalOpen, setIsCreditModalOpen] = useState(false);
  const [creditingCustomer, setCreditingCustomer] = useState<Customer | null>(null);


  const customerTicketCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    tickets.forEach(ticket => {
      counts[ticket.customer.id] = (counts[ticket.customer.id] || 0) + 1;
    });
    return counts;
  }, [tickets]);

  const filteredCustomers = useMemo(() => {
    if (!searchTerm) return customers.filter(c => c.id !== 'cust_walkin');
    return customers.filter(
      c =>
        c.id !== 'cust_walkin' &&
        (c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.email?.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [customers, searchTerm]);

  const handleOpenModal = (customer: Customer | null = null) => {
    setEditingCustomer(customer);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingCustomer(null);
    setIsModalOpen(false);
  };

  const handleSaveCustomer = (customerData: Omit<Customer, 'id'> | Customer) => {
    if ('id' in customerData) {
      onUpdateCustomer(customerData);
    } else {
      onAddNewCustomer(customerData);
    }
    handleCloseModal();
  };

  const handleOpenCreditModal = (customer: Customer) => {
    setCreditingCustomer(customer);
    setIsCreditModalOpen(true);
  };

  const handleCloseCreditModal = () => {
    setCreditingCustomer(null);
    setIsCreditModalOpen(false);
  };

  const handleSaveCredit = (customer: Customer, newBalance: number) => {
    onUpdateCustomer({ ...customer, storeCredit: newBalance });
    handleCloseCreditModal();
  };

  return (
    <>
      <div>
        {/* Header */}
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>
            {/* Title handled by StaffHeader */}
          </div>
          <div className="flex items-center gap-4 mt-4 sm:mt-0">
            <button
              onClick={() => handleOpenModal()}
              className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
              type="button"
            >
              <PlusIcon className="w-5 h-5" />
              <span className="text-sm font-medium">Add New Customer</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by name, phone, or email..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-72 focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        {/* Customer Table */}
        <div className="mt-4 overflow-x-auto">
          <div className="align-middle inline-block min-w-full">
            <div className="shadow overflow-hidden border-b border-dark-border rounded-lg">
              <table className="min-w-full divide-y divide-dark-border">
                <thead className="bg-dark-panel">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Contact</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total Tickets</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Store Credit</th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-dark-panel-light divide-y divide-dark-border">
                  {filteredCustomers.map((customer) => (
                    <tr key={customer.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-dark-text-primary">{customer.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">
                        <div>{customer.phone}</div>
                        <div>{customer.email}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{customerTicketCounts[customer.id] || 0}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">${(customer.storeCredit || 0).toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                        <button onClick={() => handleOpenCreditModal(customer)} className="text-brand-green hover:text-brand-green-darker" aria-label="Adjust Store Credit"><GiftIcon className="w-5 h-5"/></button>
                        <button onClick={() => handleOpenModal(customer)} className="text-dark-accent-blue hover:text-blue-400" aria-label="Edit Customer"><PencilIcon className="w-5 h-5"/></button>
                        <button onClick={() => onDeleteCustomer(customer.id)} className="text-red-400 hover:text-red-300" aria-label="Delete Customer"><TrashIcon className="w-5 h-5"/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {filteredCustomers.length === 0 && (
          <div className="text-center py-16 bg-dark-panel rounded-lg mt-4">
            <h3 className="text-xl font-medium text-dark-text-primary">No customers found.</h3>
            <p className="mt-2 text-base text-dark-text-secondary">
              Click "Add New Customer" to get started or try a different search term.
            </p>
          </div>
        )}
      </div>
      <CustomerAddModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSaveCustomer}
        editingCustomer={editingCustomer}
      />
      <StoreCreditModal
        isOpen={isCreditModalOpen}
        onClose={handleCloseCreditModal}
        onSave={handleSaveCredit}
        customer={creditingCustomer}
      />
    </>
  );
};

export default CustomersView;