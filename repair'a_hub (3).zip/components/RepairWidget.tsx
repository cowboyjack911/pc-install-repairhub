
import React, { useState, useEffect, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Customer, Product, InventoryItem, CartItem, Ticket, TicketStatus, Omit, Manufacturer, DeviceModel, UsedPart, DiagnosticResult, SuggestedPart, RepairType } from '../types';
import { PRODUCTS, MANUFACTURERS_BY_CATEGORY, COMMON_REPAIR_TYPES } from '../constants';
import { getAIDiagnosis } from '../services/geminiService';
import CloseIcon from './icons/CloseIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import ItemGrid from './ItemGrid';
import PartSelector from './PartSelector';
import AIIcon from './icons/AIIcon';
import AIDiagnosisResult from './AIDiagnosisResult';
import PhoneIcon from './icons/PhoneIcon';
import SearchIcon from './icons/SearchIcon';
import UserIcon from './icons/UserIcon';
import PlusIcon from './icons/PlusIcon';
import ChevronLeftIcon from './icons/ChevronLeftIcon';

interface RepairWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (ticket: Ticket) => void;
  customers: Customer[];
  onAddNewCustomer: (customerData: Omit<Customer, 'id'>) => Customer;
  inventoryItems: InventoryItem[];
}

type Step = 'customer' | 'productType' | 'manufacturer' | 'model' | 'details';

const RepairWidget: React.FC<RepairWidgetProps> = ({ isOpen, onClose, onSave, customers, onAddNewCustomer, inventoryItems }) => {
  const [step, setStep] = useState<Step>('customer');
  
  // Customer state
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isNewCustomerForm, setIsNewCustomerForm] = useState(false);
  const [customerSearch, setCustomerSearch] = useState('');
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerEmail, setNewCustomerEmail] = useState('');

  // Repair state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedManufacturer, setSelectedManufacturer] = useState<Manufacturer | null>(null);
  const [selectedModel, setSelectedModel] = useState<DeviceModel | null>(null);
  const [issue, setIssue] = useState('');
  const [price, setPrice] = useState('0');
  const [usedParts, setUsedParts] = useState<UsedPart[]>([]);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState<DiagnosticResult | null>(null);
  const [addedPartSKUs, setAddedPartSKUs] = useState<Set<string>>(new Set());

  const filteredCustomers = useMemo(() => {
    if (!customerSearch) return [];
    return customers.filter(c => 
        c.id !== 'cust_walkin' && (
            c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
            c.phone?.includes(customerSearch)
        )
    ).slice(0, 5);
  }, [customerSearch, customers]);

  const manufacturers = useMemo(() => {
    if (!selectedProduct) return [];
    return MANUFACTURERS_BY_CATEGORY[selectedProduct.id] || [];
  }, [selectedProduct]);

  const resetState = () => {
    setStep('customer');
    setSelectedCustomer(null);
    setIsNewCustomerForm(false);
    setCustomerSearch('');
    setNewCustomerName('');
    setNewCustomerPhone('');
    setNewCustomerEmail('');
    setSelectedProduct(null);
    setSelectedManufacturer(null);
    setSelectedModel(null);
    setIssue('');
    setPrice('0');
    setUsedParts([]);
    setDiagnosisResult(null);
    setAddedPartSKUs(new Set());
    setIsDiagnosing(false);
  };
  
  useEffect(() => {
    if (isOpen) {
        resetState();
    }
  }, [isOpen]);

  const handleBackStep = () => {
    if (step === 'productType') {
      setSelectedCustomer(null);
      setStep('customer');
    }
    if (step === 'manufacturer') {
      setSelectedProduct(null);
      setStep('productType');
    }
    if (step === 'model') {
      setSelectedManufacturer(null);
      setStep('manufacturer');
    }
    if (step === 'details') {
      setSelectedModel(null);
      setStep('model');
    }
  };
  
  const handleCustomerSelect = (customer: Customer) => {
    setSelectedCustomer(customer);
    setCustomerSearch('');
    setStep('productType');
  };

  const handleAddNewCustomer = () => {
    if (!newCustomerName.trim()) {
        alert("Customer name is required.");
        return;
    }
    const newCustomer = onAddNewCustomer({
        name: newCustomerName,
        phone: newCustomerPhone,
        email: newCustomerEmail
    });
    handleCustomerSelect(newCustomer);
  };
  
  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
    setStep('manufacturer');
  };

  const handleManufacturerSelect = (man: Manufacturer) => {
    setSelectedManufacturer(man);
    setStep('model');
  };

  const handleModelSelect = (mod: DeviceModel) => {
    setSelectedModel(mod);
    setStep('details');
  };

  const handleSelectRepairType = (repair: RepairType) => {
    setPrice(repair.basePrice.toFixed(2));
    if (!issue.includes(repair.name)) {
        setIssue(prev => prev ? `${prev}, ${repair.name}` : repair.name);
    }
  };
  
  const handleRunDiagnosis = async () => {
    if (!selectedModel || !issue) return;
    setIsDiagnosing(true);
    setDiagnosisResult(null);
    try {
        const result = await getAIDiagnosis(selectedModel.name, issue, inventoryItems);
        setDiagnosisResult(result);
    } catch(err) {
        alert("Failed to get AI Diagnosis. Please check console for details.");
        console.error(err);
    } finally {
        setIsDiagnosing(false);
    }
  };

  const handleAddPartFromAI = (part: SuggestedPart) => {
    const inventoryItem = inventoryItems.find(i => i.sku === part.sku);
    if (inventoryItem && !addedPartSKUs.has(part.sku)) {
        const newPart: UsedPart = {
            itemId: inventoryItem.id,
            name: inventoryItem.name,
            sku: inventoryItem.sku,
            quantityUsed: 1,
            cost: inventoryItem.cost
        };
        setUsedParts(prev => [...prev, newPart]);
        setAddedPartSKUs(prev => new Set(prev).add(part.sku));
    }
  };

  const handlePartsChange = (newParts: UsedPart[]) => {
      setUsedParts(newParts);
      setAddedPartSKUs(new Set(newParts.map(p => p.sku)));
  };

  const handleCreateTicket = () => {
    if (!selectedCustomer || !selectedProduct || !selectedModel || !issue) {
        alert("Please ensure a customer is selected and all repair details are filled out.");
        return;
    }
    const numericPrice = parseFloat(price);
    if (isNaN(numericPrice)) {
      alert("Please enter a valid price.");
      return;
    }
    const totalCost = usedParts.reduce((sum, part) => sum + (part.cost * part.quantityUsed), 0);

    const cartItem: CartItem = {
      ...selectedProduct,
      cartItemId: crypto.randomUUID(),
      name: `${selectedModel.name} Repair`,
      quantity: 1,
      unitPrice: numericPrice,
      cost: totalCost,
      tax: 0, 
      deviceMake: selectedManufacturer?.name,
      deviceModel: selectedModel.name,
      issue,
      usedParts,
      icon: selectedProduct.icon || PhoneIcon
    };

    const newTicket: Ticket = {
        id: `tkt_${crypto.randomUUID()}`,
        customer: selectedCustomer,
        items: [cartItem],
        status: numericPrice > 0 ? TicketStatus.QUOTE_PENDING : TicketStatus.NEW,
        subtotal: numericPrice,
        discount: 0,
        tax: 0,
        total: numericPrice,
        totalCost,
        createdAt: new Date(),
        notes: [],
      };
      
    onSave(newTicket);
    onClose();
  };

  const renderContent = () => {
    switch(step) {
        case 'customer':
            return (
                <div>
                    <div className="flex rounded-md shadow-sm mb-4" role="group">
                        <button onClick={() => setIsNewCustomerForm(false)} className={`w-1/2 py-2 px-4 text-sm font-medium border rounded-l-lg ${!isNewCustomerForm ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border'}`}>Existing Customer</button>
                        <button onClick={() => setIsNewCustomerForm(true)} className={`w-1/2 py-2 px-4 text-sm font-medium border rounded-r-lg ${isNewCustomerForm ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border'}`}>New Customer</button>
                    </div>
                    {isNewCustomerForm ? (
                        <div className="space-y-4">
                            <input type="text" placeholder="Full Name*" value={newCustomerName} onChange={e => setNewCustomerName(e.target.value)} className="w-full bg-dark-bg border-dark-border rounded-md shadow-sm" />
                            <input type="text" placeholder="Phone Number" value={newCustomerPhone} onChange={e => setNewCustomerPhone(e.target.value)} className="w-full bg-dark-bg border-dark-border rounded-md shadow-sm" />
                            <input type="email" placeholder="Email Address" value={newCustomerEmail} onChange={e => setNewCustomerEmail(e.target.value)} className="w-full bg-dark-bg border-dark-border rounded-md shadow-sm" />
                            <button onClick={handleAddNewCustomer} className="w-full bg-dark-accent-blue text-white font-bold py-2 px-4 rounded-md">Add Customer & Continue</button>
                        </div>
                    ) : (
                        <div>
                            <div className="relative">
                                <SearchIcon className="h-5 w-5 text-dark-text-tertiary absolute left-3 top-1/2 -translate-y-1/2" />
                                <input type="text" placeholder="Search by name or phone..." value={customerSearch} onChange={e => setCustomerSearch(e.target.value)} className="w-full bg-dark-bg border-dark-border rounded-md pl-10 pr-4 py-2 text-sm" />
                            </div>
                            <div className="mt-2 max-h-60 overflow-y-auto">
                                {filteredCustomers.map(c => (
                                    <button key={c.id} onClick={() => handleCustomerSelect(c)} className="w-full text-left flex items-center p-3 hover:bg-dark-panel-light rounded-lg">
                                        <UserIcon className="w-6 h-6 mr-3 text-dark-text-secondary" />
                                        <div>
                                            <p className="font-medium text-dark-text-primary">{c.name}</p>
                                            <p className="text-sm text-dark-text-tertiary">{c.phone}</p>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            );
        case 'productType':
            return <ItemGrid items={PRODUCTS} onItemSelect={handleProductSelect} />;
        case 'manufacturer':
            return <ItemGrid items={manufacturers} onItemSelect={handleSelectManufacturer} />;
        case 'model':
            return <ItemGrid items={selectedManufacturer?.models || []} onItemSelect={handleModelSelect} />;
        case 'details':
            return (
                <div className="space-y-4">
                   <div>
                      <label htmlFor="issue" className="block text-sm font-medium text-dark-text-secondary">Issue Description</label>
                      <textarea id="issue" rows={3} value={issue} onChange={e => setIssue(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" />
                      <button type="button" onClick={handleRunDiagnosis} disabled={!issue || isDiagnosing} className="mt-2 flex items-center gap-2 text-sm bg-brand-green text-dark-bg font-bold py-2 px-3 rounded-lg disabled:bg-gray-500">
                          <AIIcon className="h-4 w-4" />
                          {isDiagnosing ? 'Analyzing...' : 'Run AI Diagnosis'}
                      </button>
                      {diagnosisResult && <AIDiagnosisResult result={diagnosisResult} onAddPart={handleAddPartFromAI} addedPartSKUs={addedPartSKUs} />}
                  </div>
                  <PartSelector inventory={inventoryItems} selectedParts={usedParts} onPartsChange={handlePartsChange} />
                   <div>
                        <h3 className="text-lg font-semibold text-dark-text-primary mb-2">Common Repairs</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                            {COMMON_REPAIR_TYPES.map(r => (
                                <button key={r.id} onClick={() => handleSelectRepairType(r)} className="p-2 text-center text-sm bg-dark-panel-light rounded-md hover:bg-dark-border">
                                    <span className="font-semibold">{r.name}</span><br/><span className="text-xs text-brand-green">${r.basePrice.toFixed(2)}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                  <div>
                      <label htmlFor="price" className="block text-sm font-medium text-dark-text-secondary">Repair Price ($)</label>
                      <input type="number" step="0.01" id="price" value={price} onChange={e => setPrice(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm" />
                  </div>
                </div>
            );
    }
  };
  
  const stepTitles: Record<Step, string> = {
    customer: 'Select Customer',
    productType: 'Select Service',
    manufacturer: 'Select Manufacturer',
    model: 'Select Model',
    details: 'Enter Details'
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border flex-shrink-0">
            <div className="flex items-center gap-2 text-dark-text-primary">
                <h2 className="font-bold text-xl">{stepTitles[step]}</h2>
                <div className="flex items-center text-sm text-dark-text-secondary">
                    {selectedCustomer && <><ChevronRightIcon className="w-5 h-5" /><span>{selectedCustomer.name}</span></>}
                    {selectedProduct && <><ChevronRightIcon className="w-5 h-5" /><span>{selectedProduct.name}</span></>}
                    {selectedManufacturer && <><ChevronRightIcon className="w-5 h-5" /><span>{selectedManufacturer.name}</span></>}
                    {selectedModel && <><ChevronRightIcon className="w-5 h-5" /><span>{selectedModel.name}</span></>}
                </div>
            </div>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white"><CloseIcon className="h-6 w-6" /></button>
        </header>
        <main className="p-6 overflow-y-auto flex-grow">
            {renderContent()}
        </main>
        <footer className="flex justify-between items-center p-4 bg-dark-panel-light/50 rounded-b-2xl flex-shrink-0">
            <button onClick={handleBackStep} disabled={step === 'customer'} className="flex items-center gap-1 px-4 py-2 text-sm font-medium rounded-md hover:bg-dark-border disabled:opacity-50">
              <ChevronLeftIcon className="w-4 h-4" /> Back
            </button>
            {step === 'details' && (
                <button onClick={handleCreateTicket} className="px-6 py-2 text-sm font-bold text-dark-bg bg-brand-green rounded-md hover:bg-brand-green-darker">Create Ticket</button>
            )}
        </footer>
      </div>
    </div>
  );
};

export default RepairWidget;