import React from 'react';
import { CartItem } from '../types';
import TrashIcon from './icons/TrashIcon';

interface CartItemDisplayProps {
  item: CartItem;
  onRemove: (cartItemId: string) => void;
}

const CartItemDisplay: React.FC<CartItemDisplayProps> = ({ item, onRemove }) => {
  const total = item.unitPrice * item.quantity + item.tax;

  return (
    <div className="grid grid-cols-12 items-center text-sm py-2 hover:bg-dark-panel-light -mx-4 px-4 rounded-md">
      <div className="col-span-1 text-dark-text-primary font-medium">{item.quantity}</div>
      <div className="col-span-5 text-dark-text-primary font-medium truncate">{item.name}</div>
      <div className="col-span-2 text-right text-dark-text-secondary">${item.unitPrice.toFixed(2)}</div>
      <div className="col-span-2 text-right text-dark-text-secondary">${item.tax.toFixed(2)}</div>
      <div className="col-span-1 text-right text-dark-text-primary font-semibold">${total.toFixed(2)}</div>
      <div className="col-span-1 text-right">
        <button 
            onClick={() => onRemove(item.cartItemId)} 
            className="text-red-400/70 hover:text-red-400"
            aria-label="Remove item"
        >
            <TrashIcon className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default CartItemDisplay;