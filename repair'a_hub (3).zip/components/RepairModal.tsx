
import React from 'react';

// This component is no longer used by the new integrated repair wizard.
// Its functionality has been redesigned and moved into `BookingView.tsx`.
const RepairModal: React.FC = () => null;

export default RepairModal;
