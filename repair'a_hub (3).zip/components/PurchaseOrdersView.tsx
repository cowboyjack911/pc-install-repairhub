

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { PurchaseOrder, POStatus, Omit, Supplier, InventoryItem } from '../types';
import PlusIcon from './icons/PlusIcon';
import SearchIcon from './icons/SearchIcon';
import { PO_STATUS_COLORS } from '../constants';
import PurchaseOrderModal from './PurchaseOrderModal';
import ReceivePOModal from './ReceivePOModal';

interface PurchaseOrdersViewProps {
  purchaseOrders: PurchaseOrder[];
  suppliers: Supplier[];
  inventoryItems: InventoryItem[];
  onAddPurchaseOrder: (poData: Omit<PurchaseOrder, 'id'>) => void;
  onReceiveItems: (poId: string, receivedQuantities: Record<string, number>) => void;
}

const POStatusBadge: React.FC<{ status: POStatus }> = ({ status }) => {
  const colorClass = PO_STATUS_COLORS[status] || 'bg-gray-500/20 text-gray-300';
  return (
    <span className={`px-2 py-1 text-xs font-medium rounded-full ${colorClass}`}>
      {status}
    </span>
  );
};

const PurchaseOrdersView: React.FC<PurchaseOrdersViewProps> = ({ purchaseOrders, suppliers, inventoryItems, onAddPurchaseOrder, onReceiveItems }) => {
  const [isPOModalOpen, setIsPOModalOpen] = useState(false);
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false);
  const [receivingPO, setReceivingPO] = useState<PurchaseOrder | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPOs = useMemo(() => {
    if (!searchTerm) return purchaseOrders;
    return purchaseOrders.filter(
      po =>
        po.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        po.supplier.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [purchaseOrders, searchTerm]);

  const handleOpenReceiveModal = (po: PurchaseOrder) => {
    setReceivingPO(po);
    setIsReceiveModalOpen(true);
  };
  
  return (
    <>
      <div>
        {/* Header */}
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>{/* Title handled by StaffHeader */}</div>
          <div className="flex items-center gap-4 mt-4 sm:mt-0">
            <button
              onClick={() => setIsPOModalOpen(true)}
              className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
              type="button"
            >
              <PlusIcon className="w-5 h-5" />
              <span className="text-sm font-medium">New Purchase Order</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by PO number or supplier..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-72 focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        {/* PO Table */}
        <div className="mt-4 overflow-x-auto">
          <div className="align-middle inline-block min-w-full">
            <div className="shadow overflow-hidden border-b border-dark-border rounded-lg">
              <table className="min-w-full divide-y divide-dark-border">
                <thead className="bg-dark-panel">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">PO #</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Supplier</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Date</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total</th>
                    <th scope="col" className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody className="bg-dark-panel-light divide-y divide-dark-border">
                  {filteredPOs.map((po) => (
                    <tr key={po.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-dark-text-primary">{po.id.substring(0, 8)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{po.supplier.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary"><POStatusBadge status={po.status} /></td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{po.createdAt.toLocaleDateString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">${po.totalCost.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                        {(po.status === POStatus.ORDERED || po.status === POStatus.PARTIALLY_RECEIVED) && (
                           <button onClick={() => handleOpenReceiveModal(po)} className="text-brand-green font-semibold hover:text-brand-green-darker">Receive</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {filteredPOs.length === 0 && (
          <div className="text-center py-16 bg-dark-panel rounded-lg mt-4">
            <h3 className="text-xl font-medium text-dark-text-primary">No purchase orders found.</h3>
            <p className="mt-2 text-base text-dark-text-secondary">
              Click "New Purchase Order" to get started.
            </p>
          </div>
        )}
      </div>
      <PurchaseOrderModal
        isOpen={isPOModalOpen}
        onClose={() => setIsPOModalOpen(false)}
        suppliers={suppliers}
        inventoryItems={inventoryItems}
        onSave={onAddPurchaseOrder}
      />
      <ReceivePOModal
        isOpen={isReceiveModalOpen}
        onClose={() => setIsReceiveModalOpen(false)}
        purchaseOrder={receivingPO}
        onReceive={onReceiveItems}
      />
    </>
  );
};

export default PurchaseOrdersView;