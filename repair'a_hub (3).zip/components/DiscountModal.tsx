
import React, { useState, useEffect } from 'react';
import { Discount } from '../types';
import CloseIcon from './icons/CloseIcon';

interface DiscountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyDiscount: (discount: Discount) => void;
  currentDiscount: Discount;
}

const DiscountModal: React.FC<DiscountModalProps> = ({ isOpen, onClose, onApplyDiscount, currentDiscount }) => {
  const [type, setType] = useState<'percentage' | 'fixed'>(currentDiscount?.type || 'percentage');
  const [value, setValue] = useState<string>(currentDiscount?.value.toString() || '');

  useEffect(() => {
    if (isOpen) {
        setType(currentDiscount?.type || 'percentage');
        setValue(currentDiscount?.value.toString() || '');
    }
  }, [isOpen, currentDiscount]);

  const handleApply = () => {
    const numericValue = parseFloat(value);
    if (isNaN(numericValue) || numericValue < 0) {
      alert("Please enter a valid, non-negative discount value.");
      return;
    }
    onApplyDiscount({ type, value: numericValue });
  };

  const handleRemove = () => {
    onApplyDiscount(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-sm">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Apply Discount</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6">
          <div className="flex rounded-md shadow-sm mb-4" role="group">
            <button
              type="button"
              onClick={() => setType('percentage')}
              className={`px-4 py-2 text-sm font-medium border rounded-l-lg transition-colors ${type === 'percentage' ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border hover:bg-dark-panel-light'}`}
            >
              Percentage (%)
            </button>
            <button
              type="button"
              onClick={() => setType('fixed')}
              className={`px-4 py-2 text-sm font-medium border rounded-r-lg transition-colors ${type === 'fixed' ? 'bg-brand-green text-dark-bg border-brand-green' : 'bg-dark-bg text-white border-dark-border hover:bg-dark-panel-light'}`}
            >
              Fixed Amount ($)
            </button>
          </div>

          <div>
            <label htmlFor="discountValue" className="sr-only">Discount Value</label>
            <input
              type="number"
              id="discountValue"
              value={value}
              onChange={e => setValue(e.target.value)}
              className="block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
              placeholder="e.g., 10 or 15.50"
              step="0.01"
              min="0"
              autoFocus
            />
          </div>
        </main>
        
        <footer className="flex justify-between items-center p-4 bg-dark-panel-light/50 rounded-b-2xl">
            <div>
              {currentDiscount && (
                <button
                  onClick={handleRemove}
                  className="px-4 py-2 text-sm font-medium text-red-400 hover:text-red-300"
                >
                  Remove Discount
                </button>
              )}
            </div>
            <div className="space-x-3">
                 <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-sm font-medium text-dark-text-primary"
                >
                    Cancel
                </button>
                <button
                    onClick={handleApply}
                    className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
                >
                    Apply Discount
                </button>
            </div>
        </footer>
      </div>
    </div>
  );
};

export default DiscountModal;