

import React, { useState } from 'react';
// FIX: Import User type
import { Ticket, TicketStatus, Note, User } from '../types';
import { STATUS_OPTIONS } from '../constants';
import StatusBadge from './StatusBadge';
import RepairSuggester from './RepairSuggester';
import AIIcon from './icons/AIIcon';
import ChatBubbleLeftRightIcon from './icons/ChatBubbleLeftRightIcon';
import PrinterIcon from './icons/PrinterIcon';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';

interface TicketItemProps {
  ticket: Ticket;
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
  onAddQuote: (ticketId: string) => void;
  onAddNote: (ticketId: string, noteContent: string) => void;
  onPrintTicket: (ticket: Ticket) => void;
  onSendMessage: (ticket: Ticket) => void;
  // FIX: Add props for technician assignment
  user: User;
  technicians: User[];
  onAssignTechnician: (ticketId: string, technicianId: string) => void;
}

const TicketItem: React.FC<TicketItemProps> = ({ ticket, onUpdateStatus, onAddQuote, onAddNote, onPrintTicket, onSendMessage, user, technicians, onAssignTechnician }) => {
  const [isSuggesterOpen, setIsSuggesterOpen] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [newNote, setNewNote] = useState('');

  const firstItem = ticket.items[0];
  const isNew = ticket.status === TicketStatus.NEW;
  const isCompleted = ticket.status === TicketStatus.COMPLETED;

  const profit = ticket.total - ticket.tax - ticket.totalCost;

  const handleAddNote = () => {
    if (newNote.trim()) {
        onAddNote(ticket.id, newNote.trim());
        setNewNote('');
    }
  };
  
  return (
    <>
      <div className="bg-dark-panel-light rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 mb-4">
        <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-start">
              {/* Customer & Device Info */}
              <div className="md:col-span-2">
                <p className="font-bold text-lg text-dark-text-primary">{ticket.customer.name}</p>
                <p className="text-sm text-dark-text-secondary">{firstItem ? firstItem.name : 'N/A'}</p>
                <p className="text-xs text-dark-text-tertiary mt-1">
                  Ticket #{ticket.id.substring(0, 8)} | Created: {ticket.createdAt.toLocaleDateString()}
                </p>
                 {isCompleted && (
                    <p className={`text-sm font-bold mt-2 ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        Profit: ${profit.toFixed(2)}
                    </p>
                )}
              </div>
              
              {/* Issue Description */}
              <div className="md:col-span-2">
                 <p className="text-sm text-dark-text-primary">{firstItem ? firstItem.issue : 'No issue description.'}</p>
              </div>

              {/* Status & Actions */}
              <div className="md:col-span-1 flex flex-col items-start md:items-end gap-3">
                 <StatusBadge status={ticket.status} />
                 {isNew ? (
                    <button
                        onClick={() => onAddQuote(ticket.id)}
                        className="mt-2 w-full text-sm bg-dark-accent-blue hover:bg-blue-700 text-white font-bold py-2 px-3 rounded-lg transition-colors"
                    >
                        Add Quote
                    </button>
                 ) : (
                    <select
                        value={ticket.status}
                        onChange={(e) => onUpdateStatus(ticket.id, e.target.value as TicketStatus)}
                        disabled={isCompleted}
                        className="mt-2 w-full text-sm border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring focus:ring-brand-green focus:ring-opacity-50 bg-dark-panel text-white disabled:bg-dark-panel-light disabled:cursor-not-allowed disabled:text-dark-text-tertiary"
                    >
                        {STATUS_OPTIONS.map((status) => (
                        <option key={status} value={status}>
                            {status}
                        </option>
                        ))}
                    </select>
                 )}
                 {/* FIX: Add technician assignment dropdown for Admins/Managers */}
                 {(user.role === 'Admin' || user.role === 'Manager') && (
                    <select
                        title="Assign Technician"
                        value={ticket.assignedTechnicianId || ''}
                        onChange={(e) => onAssignTechnician(ticket.id, e.target.value)}
                        disabled={isCompleted}
                        className="w-full text-sm border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring focus:ring-brand-green focus:ring-opacity-50 bg-dark-panel text-white disabled:bg-dark-panel-light disabled:cursor-not-allowed disabled:text-dark-text-tertiary"
                    >
                        <option value="">Assign Tech...</option>
                        {technicians.map((tech) => (
                        <option key={tech.uid} value={tech.uid}>
                            {tech.displayName}
                        </option>
                        ))}
                    </select>
                 )}
                 <div className="flex w-full gap-2 mt-2">
                    <button
                        onClick={() => onSendMessage(ticket)}
                        className="flex-1 flex items-center justify-center gap-2 text-sm bg-dark-panel hover:bg-dark-border text-white font-bold py-2 px-3 rounded-lg transition-colors"
                        title="Send Message"
                    >
                        <PaperAirplaneIcon className="h-4 w-4" />
                    </button>
                    <button
                        onClick={() => setShowNotes(!showNotes)}
                        className="flex-1 flex items-center justify-center gap-2 text-sm bg-dark-panel hover:bg-dark-border text-white font-bold py-2 px-3 rounded-lg transition-colors"
                        title="View Notes"
                    >
                        <ChatBubbleLeftRightIcon className="h-4 w-4" />
                        <span>({ticket.notes.length})</span>
                    </button>
                    <button
                      onClick={() => setIsSuggesterOpen(true)}
                      disabled={!firstItem}
                      className="flex-1 flex items-center justify-center gap-2 text-sm bg-brand-green hover:bg-brand-green-darker text-dark-bg font-bold py-2 px-3 rounded-lg transition-colors duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed"
                    >
                      <AIIcon className="h-4 w-4" />
                    </button>
                 </div>
              </div>
            </div>
        </div>
        {showNotes && (
            <div className="bg-dark-panel p-4 border-t border-dark-border">
                <h4 className="font-semibold text-dark-text-primary mb-2">Notes</h4>
                <div className="space-y-2 max-h-40 overflow-y-auto mb-4 pr-2">
                    {ticket.notes.length > 0 ? (
                        ticket.notes.map(note => (
                            <div key={note.id} className="bg-dark-bg p-2 rounded-md text-sm">
                                <p className="text-dark-text-secondary">{note.content}</p>
                                <p className="text-xs text-dark-text-tertiary text-right mt-1">{note.createdAt.toLocaleString()}</p>
                            </div>
                        ))
                    ) : (
                        <p className="text-sm text-dark-text-tertiary">No notes yet.</p>
                    )}
                </div>
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={newNote}
                        onChange={(e) => setNewNote(e.target.value)}
                        placeholder="Add a new note..."
                        className="flex-grow bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-sm"
                        onKeyPress={(e) => e.key === 'Enter' && handleAddNote()}
                    />
                    <button onClick={handleAddNote} className="px-4 py-2 text-sm font-bold text-dark-bg bg-dark-accent-blue rounded-md hover:bg-blue-700">
                        Add
                    </button>
                </div>
            </div>
        )}
      </div>
       <RepairSuggester
        isOpen={isSuggesterOpen}
        onClose={() => setIsSuggesterOpen(false)}
        deviceModel={firstItem?.deviceModel || ''}
        issueDescription={firstItem?.issue || ''}
      />
    </>
  );
};

export default TicketItem;