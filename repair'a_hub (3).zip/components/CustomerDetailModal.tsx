import React from 'react';
import { Customer, Ticket } from '../types';
import CloseIcon from './icons/CloseIcon';
import StatusBadge from './StatusBadge';

interface CustomerDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: Customer;
  tickets: Ticket[];
}

const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({ isOpen, onClose, customer, tickets }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        <header className="flex items-start justify-between p-4 border-b border-dark-border">
          <div>
            <h2 className="text-xl font-bold text-dark-text-primary">{customer.name}</h2>
            <p className="text-sm text-dark-text-secondary">{customer.phone}</p>
            <p className="text-sm text-dark-text-secondary">{customer.email}</p>
          </div>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6 overflow-y-auto">
          <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Repair History</h3>
          {tickets.length > 0 ? (
            <div className="space-y-4">
              {tickets.map((ticket) => (
                <div key={ticket.id} className="bg-dark-panel-light p-4 rounded-lg">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-grow">
                      <p className="font-semibold text-dark-text-primary">
                        {ticket.items[0]?.name || 'Repair Ticket'}
                      </p>
                      <p className="text-sm text-dark-text-secondary mt-1 max-w-md">
                        {ticket.items[0]?.issue || 'No issue description.'}
                      </p>
                      <p className="text-xs text-dark-text-tertiary mt-2">
                        ID: {ticket.id.substring(0, 8)} | Date: {ticket.createdAt.toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                       <StatusBadge status={ticket.status} />
                       <p className="font-bold text-lg text-dark-text-primary mt-2">${ticket.total.toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-dark-text-secondary">No repair history found for this customer.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CustomerDetailModal;