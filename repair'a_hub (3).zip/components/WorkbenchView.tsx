

import React from 'react';
// FIX: Import User type
import { Ticket, TicketStatus, User } from '../types';
import TicketList from './TicketList';

interface WorkbenchViewProps {
  tickets: Ticket[];
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
  onAddQuote: (ticketId: string) => void;
  onAddNote: (ticketId: string, noteContent: string) => void;
  onPrintTicket: (ticket: Ticket) => void;
  onSendMessage: (ticket: Ticket) => void;
  // FIX: Add props for technician assignment
  user: User;
  technicians: User[];
  onAssignTechnician: (ticketId: string, technicianId: string) => void;
}

const WorkbenchView: React.FC<WorkbenchViewProps> = ({
  tickets,
  onUpdateStatus,
  onAddQuote,
  onAddNote,
  onPrintTicket,
  onSendMessage,
  // FIX: Accept new props
  user,
  technicians,
  onAssignTechnician,
}) => {
  const activeStatuses = [
    TicketStatus.NEW,
    TicketStatus.IN_PROGRESS,
    TicketStatus.WAITING_for_PARTS,
    TicketStatus.WAITING_FOR_ARRIVAL,
    TicketStatus.QUOTE_PENDING,
  ];

  const activeTickets = tickets.filter(t => activeStatuses.includes(t.status));
  const completedTickets = tickets.filter(t => t.status === TicketStatus.COMPLETED);

  return (
    <div className="space-y-10">
      <div>
        <h2 className="text-xl font-semibold text-dark-text-primary mb-4">Active Repairs</h2>
        {activeTickets.length > 0 ? (
          <TicketList
            tickets={activeTickets}
            onUpdateStatus={onUpdateStatus}
            onAddQuote={onAddQuote}
            onAddNote={onAddNote}
            onPrintTicket={onPrintTicket}
            onSendMessage={onSendMessage}
            // FIX: Pass technician assignment props down
            user={user}
            technicians={technicians}
            onAssignTechnician={onAssignTechnician}
          />
        ) : (
          <div className="text-center py-10 bg-dark-panel rounded-lg">
            <h3 className="text-lg font-medium text-dark-text-secondary">No active tickets.</h3>
            <p className="mt-1 text-sm text-dark-text-tertiary">All caught up!</p>
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-semibold text-dark-text-primary mb-4">Completed Repairs</h2>
        {completedTickets.length > 0 ? (
          <TicketList
            tickets={completedTickets}
            onUpdateStatus={onUpdateStatus}
            onAddQuote={onAddQuote}
            onAddNote={onAddNote}
            onPrintTicket={onPrintTicket}
            onSendMessage={onSendMessage}
            // FIX: Pass technician assignment props down
            user={user}
            technicians={technicians}
            onAssignTechnician={onAssignTechnician}
          />
        ) : (
          <div className="text-center py-10 bg-dark-panel rounded-lg">
            <h3 className="text-lg font-medium text-dark-text-secondary">No completed repairs found.</h3>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkbenchView;