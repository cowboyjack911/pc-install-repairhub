




import React, { useState, useEffect } from 'react';
import { NavItem, BusinessInfo } from '../../types';
import Logo from '../Logo';
import ChevronDownIcon from '../icons/ChevronDownIcon';
import CloseIcon from '../icons/CloseIcon';

const findParentGroup = (items: NavItem[], activeId: string): NavItem | null => {
    for (const item of items) {
        if (item.subItems?.some(sub => sub.id === activeId)) {
            return item;
        }
        if (item.id === 'settings' && activeId.startsWith('settings.')) {
            const settingsItem = item.subItems?.find(si => si.view === activeId);
            if(settingsItem) return item;
        }
    }
    return null;
};

const SidebarNavItem: React.FC<{
    item: NavItem;
    activeItemId: string;
    onNavigate: (id: string) => void;
    openGroupIds: Set<string>;
    toggleGroup: (id: string) => void;
}> = ({ item, activeItemId, onNavigate, openGroupIds, toggleGroup }) => {
    const Icon = item.icon;
    const hasSubItems = item.subItems && item.subItems.length > 0;
    const isOpen = hasSubItems && openGroupIds.has(item.id);

    // An item is active if its ID matches, or if one of its children's ID matches
    const isActive = activeItemId === item.id || 
                     (item.view && activeItemId.startsWith(item.view) && item.id === 'settings') ||
                     (hasSubItems && item.subItems.some(sub => sub.id === activeItemId || (sub.view && activeItemId === sub.view)));

    const handleItemClick = () => {
        if (hasSubItems) {
            toggleGroup(item.id);
        }
        if (item.view) {
          onNavigate(item.view);
        } else if (!hasSubItems) {
          onNavigate(item.id)
        }
    };
    
    // In StaffView, navigation is based on view, but active state is based on ID.
    // Let's call onNavigate with the view if it exists, otherwise the ID.
    const handleNavigation = (navItem: NavItem) => {
        onNavigate(navItem.view || navItem.id);
    }

    return (
        <div>
            <button
                onClick={handleItemClick}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                    isActive
                    ? 'bg-dark-panel-light text-white'
                    : 'text-dark-text-secondary hover:bg-dark-panel-light hover:text-white'
                }`}
            >
                <Icon className={`h-5 w-5 flex-shrink-0 ${isActive ? 'text-brand-green' : ''}`} />
                <span className="flex-grow text-left truncate">{item.label}</span>
                {item.isNew && <span className="ml-auto text-xs bg-brand-green text-dark-bg font-bold px-1.5 py-0.5 rounded-full">New</span>}
                {hasSubItems && <ChevronDownIcon className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />}
            </button>
            {isOpen && hasSubItems && (
                <div className="mt-1 pl-6 space-y-1 py-2 bg-black/20 rounded-md">
                    {item.subItems.map(subItem => {
                        const isSubItemActive = activeItemId === subItem.id || activeItemId === subItem.view;
                        return (
                            <button
                                key={subItem.id}
                                onClick={() => handleNavigation(subItem)}
                                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                                    isSubItemActive
                                    ? 'text-brand-green'
                                    : 'text-dark-text-tertiary hover:text-white'
                                }`}
                            >
                                <span className="w-5 h-5 flex-shrink-0"></span>
                                <span className="flex-grow text-left truncate">{subItem.label}</span>
                            </button>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

// FIX: Define SidebarProps interface
interface SidebarProps {
    businessInfo: BusinessInfo;
    activeItemId: string;
    onNavigate: (id: string) => void;
    onClose: () => void;
    // FIX: Add navItems to props
    navItems: NavItem[];
}

const Sidebar: React.FC<SidebarProps> = ({ businessInfo, activeItemId, onNavigate, onClose, navItems }) => {
    const [openGroupIds, setOpenGroupIds] = useState<Set<string>>(new Set());

    useEffect(() => {
        // FIX: Use navItems prop instead of hardcoded constant
        const parent = findParentGroup(navItems, activeItemId);
        if (parent && !openGroupIds.has(parent.id)) {
            setOpenGroupIds(prev => new Set(prev).add(parent.id));
        }
    }, [activeItemId, openGroupIds, navItems]);

    const toggleGroup = (id: string) => {
        setOpenGroupIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) {
                newSet.delete(id);
            } else {
                newSet.add(id);
            }
            return newSet;
        });
    };
    
    // In StaffView, the activeId is the view. We need to find the item by view.
    const findItemByView = (items: NavItem[], view: string): NavItem | null => {
        for(const item of items) {
            if (item.view === view) return item;
            if (item.subItems) {
                const found = findItemByView(item.subItems, view);
                if(found) return found;
            }
        }
        return null;
    }
    // FIX: Use navItems prop instead of hardcoded constant
    const activeItem = findItemByView(navItems, activeItemId);

    return (
        <aside className="w-64 flex-shrink-0 bg-dark-panel flex flex-col border-r border-dark-border h-full">
            <div className="h-16 flex items-center justify-between px-4 border-b border-dark-border">
                <Logo businessInfo={businessInfo} />
                 <button 
                    onClick={onClose} 
                    className="p-2 -ml-2 rounded-md text-dark-text-tertiary hover:text-white hover:bg-dark-panel-light"
                    aria-label="Close menu"
                >
                    <CloseIcon className="w-6 h-6" />
                </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-4 space-y-1">
                {/* FIX: Use navItems prop instead of hardcoded constant */}
                {navItems.map(item => (
                    <SidebarNavItem 
                        key={item.id}
                        item={item}
                        activeItemId={activeItem?.id || activeItemId}
                        onNavigate={onNavigate}
                        openGroupIds={openGroupIds}
                        toggleGroup={toggleGroup}
                    />
                ))}
            </nav>
        </aside>
    );
};

export default Sidebar;