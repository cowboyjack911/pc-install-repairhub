
import React, { useState } from 'react';
import { GiftCard } from '../types';
import CloseIcon from './icons/CloseIcon';

interface ApplyGiftCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (card: GiftCard) => void;
  giftCards: GiftCard[];
}

const ApplyGiftCardModal: React.FC<ApplyGiftCardModalProps> = ({ isOpen, onClose, onApply, giftCards }) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleApply = () => {
    setError(null);
    const foundCard = giftCards.find(card => card.id.toLowerCase() === code.toLowerCase().trim());
    
    if (!foundCard) {
      setError('Gift card not found.');
      return;
    }
    if (foundCard.status === 'depleted' || foundCard.balance <= 0) {
      setError('This gift card has no remaining balance.');
      return;
    }
    
    onApply(foundCard);
  };
  
  const handleClose = () => {
    setCode('');
    setError(null);
    onClose();
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-sm">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Apply Gift Card</h2>
          <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6">
          <label htmlFor="giftCardCode" className="block text-sm font-medium text-dark-text-secondary">
            Enter Gift Card Code
          </label>
          <input
            type="text"
            id="giftCardCode"
            value={code}
            onChange={e => setCode(e.target.value)}
            className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
            placeholder="e.g., GC-2023-ABC-123"
            autoFocus
          />
          {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
        </main>
        
        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2 text-sm font-medium text-dark-text-primary"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
          >
            Apply
          </button>
        </footer>
      </div>
    </div>
  );
};

export default ApplyGiftCardModal;
