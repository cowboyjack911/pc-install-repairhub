import React from 'react';

const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3.375A2.25 2.25 0 0010.5 1.125h-3a2.25 2.25 0 00-2.25 2.25v3.75a2.25 2.25 0 001.043 1.916l2.11 1.054a.75.75 0 00.868 0l2.11-1.054A2.25 2.25 0 0012.75 7.125V3.375z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3.375h3a2.25 2.25 0 012.25 2.25v3.75a2.25 2.25 0 01-1.043 1.916l-2.11 1.054a.75.75 0 01-.868 0l-2.11-1.054A2.25 2.25 0 018.25 7.125V3.375h4.5z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 12h16.5m-16.5 0a2.25 2.25 0 01-2.25-2.25V7.125A2.25 2.25 0 013.75 4.875h16.5A2.25 2.25 0 0122.5 7.125v2.625A2.25 2.25 0 0120.25 12H3.75z" />
    </svg>
);

export default GiftIcon;