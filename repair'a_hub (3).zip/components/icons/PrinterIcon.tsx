import React from 'react';

const PrinterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6 18.75m10.94-4.921c.24.03.48.062.72.096m-.72-.096L18 18.75m-12 0h12.06a1.5 1.5 0 001.438-1.002L21 11.25c0-1.026-.84-1.875-1.875-1.875H4.875C3.85 9.375 3 10.224 3 11.25l2.06 6.548A1.5 1.5 0 006.5 18.75h.21z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18.75h12M6 18.75a2.25 2.25 0 01-2.25-2.25V13.5A2.25 2.25 0 016 11.25h12a2.25 2.25 0 012.25 2.25v3A2.25 2.25 0 0118 18.75M18 18.75v-7.5a2.25 2.25 0 00-2.25-2.25H8.25A2.25 2.25 0 006 11.25v7.5" />
    </svg>
);

export default PrinterIcon;
