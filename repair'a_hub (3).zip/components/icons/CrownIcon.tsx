import React from 'react';

const CrownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-3.375A3 3 0 0011.25 15h-2.5a3 3 0 00-2.25 2.625V21m10.5-9.375a.75.75 0 00-1.5 0v3.375a.75.75 0 001.5 0V11.625zM15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

export default CrownIcon;