import React from 'react';

const AfterpayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
    >
        <path d="M4 10h16" />
        <path d="M4 14h16" />
    </svg>
);

export default AfterpayIcon;
