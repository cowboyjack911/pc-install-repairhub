import React from 'react';

const HomeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955a.75.75 0 011.06 0l8.955 8.955M3 10.5v.75a3.75 3.75 0 003.75 3.75h1.5a.75.75 0 00.75-.75v-4.5a.75.75 0 00-.75-.75h-1.5A3.75 3.75 0 003 10.5z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 21V15a.75.75 0 01.75-.75h3.75a.75.75 0 01.75.75v6m-4.5 0H21" />
    </svg>
);

export default HomeIcon;
