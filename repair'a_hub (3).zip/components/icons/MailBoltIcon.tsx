import React from 'react';

const MailBoltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 9V18a2.25 2.25 0 01-2.25 2.25H4.5A2.25 2.25 0 012.25 18V9m19.5 0a2.25 2.25 0 00-2.25-2.25H4.5A2.25 2.25 0 002.25 9m19.5 0v.256a2.25 2.25 0 01-2.25 2.25H4.5A2.25 2.25 0 012.25 9.256V9m19.5 0L12 3m-9.75 6L12 3m0 0l-9.75 6" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 12l-2.25 3h4.5l-2.25-3z" />
    </svg>
);

export default MailBoltIcon;