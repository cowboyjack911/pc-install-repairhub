
import React from 'react';

const ChatBubbleLeftRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.722.372c-1.034.104-1.934.956-1.934 2.003v.497c0 .538-.214 1.033-.584 1.404l-1.558 1.558a1.5 1.5 0 01-2.122 0l-1.558-1.558c-.37-.371-.584-.866-.584-1.404v-.497c0-1.047-.9-1.899-1.934-2.003l-3.722-.372c-1.134-.093-1.98-1.057-1.98-2.193V10.608c0-.97.616-1.813 1.5-2.097m14.25-3.866A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5v-.001z" />
    </svg>
);

export default ChatBubbleLeftRightIcon;