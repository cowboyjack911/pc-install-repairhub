import React from 'react';

const PlugConnectedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.39 4.5A2.25 2.25 0 009.25 2.25h-3.75v3h3.75c1.155 0 2.166-.81 2.24-1.875A2.252 2.252 0 0011.39 4.5zM11.39 4.5v1.5M11.39 4.5a2.25 2.25 0 012.122 3.125l-2.02 4.04a.75.75 0 01-1.218 0l-2.02-4.04A2.25 2.25 0 0111.39 4.5zM12 18.75h3.75a2.25 2.25 0 002.25-2.25V13.5a2.25 2.25 0 00-2.25-2.25H12v7.5zM6 13.5h3.75v7.5H6v-7.5z" />
    </svg>
);

export default PlugConnectedIcon;