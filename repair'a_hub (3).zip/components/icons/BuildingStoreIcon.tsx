import React from 'react';

const BuildingStoreIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21m-4.5 0H2.25a.75.75 0 01-.75-.75V10.5a.75.75 0 01.75-.75h1.5V6a.75.75 0 01.75-.75h15a.75.75 0 01.75.75v3.75h1.5a.75.75 0 01.75.75v9.75a.75.75 0 01-.75.75H13.5z" />
    </svg>
);

export default BuildingStoreIcon;