
import React from 'react';

const AIIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    {...props}
  >
    <path 
      fillRule="evenodd" 
      d="M9.315 7.584C12.195 3.883 19.14 7.238 19.5 12c.36 4.762-6.305 8.117-9.185 4.416-2.88-3.701.29-10.61 2.295-11.962a.94.94 0 011.09 1.638C12.125 7.153 11.022 10.39 12 12c.978 1.61 3.514.935 4.685-1.125-1.025 2.828-4.33 3.417-5.58 1.625-1.25-1.792.14-5.333-2.79-4.916z" 
      clipRule="evenodd" 
    />
  </svg>
);

export default AIIcon;
