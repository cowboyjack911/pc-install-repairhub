
import React from 'react';

const BarcodeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.5v15a2.25 2.25 0 002.25 2.25h13.5a2.25 2.25 0 002.25-2.25v-15a2.25 2.25 0 00-2.25-2.25H6a2.25 2.25 0 00-2.25 2.25z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 9v6m2.25-6v6m2.25-6v6m2.25-6v6m2.25-6v6" />
    </svg>
);

export default BarcodeIcon;
