import React from 'react';

const UsersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.289 2.72a.75.75 0 01-.886.044l-1.888-.879.443-1.805a.75.75 0 011.316.487l-.23.935zM18 18.72A9.094 9.094 0 0018 9.094m-9 9.626a9.094 9.094 0 01-3.741-.479 3 3 0 014.682-2.72M6.344 18.72A9.094 9.094 0 016 9.094m9.094 9.626c-1.307.29-2.662.479-4.094.479-1.432 0-2.787-.189-4.094-.479m12.376-1.579a3 3 0 00-4.682-2.72m-7.289 2.72a.75.75 0 01-.886.044l-1.888-.879.443-1.805a.75.75 0 011.316.487l-.23.935zM12 21a9 9 0 100-18 9 9 0 000 18z" />
    </svg>
);

export default UsersIcon;
