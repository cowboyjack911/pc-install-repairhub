import React from 'react';

const PCIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 17.25H7.5a2.25 2.25 0 01-2.25-2.25V5.25A2.25 2.25 0 017.5 3h9a2.25 2.25 0 012.25 2.25v9.75a2.25 2.25 0 01-2.25 2.25H15M9 17.25v2.25m6-2.25v2.25m-3-13.5v1.5m-3-1.5v1.5m6-1.5v1.5m-3-1.5V9" />
    </svg>
);

export default PCIcon;
