import React, { useState, useMemo } from 'react';
import { Customer } from '../types';
import CloseIcon from './icons/CloseIcon';
import SearchIcon from './icons/SearchIcon';
import UserIcon from './icons/UserIcon';

interface CustomerSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  onSelectCustomer: (customer: Customer) => void;
}

const CustomerSearchModal: React.FC<CustomerSearchModalProps> = ({ isOpen, onClose, customers, onSelectCustomer }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCustomers = useMemo(() => {
    if (!searchTerm) {
      return customers;
    }
    return customers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone?.includes(searchTerm)
    );
  }, [customers, searchTerm]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-start z-50 p-4 pt-20">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg max-h-[70vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Find Customer</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <div className="p-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by name or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-dark-bg border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        <main className="overflow-y-auto px-4 pb-4">
          {filteredCustomers.length > 0 ? (
            <ul className="divide-y divide-dark-border">
              {filteredCustomers.map((customer) => (
                <li key={customer.id}>
                  <button
                    onClick={() => onSelectCustomer(customer)}
                    className="w-full text-left flex items-center p-3 hover:bg-dark-panel-light rounded-lg transition-colors"
                  >
                    <UserIcon className="w-6 h-6 mr-3 text-dark-text-secondary" />
                    <div>
                      <p className="font-medium text-dark-text-primary">{customer.name}</p>
                      <p className="text-sm text-dark-text-tertiary">{customer.phone}</p>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center py-8">
              <p className="text-dark-text-secondary">No customers found.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CustomerSearchModal;