
import React, { useState } from 'react';
import { generateImageFromPrompt } from '../services/geminiService';
import AIIcon from './icons/AIIcon';
import ArrowDownTrayIcon from './icons/ArrowDownTrayIcon';
import PhotoIcon from './icons/PhotoIcon';

const ASPECT_RATIOS = ["1:1", "16:9", "9:16", "4:3", "3:4"];

const ImageGenerationView: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState('1:1');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt) {
            setError('Please enter a prompt to generate an image.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setImageUrl(null);

        try {
            const imageBytes = await generateImageFromPrompt(prompt, aspectRatio);
            setImageUrl(`data:image/jpeg;base64,${imageBytes}`);
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-2">
                            <label htmlFor="prompt" className="block text-sm font-medium text-dark-text-secondary">Image Prompt</label>
                            <textarea
                                id="prompt"
                                rows={3}
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
                                placeholder="e.g., A futuristic phone with a holographic screen"
                            />
                        </div>
                        <div>
                            <label htmlFor="aspectRatio" className="block text-sm font-medium text-dark-text-secondary">Aspect Ratio</label>
                            <select
                                id="aspectRatio"
                                value={aspectRatio}
                                onChange={(e) => setAspectRatio(e.target.value)}
                                className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
                            >
                                {ASPECT_RATIOS.map(ratio => <option key={ratio} value={ratio}>{ratio}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="mt-4 text-right">
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="inline-flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold disabled:bg-gray-500 disabled:cursor-wait"
                        >
                            {isLoading ? (
                                <>
                                 <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-dark-bg"></div>
                                 <span>Generating...</span>
                                </>
                            ) : (
                                <>
                                <AIIcon className="w-5 h-5" />
                                <span className="text-sm font-medium">Generate Image</span>
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>

            <div className="mt-6">
                {error && <div className="p-4 bg-red-900/50 text-red-400 rounded-lg text-center">{error}</div>}
                
                {isLoading && !imageUrl && (
                    <div className="text-center py-16 bg-dark-panel rounded-lg">
                        <div className="animate-pulse flex flex-col items-center">
                            <PhotoIcon className="h-12 w-12 text-dark-border" />
                            <p className="mt-4 text-base text-dark-text-secondary">AI is creating your masterpiece...</p>
                        </div>
                    </div>
                )}

                {!isLoading && !imageUrl && !error && (
                    <div className="text-center py-16 bg-dark-panel rounded-lg border-2 border-dashed border-dark-border">
                        <PhotoIcon className="mx-auto h-12 w-12 text-dark-border" />
                        <h3 className="mt-4 text-xl font-medium text-dark-text-primary">Image will appear here</h3>
                        <p className="mt-2 text-base text-dark-text-secondary">
                          Enter a prompt above and click generate to create an image.
                        </p>
                    </div>
                )}
                
                {imageUrl && (
                    <div className="bg-dark-panel p-4 rounded-lg shadow-lg relative group">
                        <img src={imageUrl} alt={prompt} className="rounded-md w-full" />
                         <a
                            href={imageUrl}
                            download={`ai-image-${Date.now()}.jpg`}
                            className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/50 text-white px-4 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                         >
                            <ArrowDownTrayIcon className="w-5 h-5" />
                            <span>Download</span>
                         </a>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ImageGenerationView;
