
import React, { useState } from 'react';
import FacebookIcon from './icons/FacebookIcon';
import InstagramIcon from './icons/InstagramIcon';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';
import SearchIcon from './icons/SearchIcon';

const conversations = [
  { id: 1, name: 'John Doe', platform: 'facebook', lastMessage: 'Hi, can you fix an iPhone 12 screen?', time: '2m ago', unread: 2, messages: [
    { from: 'them', text: 'Hi, can you fix an iPhone 12 screen?' },
    { from: 'me', text: 'Yes, we can! It costs $129 and takes about an hour.' },
    { from: 'them', text: 'Great, can I come in this afternoon?' },
  ]},
  { id: 2, name: 'Jane Smith', platform: 'instagram', lastMessage: 'Thanks for the quick repair!', time: '1h ago', unread: 0, messages: [
      { from: 'me', text: 'Your device is ready for pickup.'},
      { from: 'them', text: 'Thanks for the quick repair!'},
  ]},
  { id: 3, name: 'Alex Johnson', platform: 'instagram', lastMessage: 'Do you buy used phones?', time: '3h ago', unread: 0, messages: [
      { from: 'them', text: 'Do you buy used phones?'},
  ]},
  { id: 4, name: 'Emily White', platform: 'facebook', lastMessage: 'What are your hours on Saturday?', time: '1d ago', unread: 0, messages: [
      { from: 'them', text: 'What are your hours on Saturday?'},
  ]},
];

const MessagingView: React.FC = () => {
    const [activeConversationId, setActiveConversationId] = useState(1);
    const activeConversation = conversations.find(c => c.id === activeConversationId);

    return (
        <div className="flex h-[calc(100vh-8.5rem)] bg-dark-panel rounded-lg shadow-lg overflow-hidden">
            {/* Conversations List */}
            <aside className="w-1/3 border-r border-dark-border flex flex-col">
                <div className="p-4 border-b border-dark-border">
                    <div className="relative">
                        <SearchIcon className="h-5 w-5 text-dark-text-tertiary absolute left-3 top-1/2 -translate-y-1/2" />
                        <input type="text" placeholder="Search messages..." className="bg-dark-bg border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full"/>
                    </div>
                </div>
                <div className="flex-grow overflow-y-auto">
                    {conversations.map(conv => (
                        <button key={conv.id} onClick={() => setActiveConversationId(conv.id)} className={`w-full text-left p-4 flex items-center gap-4 transition-colors ${activeConversationId === conv.id ? 'bg-dark-accent-blue/10' : 'hover:bg-dark-panel-light'}`}>
                            <div className="relative">
                                {conv.platform === 'facebook' ? <FacebookIcon className="w-10 h-10 text-blue-500" /> : <InstagramIcon className="w-10 h-10" />}
                            </div>
                            <div className="flex-grow overflow-hidden">
                                <div className="flex justify-between items-center">
                                    <p className="font-bold text-dark-text-primary truncate">{conv.name}</p>
                                    <p className="text-xs text-dark-text-tertiary flex-shrink-0">{conv.time}</p>
                                </div>
                                <div className="flex justify-between items-start">
                                    <p className="text-sm text-dark-text-secondary truncate">{conv.lastMessage}</p>
                                    {conv.unread > 0 && <span className="flex-shrink-0 ml-2 bg-dark-accent-blue text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">{conv.unread}</span>}
                                </div>
                            </div>
                        </button>
                    ))}
                </div>
            </aside>

            {/* Chat Panel */}
            <main className="w-2/3 flex flex-col">
                {activeConversation ? (
                    <>
                        <header className="p-4 border-b border-dark-border flex items-center gap-3">
                            {activeConversation.platform === 'facebook' ? <FacebookIcon className="w-8 h-8 text-blue-500" /> : <InstagramIcon className="w-8 h-8" />}
                            <div>
                                <h2 className="font-bold text-lg text-dark-text-primary">{activeConversation.name}</h2>
                                <p className="text-xs text-green-400">Online</p>
                            </div>
                        </header>
                        <div className="flex-grow p-6 overflow-y-auto space-y-4">
                            {activeConversation.messages.map((msg, index) => (
                                <div key={index} className={`flex ${msg.from === 'me' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-xs lg:max-w-md p-3 rounded-2xl ${msg.from === 'me' ? 'bg-dark-accent-blue text-white rounded-br-none' : 'bg-dark-panel-light text-dark-text-primary rounded-bl-none'}`}>
                                        <p>{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <footer className="p-4 bg-dark-panel-light/50">
                            <div className="relative">
                                <input type="text" placeholder="Type a message..." className="w-full bg-dark-bg border-dark-border rounded-full py-3 pl-4 pr-12 text-sm"/>
                                <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-dark-accent-blue text-white hover:bg-blue-700">
                                    <PaperAirplaneIcon className="w-5 h-5"/>
                                </button>
                            </div>
                        </footer>
                    </>
                ) : (
                    <div className="flex items-center justify-center h-full text-dark-text-secondary">Select a conversation to start messaging.</div>
                )}
            </main>
        </div>
    );
};

export default MessagingView;
