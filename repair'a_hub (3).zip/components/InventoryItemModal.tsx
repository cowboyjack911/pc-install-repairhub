

import React, { useState, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { InventoryItem, Omit } from '../types';
import CloseIcon from './icons/CloseIcon';

interface InventoryItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (itemData: Omit<InventoryItem, 'id'> | InventoryItem) => void;
  item: InventoryItem | null;
}

const InventoryItemModal: React.FC<InventoryItemModalProps> = ({ isOpen, onClose, onSave, item }) => {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [quantity, setQuantity] = useState('');
  const [cost, setCost] = useState('');
  const [reorderPoint, setReorderPoint] = useState('');
  const isEditing = !!item;

  useEffect(() => {
    if (isOpen) {
      setName(item?.name || '');
      setSku(item?.sku || '');
      setQuantity(item?.quantity.toString() || '');
      setCost(item?.cost.toString() || '');
      setReorderPoint(item?.reorderPoint?.toString() || '');
    }
  }, [isOpen, item]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !sku || !quantity || !cost) {
      alert("Please fill in all fields.");
      return;
    }
    const itemData: Omit<InventoryItem, 'id'> = {
      name,
      sku,
      quantity: parseInt(quantity, 10),
      cost: parseFloat(cost),
      reorderPoint: reorderPoint ? parseInt(reorderPoint, 10) : undefined,
    };

    if (isEditing && item) {
      onSave({ ...itemData, id: item.id });
    } else {
      onSave(itemData);
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <h2 className="text-xl font-bold text-dark-text-primary">
              {isEditing ? 'Edit Inventory Item' : 'Add New Inventory Item'}
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="text-dark-text-tertiary hover:text-white transition-colors"
            >
              <CloseIcon className="h-6 w-6" />
            </button>
          </header>

          <main className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label htmlFor="itemName" className="block text-sm font-medium text-dark-text-secondary">Item Name</label>
              <input type="text" id="itemName" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
             <div>
              <label htmlFor="itemSku" className="block text-sm font-medium text-dark-text-secondary">SKU</label>
              <input type="text" id="itemSku" value={sku} onChange={e => setSku(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
            <div>
              <label htmlFor="itemQuantity" className="block text-sm font-medium text-dark-text-secondary">Quantity</label>
              <input type="number" id="itemQuantity" value={quantity} onChange={e => setQuantity(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
            <div>
              <label htmlFor="itemCost" className="block text-sm font-medium text-dark-text-secondary">Cost ($)</label>
              <input type="number" step="0.01" id="itemCost" value={cost} onChange={e => setCost(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
             <div>
              <label htmlFor="reorderPoint" className="block text-sm font-medium text-dark-text-secondary">Reorder Point</label>
              <input type="number" id="reorderPoint" value={reorderPoint} onChange={e => setReorderPoint(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" placeholder="e.g., 5" />
            </div>
          </main>

          <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-panel focus:ring-brand-green">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-panel focus:ring-brand-green">
              Save Item
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default InventoryItemModal;