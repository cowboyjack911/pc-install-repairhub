
import React, { useMemo } from 'react';
import { Ticket, User } from '../../types';

interface TechnicianPerformanceReportProps {
    tickets: Ticket[];
    users: User[];
}

interface AggregatedTech {
    id: string;
    name: string;
    ticketCount: number;
    totalRevenue: number;
}

const TechnicianPerformanceReport: React.FC<TechnicianPerformanceReportProps> = ({ tickets, users }) => {
    const technicians = useMemo(() => users.filter(u => u.role === 'Technician'), [users]);

    const reportData = useMemo(() => {
        const techMap = new Map<string, AggregatedTech>();

        technicians.forEach(tech => {
            techMap.set(tech.uid, { id: tech.uid, name: tech.displayName || 'Unknown', ticketCount: 0, totalRevenue: 0 });
        });

        tickets.forEach(ticket => {
            if (ticket.assignedTechnicianId) {
                const techData = techMap.get(ticket.assignedTechnicianId);
                if (techData) {
                    techData.ticketCount += 1;
                    techData.totalRevenue += ticket.total;
                }
            }
        });

        return Array.from(techMap.values()).sort((a, b) => b.totalRevenue - a.totalRevenue);
    }, [tickets, technicians]);

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
            <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Technician Performance</h3>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-dark-border">
                    <thead className="bg-dark-panel-light">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Technician</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Completed Repairs</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody className="bg-dark-bg divide-y divide-dark-border">
                        {reportData.map(tech => (
                            <tr key={tech.id}>
                                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-dark-text-primary">{tech.name}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">{tech.ticketCount}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm font-semibold text-green-400">${tech.totalRevenue.toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {reportData.length === 0 && (
                <div className="text-center py-10">
                    <p className="text-dark-text-secondary">No technician data for the selected period.</p>
                </div>
            )}
        </div>
    );
};

export default TechnicianPerformanceReport;
