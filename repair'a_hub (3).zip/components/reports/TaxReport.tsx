import React, { useMemo } from 'react';
import { Ticket } from '../../types';
import StatCard from '../dashboard/StatCard';
import TaxIcon from '../icons/TaxIcon';
import ChartBarIcon from '../icons/ChartBarIcon';
import CurrencyDollarIcon from '../icons/CurrencyDollarIcon';

interface TaxReportProps {
    tickets: Ticket[];
}

const TaxReport: React.FC<TaxReportProps> = ({ tickets }) => {
    const reportData = useMemo(() => {
        const totalTax = tickets.reduce((sum, t) => sum + t.tax, 0);
        const taxableSales = tickets.reduce((sum, t) => sum + (t.subtotal - t.discount), 0);
        const totalSales = tickets.reduce((sum, t) => sum + t.total, 0);

        return { totalTax, taxableSales, totalSales };
    }, [tickets]);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Total Tax Collected" value={`$${reportData.totalTax.toFixed(2)}`} icon={TaxIcon} />
                <StatCard title="Taxable Sales" value={`$${reportData.taxableSales.toFixed(2)}`} icon={ChartBarIcon} />
                <StatCard title="Total Sales (incl. Tax)" value={`$${reportData.totalSales.toFixed(2)}`} icon={CurrencyDollarIcon} />
            </div>

            <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
                <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Taxable Transactions</h3>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-dark-border">
                        <thead className="bg-dark-panel-light">
                            <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Date</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Ticket #</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Taxable Amount</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Tax</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total</th>
                            </tr>
                        </thead>
                        <tbody className="bg-dark-bg divide-y divide-dark-border">
                            {tickets.map(ticket => (
                                <tr key={ticket.id}>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-primary">{new Date(ticket.createdAt).toLocaleDateString()}</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-secondary">{ticket.id.substring(0,8)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${(ticket.subtotal - ticket.discount).toFixed(2)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${ticket.tax.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm font-semibold text-dark-text-primary">${ticket.total.toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {tickets.length === 0 && (
                    <div className="text-center py-10">
                        <p className="text-dark-text-secondary">No taxable transactions for the selected period.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TaxReport;
