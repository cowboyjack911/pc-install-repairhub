

import React, { useMemo } from 'react';
import { Ticket, Expense } from '../../types';

interface ProfitAndLossReportProps {
    tickets: Ticket[];
    expenses: Expense[];
}

const ProfitAndLossReport: React.FC<ProfitAndLossReportProps> = ({ tickets, expenses }) => {
    const reportData = useMemo(() => {
        const grossSales = tickets.reduce((sum, t) => sum + t.subtotal, 0);
        const discounts = tickets.reduce((sum, t) => sum + t.discount, 0);
        const netSales = grossSales - discounts;
        const cogs = tickets.reduce((sum, t) => sum + t.totalCost, 0);
        const grossProfit = netSales - cogs;
        const operatingExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
        const netProfit = grossProfit - operatingExpenses;

        return { grossSales, discounts, netSales, cogs, grossProfit, operatingExpenses, netProfit };
    }, [tickets, expenses]);

    const formatCurrency = (value: number) => {
        const isNegative = value < 0;
        return `${isNegative ? '-' : ''}A$${Math.abs(value).toFixed(2)}`;
    }

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
            <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Profit & Loss Summary</h3>
            <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center p-3 bg-dark-bg rounded-md">
                    <span className="text-dark-text-secondary">Gross Sales</span>
                    <span className="font-medium text-dark-text-primary">{formatCurrency(reportData.grossSales)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-dark-bg rounded-md">
                    <span className="text-dark-text-secondary">Discounts</span>
                    <span className="font-medium text-dark-text-primary">{formatCurrency(reportData.discounts)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-dark-bg rounded-md border-t-2 border-dark-border font-bold">
                    <span className="text-dark-text-primary">Net Sales</span>
                    <span className="text-dark-text-primary">{formatCurrency(reportData.netSales)}</span>
                </div>

                <div className="flex justify-between items-center p-3 bg-dark-bg rounded-md mt-4">
                    <span className="text-dark-text-secondary">Cost of Goods Sold (COGS)</span>
                    <span className="font-medium text-dark-text-primary">{formatCurrency(reportData.cogs)}</span>
                </div>
                 <div className="flex justify-between items-center p-3 bg-dark-bg rounded-md border-t-2 border-dark-border font-bold">
                    <span className="text-dark-text-primary">Gross Profit</span>
                    <span className="text-green-400">{formatCurrency(reportData.grossProfit)}</span>
                </div>

                <div className="flex justify-between items-center p-3 bg-dark-bg rounded-md mt-4">
                    <span className="text-dark-text-secondary">Operating Expenses</span>
                    <span className="font-medium text-dark-text-primary">{formatCurrency(reportData.operatingExpenses)}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-dark-panel-light rounded-md border-t-4 border-dark-border font-bold text-lg">
                    <span className="text-dark-text-primary">Net Profit</span>
                    <span className={reportData.netProfit >= 0 ? 'text-brand-green' : 'text-red-400'}>
                        {formatCurrency(reportData.netProfit)}
                    </span>
                </div>
            </div>
             {(tickets.length === 0 && expenses.length === 0) && (
                <div className="text-center py-10">
                    <p className="text-dark-text-secondary">No financial data for the selected period.</p>
                </div>
            )}
        </div>
    );
};

export default ProfitAndLossReport;