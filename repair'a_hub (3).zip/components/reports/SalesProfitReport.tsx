import React, { useMemo } from 'react';
import { Ticket } from '../../types';
import StatCard from '../dashboard/StatCard';
import CurrencyDollarIcon from '../icons/CurrencyDollarIcon';
import TagIcon from '../icons/TagIcon';
import ChartBarIcon from '../icons/ChartBarIcon';

interface SalesProfitReportProps {
    tickets: Ticket[];
}

const SalesProfitReport: React.FC<SalesProfitReportProps> = ({ tickets }) => {
    const reportData = useMemo(() => {
        const grossSales = tickets.reduce((sum, t) => sum + t.subtotal, 0);
        const discounts = tickets.reduce((sum, t) => sum + t.discount, 0);
        const netSales = grossSales - discounts;
        const cogs = tickets.reduce((sum, t) => sum + t.totalCost, 0);
        const tax = tickets.reduce((sum, t) => sum + t.tax, 0);
        const grossProfit = netSales - cogs;

        return { grossSales, discounts, netSales, cogs, tax, grossProfit };
    }, [tickets]);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Gross Sales" value={`$${reportData.grossSales.toFixed(2)}`} icon={ChartBarIcon} />
                <StatCard title="Discounts" value={`$${reportData.discounts.toFixed(2)}`} icon={TagIcon} />
                <StatCard title="Net Sales" value={`$${reportData.netSales.toFixed(2)}`} icon={ChartBarIcon} />
                <StatCard title="Gross Profit" value={`$${reportData.grossProfit.toFixed(2)}`} icon={CurrencyDollarIcon} />
            </div>

            <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
                <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Transactions</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-dark-border">
                        <thead className="bg-dark-panel-light">
                            <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Date</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Ticket #</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Customer</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Net Sales</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Tax</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Cost</th>
                                <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Profit</th>
                            </tr>
                        </thead>
                        <tbody className="bg-dark-bg divide-y divide-dark-border">
                            {tickets.map(ticket => {
                                const netSale = ticket.subtotal - ticket.discount;
                                const profit = netSale - ticket.totalCost;
                                return (
                                <tr key={ticket.id}>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-primary">{new Date(ticket.createdAt).toLocaleDateString()}</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-secondary">{ticket.id.substring(0,8)}</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-secondary">{ticket.customer.name}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${netSale.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${ticket.tax.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm font-semibold text-dark-text-primary">${ticket.total.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${ticket.totalCost.toFixed(2)}</td>
                                    <td className="px-4 py-2 text-right whitespace-nowrap text-sm font-semibold text-green-400">${profit.toFixed(2)}</td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                </div>
                 {tickets.length === 0 && (
                    <div className="text-center py-10">
                        <p className="text-dark-text-secondary">No sales data for the selected period.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default SalesProfitReport;