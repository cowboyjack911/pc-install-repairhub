
import React, { useMemo } from 'react';
import { Ticket, Customer } from '../../types';

interface CustomerReportsProps {
    tickets: Ticket[];
    customers: Customer[];
}

interface AggregatedCustomer {
    id: string;
    name: string;
    ticketCount: number;
    totalSpent: number;
}

const CustomerReports: React.FC<CustomerReportsProps> = ({ tickets, customers }) => {
    const topSpenders = useMemo(() => {
        const customerMap = new Map<string, AggregatedCustomer>();

        customers.forEach(c => {
            if (c.id !== 'cust_walkin') {
                customerMap.set(c.id, { id: c.id, name: c.name, ticketCount: 0, totalSpent: 0 });
            }
        });

        tickets.forEach(ticket => {
            const customerData = customerMap.get(ticket.customer.id);
            if (customerData) {
                customerData.ticketCount += 1;
                customerData.totalSpent += ticket.total;
            }
        });

        return Array.from(customerMap.values()).sort((a, b) => b.totalSpent - a.totalSpent).slice(0, 20); // Top 20
    }, [tickets, customers]);

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
            <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Top Spenders</h3>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-dark-border">
                    <thead className="bg-dark-panel-light">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Rank</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Customer Name</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Tickets</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total Spent</th>
                        </tr>
                    </thead>
                    <tbody className="bg-dark-bg divide-y divide-dark-border">
                        {topSpenders.map((customer, index) => (
                            <tr key={customer.id}>
                                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-dark-text-primary">{index + 1}</td>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-dark-text-secondary">{customer.name}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">{customer.ticketCount}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm font-semibold text-green-400">${customer.totalSpent.toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {topSpenders.length === 0 && (
                <div className="text-center py-10">
                    <p className="text-dark-text-secondary">No customer sales data for the selected period.</p>
                </div>
            )}
        </div>
    );
};

export default CustomerReports;
