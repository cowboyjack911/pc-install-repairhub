import React, { useMemo } from 'react';
import { Ticket } from '../../types';

interface BestSellersReportProps {
    tickets: Ticket[];
}

interface AggregatedItem {
    name: string;
    quantity: number;
    revenue: number;
    cost: number;
    profit: number;
}

const BestSellersReport: React.FC<BestSellersReportProps> = ({ tickets }) => {
    const reportData = useMemo(() => {
        const itemMap = new Map<string, AggregatedItem>();

        tickets.forEach(ticket => {
            ticket.items.forEach(item => {
                const existing = itemMap.get(item.name);
                if (existing) {
                    existing.quantity += item.quantity;
                    existing.revenue += item.unitPrice * item.quantity;
                    existing.cost += item.cost;
                    existing.profit += (item.unitPrice * item.quantity) - item.cost;
                } else {
                    itemMap.set(item.name, {
                        name: item.name,
                        quantity: item.quantity,
                        revenue: item.unitPrice * item.quantity,
                        cost: item.cost,
                        profit: (item.unitPrice * item.quantity) - item.cost,
                    });
                }
            });
        });

        return Array.from(itemMap.values()).sort((a, b) => b.quantity - a.quantity);
    }, [tickets]);

    return (
        <div className="bg-dark-panel p-6 rounded-lg shadow-lg">
            <h3 className="text-lg font-semibold text-dark-text-primary mb-4">Best Sellers by Quantity</h3>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-dark-border">
                    <thead className="bg-dark-panel-light">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Item Name</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Qty Sold</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total Revenue</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total Cost</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Total Profit</th>
                        </tr>
                    </thead>
                    <tbody className="bg-dark-bg divide-y divide-dark-border">
                        {reportData.map(item => (
                            <tr key={item.name}>
                                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-dark-text-primary">{item.name}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">{item.quantity}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${item.revenue.toFixed(2)}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm text-dark-text-secondary">${item.cost.toFixed(2)}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap text-sm font-semibold text-green-400">${item.profit.toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {reportData.length === 0 && (
                <div className="text-center py-10">
                    <p className="text-dark-text-secondary">No item data for the selected period.</p>
                </div>
            )}
        </div>
    );
};

export default BestSellersReport;
