

import React, { useState, useMemo } from 'react';
import { Ticket, TicketStatus, Expense, User, InventoryItem, Customer } from '../../types';
import SalesProfitReport from './SalesProfitReport';
import TaxReport from './TaxReport';
import BestSellersReport from './BestSellersReport';
import ProfitAndLossReport from './ProfitAndLossReport';
import TechnicianPerformanceReport from './TechnicianPerformanceReport';
import InventoryAgingReport from './InventoryAgingReport';
import CustomerReports from './CustomerReports';

interface ReportsViewProps {
  tickets: Ticket[];
  expenses: Expense[];
  users: User[];
  inventoryItems: InventoryItem[];
  customers: Customer[];
}

type ReportType = 'sales' | 'tax' | 'bestsellers' | 'pnl' | 'tech' | 'inventory_aging' | 'customer';
type DatePreset = 'today' | 'week' | 'month' | 'custom';

const ReportsView: React.FC<ReportsViewProps> = ({ tickets, expenses, users, inventoryItems, customers }) => {
  const [activeReport, setActiveReport] = useState<ReportType>('sales');
  const [datePreset, setDatePreset] = useState<DatePreset>('month');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  const { startDate, endDate } = useMemo(() => {
    const now = new Date();
    switch (datePreset) {
      case 'today':
        return { startDate: new Date(now.setHours(0, 0, 0, 0)), endDate: new Date(now.setHours(23, 59, 59, 999)) };
      case 'week':
        const firstDayOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
        firstDayOfWeek.setHours(0,0,0,0);
        const lastDayOfWeek = new Date(firstDayOfWeek);
        lastDayOfWeek.setDate(lastDayOfWeek.getDate() + 6);
        lastDayOfWeek.setHours(23,59,59,999);
        return { startDate: firstDayOfWeek, endDate: lastDayOfWeek };
      case 'month':
        const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        lastDayOfMonth.setHours(23,59,59,999);
        return { startDate: firstDayOfMonth, endDate: lastDayOfMonth };
      case 'custom':
        const start = customStartDate ? new Date(customStartDate) : null;
        if (start) start.setHours(0,0,0,0);
        const end = customEndDate ? new Date(customEndDate) : null;
        if(end) end.setHours(23,59,59,999);
        return { startDate: start, endDate: end };
    }
  }, [datePreset, customStartDate, customEndDate]);

  const filteredTickets = useMemo(() => {
    return tickets.filter(ticket => {
      if (ticket.status !== TicketStatus.COMPLETED) return false;
      const ticketDate = new Date(ticket.createdAt);
      const isAfterStart = startDate ? ticketDate >= startDate : true;
      const isBeforeEnd = endDate ? ticketDate <= endDate : true;
      return isAfterStart && isBeforeEnd;
    });
  }, [tickets, startDate, endDate]);

  const filteredExpenses = useMemo(() => {
    return expenses.filter(expense => {
      const expenseDate = new Date(expense.date);
      const isAfterStart = startDate ? expenseDate >= startDate : true;
      const isBeforeEnd = endDate ? expenseDate <= endDate : true;
      return isAfterStart && isBeforeEnd;
    });
  }, [expenses, startDate, endDate]);

  const renderReport = () => {
    switch (activeReport) {
      case 'sales':
        return <SalesProfitReport tickets={filteredTickets} />;
      case 'tax':
        return <TaxReport tickets={filteredTickets} />;
      case 'bestsellers':
        return <BestSellersReport tickets={filteredTickets} />;
      case 'pnl':
        return <ProfitAndLossReport tickets={filteredTickets} expenses={filteredExpenses} />;
      case 'tech':
        return <TechnicianPerformanceReport tickets={filteredTickets} users={users} />;
      case 'inventory_aging':
        return <InventoryAgingReport inventoryItems={inventoryItems} />;
      case 'customer':
        return <CustomerReports tickets={filteredTickets} customers={customers} />;
      default:
        return null;
    }
  };
  
  const reportTabs: { id: ReportType, label: string }[] = [
      { id: 'sales', label: 'Sales & Profit' },
      { id: 'pnl', label: 'Profit & Loss' },
      { id: 'tax', label: 'Tax' },
      { id: 'bestsellers', label: 'Best Sellers' },
      { id: 'tech', label: 'Technician Performance' },
      { id: 'inventory_aging', label: 'Inventory Aging' },
      { id: 'customer', label: 'Customer Reports' },
  ];
  
  const datePresets: { id: DatePreset, label: string }[] = [
      { id: 'today', label: 'Today' },
      { id: 'week', label: 'This Week' },
      { id: 'month', label: 'This Month' },
      { id: 'custom', label: 'Custom' },
  ];

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-dark-panel p-4 rounded-lg shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <label className="text-sm font-medium text-dark-text-secondary">Date Range:</label>
          <div className="flex rounded-md shadow-sm bg-dark-bg border border-dark-border">
            {datePresets.map(preset => (
                <button
                    key={preset.id}
                    onClick={() => setDatePreset(preset.id)}
                    className={`px-3 py-1.5 text-sm font-medium transition-colors ${datePreset === preset.id ? 'bg-brand-green text-dark-bg' : 'text-dark-text-primary hover:bg-dark-panel-light'} first:rounded-l-md last:rounded-r-md`}
                >
                    {preset.label}
                </button>
            ))}
          </div>
        </div>
        {datePreset === 'custom' && (
            <div className="flex items-center gap-2">
                <input type="date" value={customStartDate} onChange={e => setCustomStartDate(e.target.value)} className="bg-dark-bg border-dark-border rounded-md text-sm"/>
                <span className="text-dark-text-secondary">to</span>
                <input type="date" value={customEndDate} onChange={e => setCustomEndDate(e.target.value)} className="bg-dark-bg border-dark-border rounded-md text-sm"/>
            </div>
        )}
      </div>

      {/* Report Tabs */}
       <div className="border-b border-dark-border">
            <nav className="-mb-px flex space-x-6 overflow-x-auto">
                {reportTabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveReport(tab.id)}
                        className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors
                            ${activeReport === tab.id 
                                ? 'border-brand-green text-brand-green' 
                                : 'border-transparent text-dark-text-secondary hover:text-white'
                            }
                        `}
                    >
                        {tab.label}
                    </button>
                ))}
            </nav>
        </div>

      {/* Report Content */}
      <div>
        {renderReport()}
      </div>
    </div>
  );
};

export default ReportsView;