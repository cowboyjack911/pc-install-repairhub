
import React, { useMemo } from 'react';
import { InventoryItem } from '../../types';

interface InventoryAgingReportProps {
    inventoryItems: InventoryItem[];
}

type AgeBucket = '0-30' | '31-60' | '61-90' | '91+';

const InventoryAgingReport: React.FC<InventoryAgingReportProps> = ({ inventoryItems }) => {
    const agingData = useMemo(() => {
        const buckets: Record<AgeBucket, InventoryItem[]> = {
            '0-30': [],
            '31-60': [],
            '61-90': [],
            '91+': [],
        };
        const now = new Date().getTime();

        inventoryItems.forEach(item => {
            if (item.lastReceivedDate) {
                const diffDays = Math.floor((now - new Date(item.lastReceivedDate).getTime()) / (1000 * 3600 * 24));
                if (diffDays <= 30) buckets['0-30'].push(item);
                else if (diffDays <= 60) buckets['31-60'].push(item);
                else if (diffDays <= 90) buckets['61-90'].push(item);
                else buckets['91+'].push(item);
            } else {
                // Items without a received date go to the oldest bucket
                buckets['91+'].push(item);
            }
        });
        return buckets;
    }, [inventoryItems]);

    const renderBucket = (bucketName: AgeBucket, items: InventoryItem[]) => (
        <div key={bucketName} className="bg-dark-panel p-4 rounded-lg">
            <h4 className="font-semibold text-dark-text-primary mb-2">{bucketName} Days</h4>
            {items.length > 0 ? (
                <ul className="divide-y divide-dark-border">
                    {items.map(item => (
                        <li key={item.id} className="py-2 text-sm flex justify-between">
                            <span className="text-dark-text-secondary">{item.name}</span>
                            <span className="font-medium text-dark-text-primary">{item.quantity} units</span>
                        </li>
                    ))}
                </ul>
            ) : <p className="text-sm text-dark-text-tertiary">No items in this range.</p>}
        </div>
    );

    return (
        <div className="space-y-6">
             <h3 className="text-lg font-semibold text-dark-text-primary">Inventory Aging by Last Received Date</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {renderBucket('0-30', agingData['0-30'])}
                {renderBucket('31-60', agingData['31-60'])}
                {renderBucket('61-90', agingData['61-90'])}
                {renderBucket('91+', agingData['91+'])}
             </div>
        </div>
    );
};

export default InventoryAgingReport;
