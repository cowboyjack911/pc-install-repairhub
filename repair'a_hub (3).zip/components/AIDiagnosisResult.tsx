
import React from 'react';
import { DiagnosticResult, SuggestedPart } from '../types';
import AIIcon from './icons/AIIcon';
import PlusIcon from './icons/PlusIcon';

interface AIDiagnosisResultProps {
  result: DiagnosticResult;
  onAddPart: (part: SuggestedPart) => void;
  addedPartSKUs: Set<string>;
}

const AIDiagnosisResult: React.FC<AIDiagnosisResultProps> = ({ result, onAddPart, addedPartSKUs }) => {
  return (
    <div className="mt-4 p-4 bg-dark-bg rounded-lg border border-dark-border space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <AIIcon className="h-5 w-5 text-brand-green" />
        <h4 className="text-md font-semibold text-dark-text-primary">AI Diagnostic Summary</h4>
      </div>

      <div>
        <h5 className="font-semibold text-sm text-dark-text-secondary mb-2">Potential Causes</h5>
        <ul className="list-disc list-inside text-sm text-dark-text-secondary space-y-1">
          {result.potentialCauses.map((cause, index) => <li key={index}>{cause}</li>)}
        </ul>
      </div>

      <div>
        <h5 className="font-semibold text-sm text-dark-text-secondary mb-2">Suggested Parts from Inventory</h5>
        {result.suggestedParts.length > 0 ? (
          <div className="space-y-2">
            {result.suggestedParts.map((part, index) => {
              const isAdded = addedPartSKUs.has(part.sku);
              return (
                <div key={index} className="flex justify-between items-center bg-dark-panel-light p-2 rounded-md">
                  <div>
                    <p className="font-medium text-sm text-dark-text-primary">{part.partName}</p>
                    <p className="text-xs text-dark-text-tertiary">SKU: {part.sku}</p>
                    <p className="text-xs text-dark-text-tertiary mt-1 italic">Reason: {part.reason}</p>
                  </div>
                  <button
                    onClick={() => onAddPart(part)}
                    disabled={isAdded}
                    className="flex items-center gap-1 text-sm bg-brand-green hover:bg-brand-green-darker text-dark-bg font-bold py-1 px-2 rounded-md transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
                  >
                    <PlusIcon className="h-4 w-4" /> {isAdded ? 'Added' : 'Add'}
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-sm text-dark-text-secondary">No specific parts suggested from inventory.</p>
        )}
      </div>

      <div>
        <h5 className="font-semibold text-sm text-dark-text-secondary">Estimated Difficulty</h5>
        <p className="text-sm text-dark-text-primary font-bold">{result.estimatedDifficulty}</p>
      </div>
    </div>
  );
};

export default AIDiagnosisResult;
