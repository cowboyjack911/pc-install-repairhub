import React, { useState, useEffect, useCallback } from 'react';
import { getRepairSuggestions } from '../services/geminiService';
import CloseIcon from './icons/CloseIcon';
import AIIcon from './icons/AIIcon';

interface RepairSuggesterProps {
  isOpen: boolean;
  onClose: () => void;
  deviceModel: string;
  issueDescription: string;
}

const RepairSuggester: React.FC<RepairSuggesterProps> = ({
  isOpen,
  onClose,
  deviceModel,
  issueDescription,
}) => {
  const [suggestions, setSuggestions] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSuggestions = useCallback(async () => {
    if (!deviceModel || !issueDescription) return;
    setIsLoading(true);
    setError(null);
    try {
      const result = await getRepairSuggestions(deviceModel, issueDescription);
      setSuggestions(result);
    } catch (err) {
      setError('Failed to fetch suggestions.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [deviceModel, issueDescription]);

  useEffect(() => {
    if (isOpen) {
      fetchSuggestions();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  const formatSuggestions = (text: string) => {
    return text
      .split('\n')
      .map((line, index) => {
        if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
          return <li key={index} className="ml-6 list-disc">{line.substring(2)}</li>;
        }
        if (/^\d+\./.test(line.trim())) {
            return <li key={index} className="ml-6 list-decimal">{line.replace(/^\d+\./, '').trim()}</li>
        }
        if (line.toLowerCase().includes('diagnosis:') || line.toLowerCase().includes('repair steps:') || line.toLowerCase().includes('required tools:')) {
            return <h3 key={index} className="text-lg font-semibold mt-4 mb-2 text-brand-green">{line}</h3>
        }
        return <p key={index} className="my-1">{line}</p>;
      });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <div className="flex items-center gap-3">
            <AIIcon className="h-6 w-6 text-brand-green" />
            <h2 className="text-xl font-bold text-dark-text-primary">AI Repair Assistant</h2>
          </div>
          <button
            onClick={onClose}
            className="text-dark-text-secondary hover:text-dark-text-primary transition-colors"
          >
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6 overflow-y-auto">
          {isLoading && (
            <div className="flex flex-col items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green"></div>
                <p className="mt-4 text-dark-text-secondary">Analyzing issue and generating repair steps...</p>
            </div>
          )}
          {error && <div className="text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</div>}
          {suggestions && !isLoading && (
            <div className="prose prose-sm prose-invert max-w-none text-dark-text-secondary">
                {formatSuggestions(suggestions)}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default RepairSuggester;