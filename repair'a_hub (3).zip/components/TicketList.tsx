import React from 'react';
// FIX: Import User type
import { Ticket, TicketStatus, User } from '../types';
import TicketItem from './TicketItem';

interface TicketListProps {
  tickets: Ticket[];
  onUpdateStatus: (ticketId: string, status: TicketStatus) => void;
  onAddQuote: (ticketId: string) => void;
  onAddNote: (ticketId: string, noteContent: string) => void;
  onPrintTicket: (ticket: Ticket) => void;
  onSendMessage: (ticket: Ticket) => void;
  // FIX: Add props for technician assignment
  user: User;
  technicians: User[];
  onAssignTechnician: (ticketId: string, technicianId: string) => void;
}

const TicketList: React.FC<TicketListProps> = ({ tickets, onUpdateStatus, onAddQuote, onAddNote, onPrintTicket, onSendMessage, user, technicians, onAssignTechnician }) => {
  if (tickets.length === 0) {
    return (
      <div className="text-center py-16 bg-dark-panel rounded-lg">
        <h3 className="text-xl font-medium text-dark-text-primary">No tickets found.</h3>
        <p className="mt-2 text-base text-dark-text-secondary">
          Click "Add New Ticket" to get started.
        </p>
      </div>
    );
  }

  return (
    <div>
      {tickets.map((ticket) => (
        <TicketItem 
          key={ticket.id} 
          ticket={ticket} 
          onUpdateStatus={onUpdateStatus} 
          onAddQuote={onAddQuote}
          onAddNote={onAddNote}
          onPrintTicket={onPrintTicket}
          onSendMessage={onSendMessage}
          // FIX: Pass technician assignment props down
          user={user}
          technicians={technicians}
          onAssignTechnician={onAssignTechnician}
        />
      ))}
    </div>
  );
};

export default TicketList;