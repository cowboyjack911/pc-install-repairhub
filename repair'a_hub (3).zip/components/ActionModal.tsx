import React from 'react';
import CloseIcon from './icons/CloseIcon';

interface ActionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ActionButton: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
    <button className={`bg-brand-teal text-white font-semibold py-4 rounded-lg hover:bg-teal-700 transition-colors ${className}`}>
        {children}
    </button>
);

const ActionModal: React.FC<ActionModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Action</h2>
          <button type="button" onClick={onClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>
        <main className="p-6 grid grid-cols-3 gap-4">
            <ActionButton>Pause</ActionButton>
            <ActionButton>Open Pause</ActionButton>
            <ActionButton>View Self Check-In</ActionButton>
            <ActionButton>View Refund</ActionButton>
            <ActionButton>View Estimates</ActionButton>
            <ActionButton>Create Inquiry</ActionButton>
            <ActionButton>Open Cash Drawer</ActionButton>
        </main>
      </div>
    </div>
  );
};

export default ActionModal;
