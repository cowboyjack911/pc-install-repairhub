
import React, { useState } from 'react';
import CloseIcon from './icons/CloseIcon';

interface GiftCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGiftCardToCart: (value: number) => void;
}

const GiftCardModal: React.FC<GiftCardModalProps> = ({ isOpen, onClose, onAddGiftCardToCart }) => {
  const [amount, setAmount] = useState('');

  const handleAdd = () => {
    const value = parseFloat(amount);
    if (isNaN(value) || value <= 0) {
      alert("Please enter a valid amount for the gift card.");
      return;
    }
    onAddGiftCardToCart(value);
  };
  
  const handleClose = () => {
    setAmount('');
    onClose();
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-sm">
        <header className="flex items-center justify-between p-4 border-b border-dark-border">
          <h2 className="text-xl font-bold text-dark-text-primary">Sell Gift Card</h2>
          <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <main className="p-6">
          <label htmlFor="giftCardAmount" className="block text-sm font-medium text-dark-text-secondary">
            Gift Card Value ($)
          </label>
          <input
            type="number"
            id="giftCardAmount"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
            placeholder="e.g., 50.00"
            step="0.01"
            min="0"
            autoFocus
          />
        </main>
        
        <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2 text-sm font-medium text-dark-text-primary"
          >
            Cancel
          </button>
          <button
            onClick={handleAdd}
            className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border-transparent rounded-md shadow-sm hover:bg-brand-green-darker"
          >
            Add to Cart
          </button>
        </footer>
      </div>
    </div>
  );
};

export default GiftCardModal;
