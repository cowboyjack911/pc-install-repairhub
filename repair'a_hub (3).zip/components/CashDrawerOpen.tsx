
import React, { useEffect } from 'react';

interface CashDrawerOpenProps {
  isOpen: boolean;
  onClose: () => void;
}

const CashDrawerOpen: React.FC<CashDrawerOpenProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onClose();
      }, 2500); // Automatically close after 2.5 seconds
      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 bg-dark-panel-light text-white px-6 py-3 rounded-lg shadow-2xl z-50 animate-fade-in">
      <p className="font-semibold text-center">Cash Drawer Open</p>
    </div>
  );
};

export default CashDrawerOpen;
