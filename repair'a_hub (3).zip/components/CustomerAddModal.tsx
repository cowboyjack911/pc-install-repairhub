
import React, { useState, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Customer, Omit } from '../types';
import CloseIcon from './icons/CloseIcon';

interface CustomerAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Omit<Customer, 'id'> | Customer) => void;
  editingCustomer?: Customer | null;
}

const CustomerAddModal: React.FC<CustomerAddModalProps> = ({ isOpen, onClose, onSave, editingCustomer }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const isEditing = !!editingCustomer;

  useEffect(() => {
    if (isOpen) {
      setName(editingCustomer?.name || '');
      setPhone(editingCustomer?.phone || '');
      setEmail(editingCustomer?.email || '');
    }
  }, [isOpen, editingCustomer]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) {
      alert("Customer name is required.");
      return;
    }
    
    if (isEditing && editingCustomer) {
      onSave({ ...editingCustomer, name, phone, email });
    } else {
      onSave({ name, phone, email });
    }
  };
  
  const handleClose = () => {
    // Reset form on close
    setName('');
    setPhone('');
    setEmail('');
    onClose();
  }

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
      <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
        <form onSubmit={handleSubmit}>
          <header className="flex items-center justify-between p-4 border-b border-dark-border">
            <h2 className="text-xl font-bold text-dark-text-primary">{isEditing ? 'Edit Customer' : 'Add New Customer'}</h2>
            <button
              type="button"
              onClick={handleClose}
              className="text-dark-text-tertiary hover:text-white transition-colors"
            >
              <CloseIcon className="h-6 w-6" />
            </button>
          </header>

          <main className="p-6 space-y-4">
            <div>
              <label htmlFor="customerName" className="block text-sm font-medium text-dark-text-secondary">Full Name</label>
              <input type="text" id="customerName" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" required />
            </div>
             <div>
              <label htmlFor="customerPhone" className="block text-sm font-medium text-dark-text-secondary">Phone Number</label>
              <input type="tel" id="customerPhone" value={phone} onChange={e => setPhone(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
            <div>
              <label htmlFor="customerEmail" className="block text-sm font-medium text-dark-text-secondary">Email Address</label>
              <input type="email" id="customerEmail" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white" />
            </div>
          </main>

          <footer className="flex justify-end p-4 bg-dark-panel-light/50 rounded-b-2xl space-x-3">
            <button type="button" onClick={handleClose} className="px-4 py-2 text-sm font-medium text-dark-text-primary bg-dark-panel-light border border-dark-border rounded-md shadow-sm hover:bg-dark-border focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-panel focus:ring-brand-green">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-panel focus:ring-brand-green">
              Save Customer
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default CustomerAddModal;