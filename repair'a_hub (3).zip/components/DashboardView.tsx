
import React from 'react';
import { DashboardData } from '../types';
import StatCard from './dashboard/StatCard';
import SalesChart from './dashboard/SalesChart';
import RecentActivityFeed from './dashboard/RecentActivityFeed';
import ChartBarIcon from './icons/ChartBarIcon';
import WrenchScrewdriverIcon from './icons/WrenchScrewdriverIcon';
import CheckBadgeIcon from './icons/CheckBadgeIcon';
import UsersIcon from './icons/UsersIcon';
import CurrencyDollarIcon from './icons/CurrencyDollarIcon';
import ArchiveBoxArrowDownIcon from './icons/ArchiveBoxArrowDownIcon';

interface DashboardViewProps {
  data: DashboardData;
}

const DashboardView: React.FC<DashboardViewProps> = ({ data }) => {
  return (
    <div className="space-y-8">
      {/* KPI Stats */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard 
            title="Today's Revenue" 
            value={`$${data.kpis.todaysRevenue.toFixed(2)}`} 
            icon={ChartBarIcon} 
        />
        <StatCard 
            title="Today's Profit" 
            value={`$${data.kpis.todaysProfit.toFixed(2)}`} 
            icon={CurrencyDollarIcon}
        />
        <StatCard 
            title="Pending Repairs" 
            value={data.kpis.pendingRepairs.toString()} 
            icon={WrenchScrewdriverIcon} 
        />
        <StatCard 
            title="Completed This Week" 
            value={data.kpis.completedThisWeek.toString()} 
            icon={CheckBadgeIcon} 
        />
        <StatCard 
            title="Total Customers" 
            value={data.kpis.totalCustomers.toString()} 
            icon={UsersIcon} 
        />
        <StatCard 
            title="Low Stock Items" 
            value={data.kpis.lowStockItems.toString()} 
            icon={ArchiveBoxArrowDownIcon}
        />
      </div>

      {/* Main Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sales Chart */}
        <div className="lg:col-span-2">
           <SalesChart salesData={data.salesLast7Days} />
        </div>
        
        {/* Recent Activity */}
        <div className="lg:col-span-1">
            <RecentActivityFeed tickets={data.recentActivity} />
        </div>
      </div>
    </div>
  );
};

export default DashboardView;