

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { InventoryItem, Omit } from '../types';
import PlusIcon from './icons/PlusIcon';
import SearchIcon from './icons/SearchIcon';
import InventoryItemModal from './InventoryItemModal';
import PencilIcon from './icons/PencilIcon';
import TrashIcon from './icons/TrashIcon';
import ArrowUpTrayIcon from './icons/ArrowUpTrayIcon';
import InventoryImportModal from './inventory/InventoryImportModal';
import StockAdjustmentModal from './inventory/StockAdjustmentModal';
import ArrowsUpDownIcon from './icons/ArrowsUpDownIcon';
import ExclamationTriangleIcon from './icons/ExclamationTriangleIcon';

interface InventoryManagementProps {
  items: InventoryItem[];
  onAddItem: (itemData: Omit<InventoryItem, 'id'>) => void;
  onUpdateItem: (item: InventoryItem) => void;
  onDeleteItem: (itemId: string) => void;
  onBulkImport: (items: Omit<InventoryItem, 'id'>[]) => void;
  onAdjustStock: (itemId: string, newQuantity: number, reason: string) => void;
}

const InventoryManagement: React.FC<InventoryManagementProps> = ({ items, onAddItem, onUpdateItem, onDeleteItem, onBulkImport, onAdjustStock }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredItems = useMemo(() => {
    if (!searchTerm) return items;
    return items.filter(
      item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.sku.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [items, searchTerm]);

  const handleOpenModal = (item: InventoryItem | null = null) => {
    setEditingItem(item);
    setIsModalOpen(true);
  };

  const handleOpenAdjustModal = (item: InventoryItem) => {
    setEditingItem(item);
    setIsAdjustModalOpen(true);
  };

  const handleCloseModal = () => {
    setEditingItem(null);
    setIsModalOpen(false);
    setIsAdjustModalOpen(false);
  };

  const handleSaveItem = (itemData: Omit<InventoryItem, 'id'> | InventoryItem) => {
    if ('id' in itemData) {
      onUpdateItem(itemData);
    } else {
      onAddItem(itemData);
    }
    handleCloseModal();
  };

  const handleImport = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        try {
            const rows = text.split('\n').slice(1); // Skip header
            const newItems: Omit<InventoryItem, 'id'>[] = [];
            for (const row of rows) {
              if (row.trim() === '') continue; // Skip empty rows
              const [name, sku, quantity, cost] = row.split(',');
              if (name && sku && quantity && cost && !isNaN(parseInt(quantity.trim(), 10)) && !isNaN(parseFloat(cost.trim()))) {
                newItems.push({
                  name: name.trim(),
                  sku: sku.trim(),
                  quantity: parseInt(quantity.trim(), 10),
                  cost: parseFloat(cost.trim()),
                });
              } else {
                console.warn(`Skipping malformed CSV row: ${row}`);
              }
            }
            if (newItems.length > 0) {
              onBulkImport(newItems);
            } else {
              alert('Could not parse any valid items from the CSV file. Please check the format and content.');
            }
        } catch (e) {
            console.error("Error parsing CSV:", e);
            alert("An error occurred while parsing the file. Please ensure it is a valid CSV.");
        }
      }
    };
    reader.onerror = () => {
        alert("Failed to read the file.");
    }
    reader.readAsText(file);
  };

  return (
    <>
      <div>
        {/* Header */}
        <div className="sm:flex sm:items-center sm:justify-between">
          <div>
            {/* Title handled by StaffHeader */}
          </div>
          <div className="flex items-center gap-4 mt-4 sm:mt-0">
            <button
              onClick={() => setIsImportModalOpen(true)}
              className="flex items-center justify-center gap-2 rounded-lg bg-dark-panel-light px-5 py-3 text-dark-text-primary transition hover:bg-dark-border font-bold"
              type="button"
            >
              <ArrowUpTrayIcon className="w-5 h-5" />
              <span className="text-sm font-medium">Import</span>
            </button>
            <button
              onClick={() => handleOpenModal()}
              className="flex items-center justify-center gap-2 rounded-lg bg-brand-green px-5 py-3 text-dark-bg transition hover:bg-brand-green-darker font-bold"
              type="button"
            >
              <PlusIcon className="w-5 h-5" />
              <span className="text-sm font-medium">Add New Item</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-5 w-5 text-dark-text-tertiary" />
            </div>
            <input
              type="text"
              placeholder="Search by item name or SKU..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="bg-dark-panel border border-dark-border rounded-md pl-10 pr-4 py-2 text-sm w-full sm:w-72 focus:ring-brand-green focus:border-brand-green"
            />
          </div>
        </div>

        {/* Inventory Table */}
        <div className="mt-4 overflow-x-auto">
          <div className="align-middle inline-block min-w-full">
            <div className="shadow overflow-hidden border-b border-dark-border rounded-lg">
              <table className="min-w-full divide-y divide-dark-border">
                <thead className="bg-dark-panel">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Item Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">SKU</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Quantity</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-dark-text-secondary uppercase tracking-wider">Cost</th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-dark-panel-light divide-y divide-dark-border">
                  {filteredItems.map((item) => {
                    const isLowStock = item.reorderPoint !== undefined && item.quantity <= item.reorderPoint;
                    return (
                        <tr key={item.id} className={isLowStock ? 'bg-red-900/20' : ''}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-dark-text-primary">{item.name}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">{item.sku}</td>
                        <td className={`px-6 py-4 whitespace-nowrap text-sm font-bold ${isLowStock ? 'text-red-400' : 'text-dark-text-secondary'}`}>
                            <div className="flex items-center gap-2">
                                {isLowStock && <span title={`Low stock! Reorder point is ${item.reorderPoint || 0}`}><ExclamationTriangleIcon className="w-4 h-4 text-red-400"/></span>}
                                <span>{item.quantity}</span>
                            </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-text-secondary">${item.cost.toFixed(2)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                            <button onClick={() => handleOpenAdjustModal(item)} className="text-gray-400 hover:text-white" title="Adjust Stock" aria-label={`Adjust stock for ${item.name}`}><ArrowsUpDownIcon className="w-5 h-5"/></button>
                            <button onClick={() => handleOpenModal(item)} className="text-dark-accent-blue hover:text-blue-400" title="Edit Item" aria-label={`Edit ${item.name}`}><PencilIcon className="w-5 h-5"/></button>
                            <button onClick={() => onDeleteItem(item.id)} className="text-red-400 hover:text-red-300" title="Delete Item" aria-label={`Delete ${item.name}`}><TrashIcon className="w-5 h-5"/></button>
                        </td>
                        </tr>
                    )
                })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {filteredItems.length === 0 && (
          <div className="text-center py-16 bg-dark-panel rounded-lg mt-4">
            <h3 className="text-xl font-medium text-dark-text-primary">No inventory items found.</h3>
            <p className="mt-2 text-base text-dark-text-secondary">
              Click "Add New Item" to get started or try a different search term.
            </p>
          </div>
        )}
      </div>
      <InventoryItemModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSaveItem}
        item={editingItem}
      />
      <InventoryImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImport}
      />
      <StockAdjustmentModal
        isOpen={isAdjustModalOpen}
        onClose={handleCloseModal}
        onSave={onAdjustStock}
        item={editingItem}
      />
    </>
  );
};

export default InventoryManagement;