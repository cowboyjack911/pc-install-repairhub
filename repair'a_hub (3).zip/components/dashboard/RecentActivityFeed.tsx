import React from 'react';
import { Ticket } from '../../types';
import StatusBadge from '../StatusBadge';

interface RecentActivityFeedProps {
  tickets: Ticket[];
}

const RecentActivityFeed: React.FC<RecentActivityFeedProps> = ({ tickets }) => {
  return (
    <div className="bg-dark-panel p-6 rounded-lg shadow-lg h-full">
      <h3 className="text-lg font-semibold text-dark-text-primary mb-4">
        Recent Activity
      </h3>
      <div className="space-y-4">
        {tickets.length > 0 ? (
          tickets.map(ticket => (
            <div key={ticket.id} className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-dark-text-primary">{ticket.customer.name}</p>
                <p className="text-xs text-dark-text-secondary">
                  {ticket.items[0]?.name || 'New Ticket'}
                </p>
                 <p className="text-xs text-dark-text-tertiary mt-1">
                    {ticket.createdAt.toLocaleDateString()}
                 </p>
              </div>
              <StatusBadge status={ticket.status} />
            </div>
          ))
        ) : (
          <p className="text-sm text-dark-text-secondary">No recent activity.</p>
        )}
      </div>
    </div>
  );
};

export default RecentActivityFeed;
