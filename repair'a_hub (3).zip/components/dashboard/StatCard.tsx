import React from 'react';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon }) => {
  return (
    <div className="bg-dark-panel p-6 rounded-lg shadow-lg flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-dark-text-secondary">{title}</p>
        <p className="text-3xl font-bold text-dark-text-primary mt-1">{value}</p>
      </div>
      <div className="bg-dark-panel-light p-3 rounded-full">
        <Icon className="h-6 w-6 text-brand-green" />
      </div>
    </div>
  );
};

export default StatCard;
