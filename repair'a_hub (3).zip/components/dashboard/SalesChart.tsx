import React from 'react';

interface SalesChartProps {
  salesData: { date: string; revenue: number }[];
}

const SalesChart: React.FC<SalesChartProps> = ({ salesData }) => {
  const maxRevenue = Math.max(...salesData.map(d => d.revenue), 1); // Avoid division by zero

  return (
    <div className="bg-dark-panel p-6 rounded-lg shadow-lg h-full">
      <h3 className="text-lg font-semibold text-dark-text-primary mb-4">
        Weekly Revenue
      </h3>
      <div className="flex justify-around items-end h-64 space-x-2">
        {salesData.map((data, index) => (
          <div key={index} className="flex flex-col items-center flex-1">
            <div className="text-xs text-dark-text-primary font-bold mb-1">${data.revenue.toFixed(0)}</div>
            <div
              className="w-full bg-brand-green rounded-t-md hover:bg-brand-green-darker transition-colors"
              style={{ height: `${(data.revenue / maxRevenue) * 100}%` }}
              title={`$${data.revenue.toFixed(2)}`}
            />
            <div className="text-xs text-dark-text-secondary mt-2">{data.date}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SalesChart;
