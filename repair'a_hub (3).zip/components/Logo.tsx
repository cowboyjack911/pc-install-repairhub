import React from 'react';
import { BusinessInfo } from '../types';

interface LogoProps {
  businessInfo: BusinessInfo;
}

const Logo: React.FC<LogoProps> = ({ businessInfo }) => {
  const { name, tagline, logoUrl } = businessInfo;

  return (
    <div>
      {logoUrl ? (
        <img src={logoUrl} alt={`${name} logo`} className="max-h-12" />
      ) : (
        <>
          <h1 className="text-2xl font-black text-brand-green font-display tracking-wider uppercase">
            {name}
          </h1>
          <p className="text-xs text-brand-green opacity-80 tracking-widest font-bold">
            {tagline}
          </p>
        </>
      )}
    </div>
  );
};

export default Logo;