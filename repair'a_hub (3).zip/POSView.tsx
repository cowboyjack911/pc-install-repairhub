

import React, { useState, useMemo } from 'react';
import BookingView from './components/BookingView';
// FIX: Omit is a built-in type and does not need to be imported.
import { CartItem, Customer, Product, Ticket, TicketStatus, InventoryItem, PaymentMethodSettings, PaymentDetails, Discount, TaxSettings, GiftCard } from './types';
import { QUICK_ADD_PRODUCTS, WALK_IN_CUSTOMER } from './constants';
import CustomerSearchModal from './components/CustomerSearchModal';
import CustomerAddModal from './components/CustomerAddModal';
import CustomerDetailModal from './components/CustomerDetailModal';
import CheckoutModal from './components/CheckoutModal';
import ReceiptModal from './components/ReceiptModal';
import DiscountModal from './components/DiscountModal';
import GiftCardModal from './components/GiftCardModal';
import CustomerInfo from './components/CustomerInfo';
import ActionModal from './components/ActionModal';
import CartItemDisplay from './components/CartItemDisplay';
import ToolboxIcon from './components/icons/ToolboxIcon';
import CashDrawerOpen from './components/CashDrawerOpen';
import PackageIcon from './components/icons/PackageIcon';
import POSRepairModal from './components/POSRepairModal';

interface POSViewProps {
  onSaveTicket: (ticket: Ticket) => void;
  onCompleteSale: (ticket: Ticket) => void;
  customers: Customer[];
  tickets: Ticket[];
  onAddNewCustomer: (customerData: Omit<Customer, 'id'>) => Customer;
  inventoryItems: InventoryItem[];
  paymentMethodSettings: PaymentMethodSettings;
  taxSettings: TaxSettings;
  onUpdateCustomer: (customer: Customer) => void;
  giftCards: GiftCard[];
  onPrintTicket: (ticket: Ticket) => void;
}

const POSView: React.FC<POSViewProps> = ({ onSaveTicket, onCompleteSale, customers, tickets, onAddNewCustomer, inventoryItems, paymentMethodSettings, taxSettings, onUpdateCustomer, giftCards, onPrintTicket }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customer, setCustomer] = useState<Customer>(WALK_IN_CUSTOMER);
  const [discount, setDiscount] = useState<Discount>(null);
  
  const [isCustomerSearchModalOpen, setIsCustomerSearchModalOpen] = useState(false);
  const [isCustomerAddModalOpen, setIsCustomerAddModalOpen] = useState(false);
  const [isCustomerDetailModalOpen, setIsCustomerDetailModalOpen] = useState(false);
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState(false);
  const [isGiftCardModalOpen, setIsGiftCardModalOpen] = useState(false);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [isActionModalOpen, setIsActionModalOpen] = useState(false);
  const [completedTicket, setCompletedTicket] = useState<Ticket | null>(null);
  const [showCashDrawer, setShowCashDrawer] = useState(false);
  
  const [repairModalProduct, setRepairModalProduct] = useState<Product | null>(null);

  const isCartEmpty = cart.length === 0;

  // Load cart from local storage on initial render
  useState(() => {
    try {
      const savedCart = localStorage.getItem('savedCart');
      const savedCustomer = localStorage.getItem('savedCustomer');
      if (savedCart) {
        setCart(JSON.parse(savedCart));
      }
      if (savedCustomer) {
        setCustomer(JSON.parse(savedCustomer));
      }
    } catch (error) {
      console.error("Failed to load cart from local storage", error);
    }
  });

  const calculateTotals = () => {
    const subtotal = cart.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
    const totalCost = cart.reduce((acc, item) => acc + (item.cost || 0), 0);
    const discountAmount = discount
      ? discount.type === 'fixed'
        ? Math.min(discount.value, subtotal) // Cap discount at subtotal
        : subtotal * (discount.value / 100)
      : 0;
    
    const taxableAmount = subtotal - discountAmount;
    const totalTaxRate = taxSettings.baseRate + taxSettings.rules.filter(r => r.isEnabled).reduce((sum, r) => sum + r.rate, 0);
    const tax = taxableAmount * (totalTaxRate / 100);
    const total = taxableAmount + tax;

    return { subtotal, discountAmount, tax, total, totalCost };
  };
  
  const { subtotal, discountAmount, tax, total, totalCost } = useMemo(calculateTotals, [cart, discount, taxSettings]);


  const handleAddRepairItemToCart = (item: CartItem) => {
    const itemSubtotal = item.unitPrice * item.quantity;
    const totalTaxRate = taxSettings.baseRate + taxSettings.rules.filter(r => r.isEnabled).reduce((sum, r) => sum + r.rate, 0);
    const itemTax = itemSubtotal * (totalTaxRate / 100);
    const finalItem = { ...item, tax: itemTax };
    setCart(prev => [...prev, finalItem]);
    setRepairModalProduct(null); // Close modal
  };
  
  const handleAddProductToCart = (product: Product) => {
    if (product.category === 'Repairs') {
        setRepairModalProduct(product);
        return;
    }
    
    if (product.id === 'qa_gift_card') {
        setIsGiftCardModalOpen(true);
        return;
    }
    const existingCartItem = cart.find(item => item.id === product.id);

    if (existingCartItem) {
        // If item already exists, increase quantity
        setCart(cart.map(item => 
            item.id === product.id 
                ? { ...item, quantity: item.quantity + 1 } 
                : item
        ));
    } else {
        const itemSubtotal = (product.price || 0) * 1;
        const itemTax = itemSubtotal * ((taxSettings.baseRate + taxSettings.rules.filter(r => r.isEnabled).reduce((sum, r) => sum + r.rate, 0)) / 100);

        // Otherwise, add new item to cart
        const newCartItem: CartItem = {
            ...product,
            cartItemId: crypto.randomUUID(),
            quantity: 1,
            unitPrice: product.price || 0,
            cost: (product.cost || 0) * 1,
            tax: itemTax
        };
        setCart(prevCart => [...prevCart, newCartItem]);
    }
  };

    const handleAddInventoryItemToCart = (item: InventoryItem) => {
        const itemSubtotal = (item.price || 0) * 1;
        const itemTax = itemSubtotal * ((taxSettings.baseRate + taxSettings.rules.filter(r => r.isEnabled).reduce((sum, r) => sum + r.rate, 0)) / 100);

        const newCartItem: CartItem = {
            cartItemId: crypto.randomUUID(),
            id: item.id,
            name: item.name,
            category: 'Products',
            icon: PackageIcon,
            quantity: 1,
            unitPrice: item.price || 0,
            cost: (item.cost || 0) * 1,
            tax: itemTax
        };
        setCart(prevCart => [...prevCart, newCartItem]);
    };

  const handleAddGiftCardToCart = (value: number) => {
    const giftCardProduct = QUICK_ADD_PRODUCTS.find(p => p.id === 'qa_gift_card');
    if (!giftCardProduct) return;

    const newCartItem: CartItem = {
        ...giftCardProduct,
        cartItemId: crypto.randomUUID(),
        name: `Gift Card - $${value.toFixed(2)}`,
        quantity: 1,
        unitPrice: value,
        cost: 0,
        tax: 0,
        isGiftCard: true,
        giftCardValue: value,
    };
    setCart(prev => [...prev, newCartItem]);
    setIsGiftCardModalOpen(false);
  };
  
  const handleSaveAsTicket = () => {
    if (cart.length === 0) {
      alert("Cannot save an empty cart as a ticket.");
      return;
    }

    const newTicket: Ticket = {
      id: `tkt_${crypto.randomUUID()}`,
      customer,
      items: cart,
      status: TicketStatus.NEW,
      subtotal,
      discount: discountAmount,
      tax,
      total,
      totalCost,
      createdAt: new Date(),
      notes: [],
    };
    
    onSaveTicket(newTicket);
    
    // Reset state after saving
    setCart([]);
    setCustomer(WALK_IN_CUSTOMER);
    setDiscount(null);
    localStorage.removeItem('savedCart');
    localStorage.removeItem('savedCustomer');
  };

  const handleCheckout = () => {
    if (isCartEmpty) {
      alert("Cannot check out with an empty cart.");
      return;
    }
    setIsCheckoutModalOpen(true);
  };

  const handleProcessPayment = (paymentDetails: PaymentDetails) => {
    const newTicket: Ticket = {
      id: `tkt_${crypto.randomUUID()}`,
      customer,
      items: cart,
      status: TicketStatus.COMPLETED,
      subtotal,
      discount: discountAmount,
      tax,
      total,
      totalCost,
      createdAt: new Date(),
      paymentDetails,
      notes: [],
    };

    if (paymentDetails.method === 'storeCredit' && customer.id !== 'cust_walkin') {
      const updatedCustomer = {
        ...customer,
        storeCredit: (customer.storeCredit || 0) - total,
      };
      onUpdateCustomer(updatedCustomer);
      setCustomer(updatedCustomer);
    }
    
    if (paymentDetails.method === 'Cash') {
        setShowCashDrawer(true);
    }

    onCompleteSale(newTicket);
    setCompletedTicket(newTicket);

    setCart([]);
    setCustomer(WALK_IN_CUSTOMER);
    setDiscount(null);
    localStorage.removeItem('savedCart');
    localStorage.removeItem('savedCustomer');

    setIsCheckoutModalOpen(false);
    setIsReceiptModalOpen(true);
  };
  
  const handleApplyDiscount = (newDiscount: Discount) => {
    setDiscount(newDiscount);
    setIsDiscountModalOpen(false);
  };

  const handleSelectCustomer = (selectedCustomer: Customer) => {
    setCustomer(selectedCustomer);
    setIsCustomerSearchModalOpen(false);
  };

  const handleAddNewCustomer = (newCustomerData: Omit<Customer, 'id'>) => {
    const newCustomer = onAddNewCustomer(newCustomerData);
    setCustomer(newCustomer);
    setIsCustomerAddModalOpen(false);
  };

  const handleNewSale = () => {
    setIsReceiptModalOpen(false);
    setCompletedTicket(null);
  };
  
  const customerTickets = tickets.filter(t => t.customer.id === customer.id);
  const handleRemoveCartItem = (cartItemId: string) => {
    setCart(cart.filter(item => item.cartItemId !== cartItemId));
  };


  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-6.5rem)]">
        {/* Left Column */}
        <div className="lg:col-span-1 bg-dark-panel rounded-lg flex flex-col">
           <CustomerInfo 
            customer={customer} 
            onOpenCustomerSearch={() => setIsCustomerSearchModalOpen(true)}
            onOpenCustomerAdd={() => setIsCustomerAddModalOpen(true)} 
            onOpenCustomerDetail={() => setIsCustomerDetailModalOpen(true)}
            onOpenActions={() => setIsActionModalOpen(true)}
          />
          {/* Cart Table Header */}
          <div className="grid grid-cols-12 px-4 py-2 text-xs font-bold text-dark-text-secondary border-y border-dark-border flex-shrink-0">
              <div className="col-span-1">QTY</div>
              <div className="col-span-5">Item Name</div>
              <div className="col-span-2 text-right">Price</div>
              <div className="col-span-2 text-right">Tax</div>
              <div className="col-span-2 text-right">Total</div>
          </div>
          {/* Cart Items List */}
           <div className="flex-grow overflow-y-auto">
            {isCartEmpty ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-dark-text-tertiary">
                <ToolboxIcon className="w-16 h-16 text-dark-border" />
                <h2 className="mt-4 text-xl font-bold text-dark-text-secondary">Cart is Empty</h2>
                <p className="mt-1 text-sm">Select a service or product to begin.</p>
              </div>
            ) : (
                <div className="p-4 space-y-2">
                    {cart.map(item => (
                        <CartItemDisplay key={item.cartItemId} item={item} onRemove={handleRemoveCartItem} />
                    ))}
                </div>
            )}
          </div>

          {/* Totals */}
          <div className="p-4 mt-auto border-t border-dark-border flex-shrink-0">
             <div className="space-y-1 text-sm">
                <div className="flex justify-between items-center text-dark-text-secondary">
                    <span>Total Items</span>
                    <span>{cart.reduce((sum, item) => sum + item.quantity, 0)}</span>
                </div>
                <div className="flex justify-between items-center text-dark-text-secondary">
                    <button onClick={() => setIsDiscountModalOpen(true)} className="hover:text-brand-green">Discount</button>
                    <span>${discountAmount.toFixed(2)}</span>
                </div>
                 <div className="flex justify-between items-center text-dark-text-secondary">
                    <span>Sub Total</span>
                    <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-dark-text-secondary">
                    <span>Tax</span>
                    <span>${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-dark-text-primary text-lg font-bold pt-1 border-t border-dark-border">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                </div>
             </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="lg:col-span-2 bg-dark-panel rounded-lg flex flex-col">
          <BookingView 
            quickAddProducts={QUICK_ADD_PRODUCTS}
            onProductAdd={handleAddProductToCart}
            onInventoryItemAdd={handleAddInventoryItemToCart}
            inventoryItems={inventoryItems}
            onSaveTicket={handleSaveAsTicket}
            onCheckout={handleCheckout}
            onClearCart={() => setCart([])}
          />
        </div>
      </div>
      <CustomerSearchModal
        isOpen={isCustomerSearchModalOpen}
        onClose={() => setIsCustomerSearchModalOpen(false)}
        customers={customers}
        onSelectCustomer={handleSelectCustomer}
      />
      <CustomerAddModal
        isOpen={isCustomerAddModalOpen}
        onClose={() => setIsCustomerAddModalOpen(false)}
        onSave={handleAddNewCustomer}
      />
      <CustomerDetailModal
        isOpen={isCustomerDetailModalOpen}
        onClose={() => setIsCustomerDetailModalOpen(false)}
        customer={customer}
        tickets={customerTickets}
      />
      <CheckoutModal
        isOpen={isCheckoutModalOpen}
        onClose={() => setIsCheckoutModalOpen(false)}
        cart={cart}
        discount={discount}
        taxSettings={taxSettings}
        onProcessPayment={handleProcessPayment}
        paymentMethods={paymentMethodSettings}
        customer={customer}
        giftCards={giftCards}
      />
      <ReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={handleNewSale}
        ticket={completedTicket}
        onPrintTicket={onPrintTicket}
      />
      <DiscountModal
        isOpen={isDiscountModalOpen}
        onClose={() => setIsDiscountModalOpen(false)}
        onApplyDiscount={handleApplyDiscount}
        currentDiscount={discount}
      />
      <GiftCardModal
        isOpen={isGiftCardModalOpen}
        onClose={() => setIsGiftCardModalOpen(false)}
        onAddGiftCardToCart={handleAddGiftCardToCart}
      />
      <ActionModal 
        isOpen={isActionModalOpen}
        onClose={() => setIsActionModalOpen(false)}
      />
      <POSRepairModal
        isOpen={!!repairModalProduct}
        onClose={() => setRepairModalProduct(null)}
        product={repairModalProduct}
        inventoryItems={inventoryItems}
        onAddToCart={handleAddRepairItemToCart}
      />
      <CashDrawerOpen isOpen={showCashDrawer} onClose={() => setShowCashDrawer(false)} />
    </>
  );
};

export default POSView;