import { Product, Customer, TicketStatus, Ticket, CartItem, InventoryItem, NotificationPreferences, Manufacturer, RepairType, TaxSettings, PaymentMethodSettings, Supplier, PurchaseOrder, POStatus, Expense, ExpenseCategory, GiftCard, Appointment, AppointmentStatus, MessageTemplate, PCComponent, ProductCategory, User } from './types';
import PhoneIcon from './components/icons/PhoneIcon';
import TabletIcon from './components/icons/TabletIcon';
import LaptopIcon from './components/icons/LaptopIcon';
import GamingConsoleIcon from './components/icons/GamingConsoleIcon';
import SmartwatchIcon from './components/icons/SmartwatchIcon';
import PCIcon from './components/icons/PCIcon';
import DroneIcon from './components/icons/DroneIcon';
import CustomBuildIcon from './components/icons/CustomBuildIcon';
import ShieldCheckIcon from './components/icons/ShieldCheckIcon';
import BoltIcon from './components/icons/BoltIcon';
import LockOpenIcon from './components/icons/LockOpenIcon';
import CurrencyDollarIcon from './components/icons/CurrencyDollarIcon';
import GiftCardIcon from './components/icons/GiftCardIcon';

export const DUMMY_USERS: User[] = [
  { uid: 'user_admin_1', email: 'admin@reparahub.com', displayName: 'Admin Andy', role: 'Admin' } as User,
  { uid: 'user_manager_1', email: 'manager@reparahub.com', displayName: 'Manager Mary', role: 'Manager' } as User,
  { uid: 'user_tech_1', email: 'tech1@reparahub.com', displayName: 'Tech Tom', role: 'Technician' } as User,
  { uid: 'user_tech_2', email: 'tech2@reparahub.com', displayName: 'Tech Tina', role: 'Technician' } as User,
];

export const POS_CATEGORIES: { id: ProductCategory, label: string }[] = [
    { id: 'Repairs', label: 'Repairs' },
    { id: 'Unlocking', label: 'Unlocking' },
    { id: 'Products', label: 'Products' },
    { id: 'Miscellaneous', label: 'Miscellaneous' },
    { id: 'Bill Payment', label: 'Bill Payments' },
];

export const PRODUCTS: Product[] = [
    { id: 'prod_phone', name: 'Mobile Repair', category: 'Repairs', icon: PhoneIcon },
    { id: 'prod_tablet', name: 'Tablet Repair', category: 'Repairs', icon: TabletIcon },
    { id: 'prod_laptop', name: 'Computer/Laptop Repair', category: 'Repairs', icon: LaptopIcon },
    { id: 'prod_console', name: 'Gaming Console Repairs', category: 'Repairs', icon: GamingConsoleIcon },
    { id: 'prod_watch', name: 'Smart Watch Repairs', category: 'Repairs', icon: SmartwatchIcon },
    { id: 'prod_pc', name: 'Onsite/Remote Assistance', category: 'Repairs', icon: PCIcon },
    { id: 'prod_drone', name: 'Drone Repairs', category: 'Repairs', icon: DroneIcon },
    { id: 'prod_custom_build', name: 'Custom PC Build', category: 'Repairs', icon: CustomBuildIcon },
];

export const QUICK_ADD_PRODUCTS: Product[] = [
  { id: 'qa_screen_protector', name: 'Screen Protector', category: 'Products', price: 25.00, cost: 5.00, icon: ShieldCheckIcon },
  { id: 'qa_charging_cable', name: 'Charging Cable', category: 'Products', price: 19.99, cost: 4.50, icon: BoltIcon },
  { id: 'qa_unlocking', name: 'Unlocking Service', category: 'Unlocking', price: 50.00, cost: 10.00, icon: LockOpenIcon },
  { id: 'qa_bill_payment', name: 'Bill Payment', category: 'Bill Payment', price: 5.00, cost: 0.50, icon: CurrencyDollarIcon },
  { id: 'qa_misc_charge', name: 'Miscellaneous', category: 'Miscellaneous', price: 10.00, cost: 0.00, icon: PhoneIcon },
  { id: 'qa_gift_card', name: 'Gift Card', category: 'Miscellaneous', icon: GiftCardIcon },
];

export const COMMON_REPAIR_TYPES: RepairType[] = [
  { id: 'diag', name: 'Diagnostic Service', basePrice: 40.00, imageUrl: "https://www.fixez.com/cdn/shop/products/iphone-x-screen-replacement-1.jpg?v=1675806316" },
  { id: 'screen', name: 'Screen Replacement', basePrice: 129.00, imageUrl: "https://www.fixez.com/cdn/shop/products/iphone-x-screen-replacement-1.jpg?v=1675806316" },
  { id: 'back_glass', name: 'Back Glass Replacement', basePrice: 89.00, imageUrl: "https://m.media-amazon.com/images/I/61e0S2y-FIL._AC_SL1500_.jpg" },
  { id: 'battery', name: 'Battery Replacement', basePrice: 69.00, imageUrl: "https://images-na.ssl-images-amazon.com/images/I/71maAbaV2mL._AC_SL1500_.jpg" },
  { id: 'charging', name: 'Charging Port Repair', basePrice: 79.00, imageUrl: "https://www.fixez.com/cdn/shop/files/samsung-galaxy-s22-ultra-charging-port-flex-cable-replacement-1.jpg?v=1690462058" },
  { id: 'camera_rear', name: 'Back Camera Repair', basePrice: 89.00, imageUrl: "https://www.fixez.com/cdn/shop/products/iphone-14-pro-max-rear-camera-replacement-1.jpg?v=1675806440" },
  { id: 'camera_front', name: 'Front Camera Repair', basePrice: 59.00, imageUrl: "https://www.fixez.com/cdn/shop/products/iphone-13-front-facing-camera-and-sensor-assembly-replacement.jpg?v=1675806385" },
  { id: 'speaker_mic', name: 'Speaker/Microphone Repair', basePrice: 65.00, imageUrl: "https://www.fixez.com/cdn/shop/products/iphone-12-pro-earpiece-speaker-replacement-1_1.jpg?v=1675806362" },
  { id: 'water', name: 'Water Damage Treatment', basePrice: 99.00, imageUrl: "https://www.fixez.com/cdn/shop/products/iphone-14-loudspeaker-replacement-1.jpg?v=1675806411" },
  { id: 'motherboard', name: 'Motherboard Repair', basePrice: 199.00, imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Part" },
  { id: 'software', name: 'Software Issue Fix', basePrice: 50.00, imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Part" },
  { id: 'other', name: 'Other Issue', basePrice: 0.00, imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Part" },
];

export const PHONE_MANUFACTURERS: Manufacturer[] = [
  {
    id: 'apple_phone',
    name: 'Apple',
    models: [
      { id: 'iphone_15_pro_max', name: 'iPhone 15 Pro Max', imageUrl: "https://www.apple.com/v/iphone-15-pro/c/images/overview/design/design_display_pro__eqj2tf82cwim_large.jpg" },
      { id: 'iphone_15_pro', name: 'iPhone 15 Pro', imageUrl: "https://www.apple.com/v/iphone-15-pro/c/images/overview/design/design_display_pro__eqj2tf82cwim_large.jpg" },
      { id: 'iphone_15_plus', name: 'iPhone 15 Plus', imageUrl: "https://www.apple.com/v/iphone-15/a/images/overview/design/design_display__c85e683r0o2y_large.jpg" },
      { id: 'iphone_15', name: 'iPhone 15', imageUrl: "https://www.apple.com/v/iphone-15/a/images/overview/design/design_display__c85e683r0o2y_large.jpg" },
      { id: 'iphone_14_pro_max', name: 'iPhone 14 Pro Max', imageUrl: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-14-pro-colors.png" },
      { id: 'iphone_14_pro', name: 'iPhone 14 Pro', imageUrl: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-14-pro-colors.png" },
      { id: 'iphone_14_plus', name: 'iPhone 14 Plus', imageUrl: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-14-colors.png" },
      { id: 'iphone_14', name: 'iPhone 14', imageUrl: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-14-colors.png" },
      { id: 'iphone_13_pro_max', name: 'iPhone 13 Pro Max' },
      { id: 'iphone_13_pro', name: 'iPhone 13 Pro' },
      { id: 'iphone_13', name: 'iPhone 13', imageUrl: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/iphone13/iphone-13-colors.png" },
      { id: 'iphone_13_mini', name: 'iPhone 13 Mini' },
      { id: 'iphone_se_2022', name: 'iPhone SE (2022)' },
      { id: 'iphone_12_pro_max', name: 'iPhone 12 Pro Max' },
      { id: 'iphone_12_pro', name: 'iPhone 12 Pro' },
      { id: 'iphone_12', name: 'iPhone 12' },
      { id: 'iphone_12_mini', name: 'iPhone 12 Mini' },
      { id: 'iphone_11_series', name: 'iPhone 11 Series' },
      { id: 'iphone_x_series', name: 'iPhone X/XS/XR Series' },
    ],
  },
  {
    id: 'samsung_phone',
    name: 'Samsung',
    models: [
      { id: 'galaxy_s24_ultra', name: 'Galaxy S24 Ultra', imageUrl: "https://image-us.samsung.com/us/smartphones/galaxy-s24-ultra/images/galaxy-s24-ultra-highlights-kv.jpg" },
      { id: 'galaxy_s24_plus', name: 'Galaxy S24+' },
      { id: 'galaxy_s24', name: 'Galaxy S24', imageUrl: "https://image-us.samsung.com/us/smartphones/galaxy-s24/images/galaxy-s24-highlights-kv.jpg" },
      { id: 'galaxy_s23_fe', name: 'Galaxy S23 FE' },
      { id: 'galaxy_s23_ultra', name: 'Galaxy S23 Ultra' },
      { id: 'galaxy_z_fold_5', name: 'Galaxy Z Fold 5', imageUrl: "https://image-us.samsung.com/us/smartphones/galaxy-z-fold5/images/galaxy-z-fold5-highlights-design-display-s.jpg" },
      { id: 'galaxy_z_flip_5', name: 'Galaxy Z Flip 5' },
      { id: 'galaxy_a54', name: 'Galaxy A54 5G' },
      { id: 'galaxy_a34', name: 'Galaxy A34 5G' },
      { id: 'galaxy_a14', name: 'Galaxy A14' },
      { id: 'older_s_series', name: 'Older Galaxy S Series' },
      { id: 'older_note_series', name: 'Older Galaxy Note Series' },
      { id: 'older_a_series', name: 'Older Galaxy A Series' },
    ],
  },
  {
    id: 'google_phone',
    name: 'Google',
    models: [
      { id: 'pixel_8_pro', name: 'Pixel 8 Pro', imageUrl: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/HlGquD5.max-1000x1000.jpg" },
      { id: 'pixel_8', name: 'Pixel 8', imageUrl: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/KWPrg52.max-1000x1000.jpg" },
      { id: 'pixel_fold', name: 'Pixel Fold', imageUrl: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/google_pixel_fold_obsidian_case.max-1000x1000.png" },
      { id: 'pixel_7a', name: 'Pixel 7a' },
      { id: 'pixel_7_pro', name: 'Pixel 7 Pro' },
      { id: 'pixel_7', name: 'Pixel 7' },
      { id: 'pixel_6a', name: 'Pixel 6a' },
      { id: 'pixel_6_pro', name: 'Pixel 6 Pro' },
      { id: 'pixel_6', name: 'Pixel 6' },
    ],
  },
  {
    id: 'oneplus',
    name: 'OnePlus',
    models: [
      { id: 'oneplus_12', name: 'OnePlus 12' },
      { id: 'oneplus_open', name: 'OnePlus Open' },
      { id: 'oneplus_11', name: 'OnePlus 11' },
      { id: 'oneplus_nord_n30', name: 'OnePlus Nord N30' },
      { id: 'oneplus_10_pro', name: 'OnePlus 10 Pro' },
    ],
  },
  {
    id: 'motorola',
    name: 'Motorola',
    models: [
      { id: 'moto_razr_plus', name: 'Moto Razr+' },
      { id: 'moto_edge_plus', name: 'Moto Edge+' },
      { id: 'moto_g_stylus', name: 'Moto G Stylus' },
      { id: 'moto_g_power', name: 'Moto G Power' },
    ],
  },
  {
    id: 'xiaomi',
    name: 'Xiaomi',
    models: [
        { id: 'xiaomi_14', name: 'Xiaomi 14 Series' },
        { id: 'xiaomi_13t', name: 'Xiaomi 13T Series' },
        { id: 'redmi_note_13', name: 'Redmi Note 13 Series' },
        { id: 'poco_f5', name: 'Poco F5 Series' },
    ]
  },
  {
    id: 'other_phone',
    name: 'Other',
    models: [{ id: 'other_custom_phone', name: 'Custom/Other', imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Device" }],
  },
];

export const TABLET_MANUFACTURERS: Manufacturer[] = [
  {
    id: 'apple_tablet',
    name: 'Apple',
    models: [
      { id: 'ipad_pro_12_9_6th_gen', name: 'iPad Pro 12.9" (6th Gen)', imageUrl: "https://www.apple.com/v/ipad-pro/am/images/overview/design/design_display_12_9__fx2g3eeuh02a_large.jpg" },
      { id: 'ipad_pro_11_4th_gen', name: 'iPad Pro 11" (4th Gen)' },
      { id: 'ipad_air_5th_gen', name: 'iPad Air (5th Gen)', imageUrl: "https://www.apple.com/v/ipad-air/r/images/overview/design/design_hero_1__d3m92f1we56q_large.jpg" },
      { id: 'ipad_10th_gen', name: 'iPad (10th Gen)' },
      { id: 'ipad_9th_gen', name: 'iPad (9th Gen)' },
      { id: 'ipad_mini_6th_gen', name: 'iPad Mini (6th Gen)' },
    ],
  },
  {
    id: 'samsung_tablet',
    name: 'Samsung',
    models: [
      { id: 'galaxy_tab_s9_ultra', name: 'Galaxy Tab S9 Ultra' },
      { id: 'galaxy_tab_s9_plus', name: 'Galaxy Tab S9+' },
      { id: 'galaxy_tab_s9', name: 'Galaxy Tab S9', imageUrl: "https://image-us.samsung.com/us/tablets/galaxy-tab-s9-ultra/images/galaxy-tab-s9-ultra-highlights-kv.jpg" },
      { id: 'galaxy_tab_s9_fe', name: 'Galaxy Tab S9 FE', imageUrl: "https://image-us.samsung.com/us/tablets/galaxy-tab-s9-fe/gallery/gray/01_gallery.jpg" },
      { id: 'galaxy_tab_a9_plus', name: 'Galaxy Tab A9+' },
      { id: 'older_tab_s', name: 'Older Galaxy Tab S Series' },
      { id: 'older_tab_a', name: 'Older Galaxy Tab A Series' },
    ],
  },
  {
    id: 'microsoft_tablet',
    name: 'Microsoft',
    models: [
      { id: 'surface_pro_9', name: 'Surface Pro 9' },
      { id: 'surface_go_4', name: 'Surface Go 4' },
      { id: 'surface_laptop_studio', name: 'Surface Laptop Studio' },
    ]
  },
  {
    id: 'amazon_tablet',
    name: 'Amazon',
    models: [
      { id: 'fire_max_11', name: 'Fire Max 11' },
      { id: 'fire_hd_10', name: 'Fire HD 10' },
      { id: 'fire_hd_8', name: 'Fire HD 8' },
    ]
  },
  {
    id: 'google_tablet',
    name: 'Google',
    models: [
        { id: 'pixel_tablet', name: 'Pixel Tablet', imageUrl: "https://lh3.googleusercontent.com/PgwI6DrklY82j2yzJCV22i2qNQgq6iQ5812n4x9KjZ2v_RBda1u51n2f51-j24Vq5J0V=w2400-h1200-rw" },
    ],
  },
  {
    id: 'other_tablet',
    name: 'Other',
    models: [{ id: 'other_custom_tablet', name: 'Custom/Other', imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Device" }],
  },
];

export const WATCH_MANUFACTURERS: Manufacturer[] = [
  {
    id: 'apple_watch',
    name: 'Apple',
    models: [
      { id: 'apple_watch_ultra_2', name: 'Apple Watch Ultra 2', imageUrl: "https://www.apple.com/v/apple-watch-ultra-2/c/images/overview/design/design_hero__ebkb7na89fie_large.jpg" },
      { id: 'apple_watch_9', name: 'Apple Watch Series 9', imageUrl: "https://www.apple.com/v/apple-watch-series-9/e/images/overview/design/design_hero__c58lti2llw2y_large.jpg" },
      { id: 'apple_watch_se_2', name: 'Apple Watch SE (2nd Gen)' },
      { id: 'apple_watch_8', name: 'Apple Watch Series 8' },
      { id: 'apple_watch_ultra_1', name: 'Apple Watch Ultra' },
    ],
  },
  {
    id: 'samsung_watch',
    name: 'Samsung',
    models: [
      { id: 'galaxy_watch_6', name: 'Galaxy Watch 6', imageUrl: "https://image-us.samsung.com/us/watches/galaxy-watch6/images/galaxy-watch6-highlights-kv-s.jpg" },
      { id: 'galaxy_watch_6_classic', name: 'Galaxy Watch 6 Classic' },
      { id: 'galaxy_watch_5_pro', name: 'Galaxy Watch 5 Pro' },
      { id: 'galaxy_watch_5', name: 'Galaxy Watch 5' },
    ],
  },
  {
    id: 'google_watch',
    name: 'Google',
    models: [
      { id: 'pixel_watch_2', name: 'Pixel Watch 2', imageUrl: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/pw2_lifestyle_hero_2.width-1000.height-1000.format-webp.webp" },
      { id: 'pixel_watch_1', name: 'Pixel Watch' },
    ],
  },
  {
      id: 'fitbit',
      name: 'Fitbit',
      models: [
          { id: 'fitbit_sense_2', name: 'Fitbit Sense 2' },
          { id: 'fitbit_versa_4', name: 'Fitbit Versa 4' },
          { id: 'fitbit_charge_6', name: 'Fitbit Charge 6' },
      ]
  },
  {
      id: 'garmin',
      name: 'Garmin',
      models: [
          { id: 'garmin_fenix_7', name: 'Garmin Fenix 7' },
          { id: 'garmin_venu_3', name: 'Garmin Venu 3' },
          { id: 'garmin_forerunner_965', name: 'Garmin Forerunner 965' },
      ]
  },
  {
    id: 'other_watch',
    name: 'Other',
    models: [{ id: 'other_custom_watch', name: 'Custom/Other', imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Device" }],
  },
];

export const LAPTOP_PC_MANUFACTURERS: Manufacturer[] = [
  {
    id: 'apple_computer',
    name: 'Apple',
    models: [
        { id: 'macbook_air_m2', name: 'MacBook Air M2 (2022)', imageUrl: "https://www.apple.com/v/macbook-air-13-and-15-m2/b/images/overview/design/design_hero_13__d6b8kmmna9hy_large.jpg" },
        { id: 'macbook_pro_16_m3', name: 'MacBook Pro 16" (M3)', imageUrl: "https://www.apple.com/v/macbook-pro-14-and-16/c/images/overview/hero/hero_mbp_14_16__b7y9eoreayuy_large.jpg" },
        { id: 'imac_24_m3', name: 'iMac 24" (M3)', imageUrl: "https://www.apple.com/v/imac-24/h/images/overview/color_front_green__eb8qbnw82m2i_large.jpg" },
        { id: 'mac_mini', name: 'Mac Mini' },
        { id: 'mac_studio', name: 'Mac Studio' },
        { id: 'mac_pro', name: 'Mac Pro' },
    ],
  },
  {
    id: 'dell',
    name: 'Dell',
    models: [
        { id: 'xps_15', name: 'XPS 15', imageUrl: "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-15-9530/media-gallery/touch-platinum-silver/notebook-xps-15-9530-t-platinum-silver-gallery-1.psd?fmt=png-alpha" },
        { id: 'xps_17', name: 'XPS 17' },
        { id: 'inspiron_15', name: 'Inspiron 15' },
        { id: 'latitude_7440', name: 'Latitude 7440' },
        { id: 'alienware_m16', name: 'Alienware m16', imageUrl: "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/alienware-notebooks/alienware-m18-r1/media-gallery/dark-metallic-moon/notebook-alienware-m18-r1-dark-side-of-the-moon-gallery-1.psd?fmt=png-alpha" },
        { id: 'alienware_aurora_r15', name: 'Alienware Aurora R15 Desktop' },
    ],
  },
  {
    id: 'hp',
    name: 'HP',
    models: [
        { id: 'spectre_x360', name: 'Spectre x360', imageUrl: "https://m.media-amazon.com/images/I/718Dk3K23LL._AC_SL1500_.jpg" },
        { id: 'envy_16', name: 'Envy 16' },
        { id: 'pavilion_aero', name: 'Pavilion Aero' },
        { id: 'elitebook_840', name: 'EliteBook 840' },
        { id: 'omen_17', name: 'Omen 17', imageUrl: "https://m.media-amazon.com/images/I/71PlJ-ejg8L._AC_SL1500_.jpg" },
        { id: 'omen_45l_desktop', name: 'Omen 45L Desktop' },
    ],
  },
  {
    id: 'lenovo',
    name: 'Lenovo',
    models: [
        { id: 'thinkpad_x1', name: 'ThinkPad X1 Carbon', imageUrl: "https://p4-ofp.static.pub/fes/cms/2023/01/03/h7b8y616j1k51t6p4h0fmn22vj2d17475850.png" },
        { id: 'yoga_9i', name: 'Yoga 9i' },
        { id: 'ideapad_slim_5', name: 'IdeaPad Slim 5' },
        { id: 'legion_pro_7i', name: 'Legion Pro 7i', imageUrl: "https://p1-ofp.static.pub/fes/cms/2022/12/12/j55mmv00n2h0y5l372tqx9wlxz2y23877969.png" },
        { id: 'legion_tower_7i', name: 'Legion Tower 7i' },
    ],
  },
  {
    id: 'asus',
    name: 'Asus',
    models: [
        { id: 'rog_zephyrus_g14', name: 'ROG Zephyrus G14' },
        { id: 'zenbook_14_oled', name: 'Zenbook 14 OLED' },
        { id: 'vivobook_pro_16', name: 'Vivobook Pro 16' },
        { id: 'rog_strix_g18', name: 'ROG Strix G18' },
    ],
  },
  {
    id: 'acer',
    name: 'Acer',
    models: [
        { id: 'swift_go_14', name: 'Swift Go 14' },
        { id: 'aspire_5', name: 'Aspire 5' },
        { id: 'predator_helios_16', name: 'Predator Helios 16' },
        { id: 'nitro_5', name: 'Nitro 5' },
    ],
  },
  {
      id: 'razer',
      name: 'Razer',
      models: [
          { id: 'blade_15', name: 'Razer Blade 15' },
          { id: 'blade_16', name: 'Razer Blade 16' },
          { id: 'blade_18', name: 'Razer Blade 18' },
      ]
  },
];

export const GAMING_CONSOLE_MANUFACTURERS: Manufacturer[] = [
    { id: 'sony', name: 'Sony', models: [
        {id: 'ps5', name: 'PlayStation 5', imageUrl: "https://m.media-amazon.com/images/I/61t4GqA5DML._SL1500_.jpg"}, 
        {id: 'ps5_slim', name: 'PlayStation 5 Slim'},
        {id: 'ps_portal', name: 'PlayStation Portal'},
        {id: 'ps4_pro', name: 'PlayStation 4 Pro', imageUrl: "https://m.media-amazon.com/images/I/41GGPRqTZtL._SL1000_.jpg"},
        {id: 'ps4_slim', name: 'PlayStation 4 Slim'},
        {id: 'ps_vita', name: 'PS Vita'},
    ] },
    { id: 'microsoft', name: 'Microsoft', models: [
        {id: 'xbox_series_x', name: 'Xbox Series X', imageUrl: "https://m.media-amazon.com/images/I/61JGKhx+6eL._SL1500_.jpg"}, 
        {id: 'xbox_series_s', name: 'Xbox Series S', imageUrl: "https://m.media-amazon.com/images/I/71NBQ2a52CL._SL1500_.jpg"},
        {id: 'xbox_one_x', name: 'Xbox One X'},
        {id: 'xbox_one_s', name: 'Xbox One S'},
    ] },
    { id: 'nintendo', name: 'Nintendo', models: [
        {id: 'switch_oled', name: 'Switch OLED', imageUrl: "https://m.media-amazon.com/images/I/71m5Bzkx48L._SL1500_.jpg"}, 
        {id: 'switch', name: 'Switch (Standard)'},
        {id: 'switch_lite', name: 'Switch Lite', imageUrl: "https://m.media-amazon.com/images/I/71qmF0FHj9L._SL1500_.jpg"},
        {id: 'new_3ds_xl', name: 'New 3DS XL'},
    ] },
    { id: 'valve', name: 'Valve', models: [
        {id: 'steam_deck_oled', name: 'Steam Deck OLED'},
        {id: 'steam_deck_lcd', name: 'Steam Deck LCD'},
    ]},
    { id: 'other_console', name: 'Other', models: [{ id: 'other_custom_console', name: 'Custom/Other', imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Device" }] },
];

export const DRONE_MANUFACTURERS: Manufacturer[] = [
    { id: 'dji', name: 'DJI', models: [
        {id: 'mavic_3_pro', name: 'Mavic 3 Pro', imageUrl: "https://m.media-amazon.com/images/I/71Q0y+8vSQL._AC_SL1500_.jpg"}, 
        {id: 'mini_4_pro', name: 'Mini 4 Pro', imageUrl: "https://m.media-amazon.com/images/I/71Xm1QfNE8L._AC_SL1500_.jpg"},
        {id: 'air_3', name: 'Air 3'},
        {id: 'avata_2', name: 'Avata 2'},
        {id: 'inspire_3', name: 'Inspire 3'},
    ] },
    { id: 'autel', name: 'Autel Robotics', models: [
        {id: 'evo_ii_pro', name: 'EVO II Pro'},
        {id: 'evo_max_4t', name: 'EVO Max 4T'},
    ] },
    { id: 'parrot', name: 'Parrot', models: [
        {id: 'anafi_ai', name: 'Anafi Ai'},
    ] },
    { id: 'other_drone', name: 'Other', models: [{ id: 'other_custom_drone', name: 'Custom/Other', imageUrl: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Device" }] },
];

export const MANUFACTURERS_BY_CATEGORY: Record<string, Manufacturer[]> = {
    'prod_phone': PHONE_MANUFACTURERS,
    'prod_tablet': TABLET_MANUFACTURERS,
    'prod_watch': WATCH_MANUFACTURERS,
    'prod_laptop': LAPTOP_PC_MANUFACTURERS,
    'prod_pc': LAPTOP_PC_MANUFACTURERS,
    'prod_console': GAMING_CONSOLE_MANUFACTURERS,
    'prod_drone': DRONE_MANUFACTURERS,
};

export const WALK_IN_CUSTOMER: Customer = {
    id: 'cust_walkin',
    name: 'Walkin Customer',
};

export const defaultNotificationPreferences: NotificationPreferences = {
    [TicketStatus.NEW]: { email: true, sms: true },
    [TicketStatus.IN_PROGRESS]: { email: true, sms: false },
    [TicketStatus.WAITING_for_PARTS]: { email: true, sms: true },
    [TicketStatus.COMPLETED]: { email: true, sms: true },
    [TicketStatus.CANCELLED]: { email: false, sms: false },
    [TicketStatus.SAVED]: { email: false, sms: false },
    [TicketStatus.WAITING_FOR_ARRIVAL]: { email: true, sms: false },
    [TicketStatus.QUOTE_PENDING]: { email: true, sms: true },
};

export const DUMMY_CUSTOMERS: Customer[] = [
  { id: 'cust_1', name: 'Alice Johnson', phone: '555-0101', email: 'alice@email.com', notificationPreferences: defaultNotificationPreferences, storeCredit: 50.00 },
  { id: 'cust_2', name: 'Bob Williams', phone: '555-0102', email: 'bob@email.com', notificationPreferences: defaultNotificationPreferences, storeCredit: 0 },
  { id: 'cust_3', name: 'Charlie Brown', phone: '555-0103', email: 'charlie@email.com', notificationPreferences: defaultNotificationPreferences, storeCredit: 25.50 },
  { id: 'cust_4', name: 'Diana Miller', phone: '555-0104', email: 'diana@email.com', notificationPreferences: defaultNotificationPreferences, storeCredit: 100.00 },
  { id: 'cust_5', name: 'Ethan Davis', phone: '555-0105', email: 'ethan@email.com', notificationPreferences: defaultNotificationPreferences },
  { id: 'cust_6', name: 'Fiona Garcia', phone: '555-0106', email: 'fiona@email.com', notificationPreferences: defaultNotificationPreferences, storeCredit: 15.75 },
];

const dummyCartItem1: CartItem = {
  cartItemId: 'ci_1',
  id: 'prod_phone',
  name: 'Apple iPhone 13 Pro Screen Repair',
  category: 'Repairs',
  icon: PhoneIcon,
  quantity: 1,
  unitPrice: 249.99,
  tax: 25.00,
  cost: 120.00,
  deviceMake: 'Apple',
  deviceModel: 'iPhone 13 Pro',
  imei: '353234567890123',
  issue: 'Cracked screen, display is flickering.',
};

const dummyCartItem2: CartItem = {
  cartItemId: 'ci_2',
  id: 'prod_laptop',
  name: 'Dell XPS 15 Battery Replacement',
  category: 'Repairs',
  icon: LaptopIcon,
  quantity: 1,
  unitPrice: 120.00,
  tax: 11.00,
  cost: 45.00,
  deviceMake: 'Dell',
  deviceModel: 'XPS 15 9570',
  issue: 'Battery drains very quickly and laptop shuts down unexpectedly.',
};

const dummyCartItem3: CartItem = {
  cartItemId: 'ci_3',
  id: 'prod_console',
  name: 'Playstation 5 HDMI Port Repair',
  category: 'Repairs',
  icon: GamingConsoleIcon,
  quantity: 1,
  unitPrice: 0, // Awaiting quote
  tax: 0,
  cost: 0,
  deviceMake: 'Sony',
  deviceModel: 'Playstation 5',
  issue: 'No video output from HDMI port, console powers on.',
};

export const DUMMY_TICKETS: Ticket[] = [
  {
    id: 'tkt_1',
    customer: DUMMY_CUSTOMERS[0], // Alice Johnson
    items: [dummyCartItem1],
    status: TicketStatus.COMPLETED,
    subtotal: 249.99,
    discount: 0,
    tax: 25.00,
    total: 274.99,
    totalCost: 120.00,
    createdAt: new Date('2023-10-26'),
    assignedTechnicianId: 'user_tech_1',
    notes: [
        { id: 'note_1', content: 'Customer called to confirm pickup time.', createdAt: new Date('2023-10-26 14:30:00') }
    ],
  },
  {
    id: 'tkt_2',
    customer: DUMMY_CUSTOMERS[1], // Bob Williams
    items: [dummyCartItem2],
    status: TicketStatus.IN_PROGRESS,
    subtotal: 120.00,
    discount: 10.00,
    tax: 11.00,
    total: 121.00,
    totalCost: 45.00,
    createdAt: new Date('2023-10-28'),
    assignedTechnicianId: 'user_tech_2',
    notes: [],
  },
   {
    id: 'tkt_3',
    customer: DUMMY_CUSTOMERS[2], // Charlie Brown
    items: [dummyCartItem3],
    status: TicketStatus.NEW,
    subtotal: 0,
    discount: 0,
    tax: 0,
    total: 0,
    totalCost: 0,
    createdAt: new Date(),
    assignedTechnicianId: 'user_tech_1',
    notes: [],
  },
];


// Fix: Add STATUS_COLORS for use in StatusBadge component
export const STATUS_COLORS: Record<TicketStatus, string> = {
  [TicketStatus.NEW]: 'bg-blue-100 text-blue-800',
  [TicketStatus.IN_PROGRESS]: 'bg-yellow-100 text-yellow-800',
  [TicketStatus.WAITING_for_PARTS]: 'bg-orange-100 text-orange-800',
  [TicketStatus.COMPLETED]: 'bg-green-100 text-green-800',
  [TicketStatus.CANCELLED]: 'bg-red-100 text-red-800',
  [TicketStatus.SAVED]: 'bg-gray-100 text-gray-800',
  [TicketStatus.WAITING_FOR_ARRIVAL]: 'bg-purple-100 text-purple-800',
  [TicketStatus.QUOTE_PENDING]: 'bg-cyan-100 text-cyan-800',
};

export const PO_STATUS_COLORS: Record<POStatus, string> = {
  [POStatus.DRAFT]: 'bg-gray-100 text-gray-800',
  [POStatus.ORDERED]: 'bg-blue-100 text-blue-800',
  [POStatus.PARTIALLY_RECEIVED]: 'bg-yellow-100 text-yellow-800',
  [POStatus.RECEIVED]: 'bg-green-100 text-green-800',
  [POStatus.CANCELLED]: 'bg-red-100 text-red-800',
};

export const APPOINTMENT_STATUS_COLORS: Record<AppointmentStatus, { bg: string, text: string }> = {
  [AppointmentStatus.SCHEDULED]: { bg: 'bg-blue-100', text: 'text-blue-800' },
  [AppointmentStatus.COMPLETED]: { bg: 'bg-green-100', text: 'text-green-800' },
  [AppointmentStatus.CANCELLED]: { bg: 'bg-red-100', text: 'text-red-800' },
  [AppointmentStatus.NO_SHOW]: { bg: 'bg-gray-100', text: 'text-gray-800' },
};


export const STATUS_OPTIONS = Object.values(TicketStatus);

export const EXPENSE_CATEGORIES = Object.values(ExpenseCategory);

const CRAZY_PARTS_INVENTORY: InventoryItem[] = [
  // iPhone Parts
  { id: 'inv_101', name: 'iPhone 15 Pro Max Screen (Premium)', sku: 'IP15PM-SCR-PREM', quantity: 15, cost: 210.00, price: 349.95, category: 'iPhone Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-11-10') },
  { id: 'inv_102', name: 'iPhone 15 Pro Battery', sku: 'IP15P-BAT', quantity: 25, cost: 45.00, price: 89.95, category: 'iPhone Parts', reorderPoint: 10, lastReceivedDate: new Date('2023-11-10') },
  { id: 'inv_103', name: 'iPhone 14 Pro Max Screen (Premium)', sku: 'IP14PM-SCR-PREM', quantity: 12, cost: 180.00, price: 299.95, category: 'iPhone Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-10-15') },
  { id: 'inv_104', name: 'iPhone 14 Battery', sku: 'IP14-BAT', quantity: 30, cost: 40.00, price: 79.95, category: 'iPhone Parts', reorderPoint: 10, lastReceivedDate: new Date('2023-10-15') },
  { id: 'inv_105', name: 'iPhone 13 Screen (Aftermarket)', sku: 'IP13-SCR-AFT', quantity: 18, cost: 65.00, price: 129.95, category: 'iPhone Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-09-20') },
  { id: 'inv_106', name: 'iPhone 13 Charging Port Flex', sku: 'IP13-CHG', quantity: 22, cost: 25.00, price: 59.95, category: 'iPhone Parts', reorderPoint: 10, lastReceivedDate: new Date('2023-09-20') },
  { id: 'inv_107', name: 'iPhone 12 Back Glass Housing (Blue)', sku: 'IP12-BG-BLU', quantity: 8, cost: 50.00, price: 99.95, category: 'iPhone Parts', reorderPoint: 3, lastReceivedDate: new Date('2023-08-15') },
  { id: 'inv_108', name: 'iPhone SE (2022) Battery', sku: 'IPSE3-BAT', quantity: 15, cost: 30.00, price: 69.95, category: 'iPhone Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-10-05') },

  // Samsung Parts
  { id: 'inv_201', name: 'Samsung S24 Ultra Screen + Frame', sku: 'S24U-SCR', quantity: 10, cost: 320.00, price: 499.95, category: 'Samsung Parts', reorderPoint: 3, lastReceivedDate: new Date('2023-11-12') },
  { id: 'inv_202', name: 'Samsung S23 Ultra Battery', sku: 'S23U-BAT', quantity: 18, cost: 50.00, price: 99.95, category: 'Samsung Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-09-01') },
  { id: 'inv_203', name: 'Samsung S22 Charging Port', sku: 'S22-CHG', quantity: 20, cost: 30.00, price: 69.95, category: 'Samsung Parts', reorderPoint: 8, lastReceivedDate: new Date('2023-08-25') },
  { id: 'inv_204', name: 'Samsung A54 Screen', sku: 'A54-SCR', quantity: 15, cost: 80.00, price: 149.95, category: 'Samsung Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-10-10') },
  { id: 'inv_205', name: 'Samsung Z Fold 5 Inner Display', sku: 'ZF5-SCR-IN', quantity: 3, cost: 600.00, price: 899.95, category: 'Samsung Parts', reorderPoint: 1, lastReceivedDate: new Date('2023-11-01') },

  // Google Pixel Parts
  { id: 'inv_301', name: 'Google Pixel 8 Pro Screen', sku: 'P8P-SCR', quantity: 8, cost: 190.00, price: 319.95, category: 'Google Pixel Parts', reorderPoint: 3, lastReceivedDate: new Date('2023-10-20') },
  { id: 'inv_302', name: 'Google Pixel 7a Battery', sku: 'P7A-BAT', quantity: 12, cost: 40.00, price: 79.95, category: 'Google Pixel Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-09-15') },
  { id: 'inv_303', name: 'Google Pixel 6 Pro Charging Port', sku: 'P6P-CHG', quantity: 15, cost: 35.00, price: 69.95, category: 'Google Pixel Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-08-10') },

  // General Parts & Tools
  { id: 'inv_401', name: 'Tesa Adhesive Tape (2mm)', sku: 'GEN-TAPE-2MM', quantity: 50, cost: 8.00, price: 19.95, category: 'General Parts', reorderPoint: 20, lastReceivedDate: new Date('2023-11-05') },
  { id: 'inv_402', name: 'iFixit Pro Tech Toolkit', sku: 'GEN-TOOL-IFIXIT', quantity: 10, cost: 85.00, price: 129.95, category: 'General Parts', reorderPoint: 3, lastReceivedDate: new Date('2023-07-01') },
  { id: 'inv_403', name: 'Isopropyl Alcohol 99% (500ml)', sku: 'GEN-CHEM-ISO-500', quantity: 30, cost: 10.00, price: 24.95, category: 'General Parts', reorderPoint: 10, lastReceivedDate: new Date('2023-11-05') },

  // Accessories
  { id: 'inv_501', name: 'USB-C to Lightning Cable (1m)', sku: 'ACC-CBL-LGT-1M', quantity: 40, cost: 8.00, price: 29.95, category: 'Accessories', reorderPoint: 15, lastReceivedDate: new Date('2023-11-08') },
  { id: 'inv_502', name: '30W USB-C Power Adapter', sku: 'ACC-ADP-30W', quantity: 35, cost: 15.00, price: 49.95, category: 'Accessories', reorderPoint: 10, lastReceivedDate: new Date('2023-11-08') },
  { id: 'inv_503', name: 'Tempered Glass (iPhone 15 Pro)', sku: 'ACC-SP-IP15P', quantity: 50, cost: 5.00, price: 24.95, category: 'Accessories', reorderPoint: 20, lastReceivedDate: new Date('2023-10-30') },
  { id: 'inv_504', name: 'Clear Case (Galaxy S24 Ultra)', sku: 'ACC-CSE-S24U-CL', quantity: 25, cost: 10.00, price: 34.95, category: 'Accessories', reorderPoint: 10, lastReceivedDate: new Date('2023-11-01') },
  { id: 'inv_505', name: 'MagSafe Wireless Charger', sku: 'ACC-WCHG-MAG', quantity: 20, cost: 25.00, price: 69.95, category: 'Accessories', reorderPoint: 8, lastReceivedDate: new Date('2023-10-25') },
  { id: 'inv_506', name: 'Anker Power Bank 20000mAh', sku: 'ACC-PB-ANK-20K', quantity: 15, cost: 55.00, price: 99.95, category: 'Accessories', reorderPoint: 5, lastReceivedDate: new Date('2023-10-25') },
  { id: 'inv_507', name: 'Car Vent Phone Mount', sku: 'ACC-MOUNT-CAR', quantity: 30, cost: 9.00, price: 29.95, category: 'Accessories', reorderPoint: 10, lastReceivedDate: new Date('2023-10-18') },
];


export const DUMMY_INVENTORY_ITEMS: InventoryItem[] = [
  { id: 'inv_1', name: 'iPhone 14 Pro Screen', sku: 'IP14P-SCR', quantity: 12, cost: 150.00, price: 289.99, category: 'iPhone Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-10-15') },
  { id: 'inv_2', name: 'iPhone 14 Pro Battery', sku: 'IP14P-BAT', quantity: 8, cost: 45.00, price: 89.99, category: 'iPhone Parts', reorderPoint: 3, lastReceivedDate: new Date('2023-10-15') },
  { id: 'inv_3', name: 'Galaxy S23 Ultra Screen', sku: 'S23U-SCR-SUB', quantity: 7, cost: 180.00, price: 349.99, category: 'Samsung Parts', reorderPoint: 5, lastReceivedDate: new Date('2023-08-22') },
  { id: 'inv_5', name: 'Pixel 7 Pro Screen', sku: 'P7P-SCR', quantity: 5, cost: 130.00, price: 249.99, category: 'Google Pixel Parts', reorderPoint: 2, lastReceivedDate: new Date('2023-07-10') },
  { id: 'inv_6', name: 'Generic USB-C Port', sku: 'GEN-USBC', quantity: 25, cost: 15.00, price: 49.99, category: 'General Parts', reorderPoint: 10, lastReceivedDate: new Date('2023-10-01') },
  { id: 'inv_7', name: 'MacBook Air M2 Battery', sku: 'MBA-M2-BAT', quantity: 3, cost: 85.00, price: 179.99, category: 'Laptop Parts', reorderPoint: 2, lastReceivedDate: new Date('2023-06-05') },
  ...CRAZY_PARTS_INVENTORY,
];

export const DUMMY_TAX_SETTINGS: TaxSettings = {
    baseRate: 8.25,
    rules: [
        { id: 'tax_rule_1', name: 'Labor Tax', rate: 1.5, isEnabled: true },
        { id: 'tax_rule_2', name: 'Eco Fee', rate: 0.5, isEnabled: false },
    ]
};

export const DUMMY_PAYMENT_METHOD_SETTINGS: PaymentMethodSettings = {
    cash: true,
    card: true,
    afterpay: false,
    square: true,
    storeCredit: true,
};

export const DUMMY_SUPPLIERS: Supplier[] = [
    { id: 'sup_1', name: 'Global Phone Parts', contactPerson: 'John Smith', phone: '555-1234', email: 'sales@globalparts.com' },
    { id: 'sup_2', name: 'Device Savers Inc.', contactPerson: 'Maria Garcia', phone: '555-5678', email: 'maria.g@devicesavers.com' },
];

export const DUMMY_PURCHASE_ORDERS: PurchaseOrder[] = [
    { 
        id: 'po_1', 
        supplier: DUMMY_SUPPLIERS[0], 
        items: [
            { itemId: 'inv_1', name: 'iPhone 14 Pro Screen', sku: 'IP14P-SCR', quantityOrdered: 10, quantityReceived: 10, cost: 145.00 },
            { itemId: 'inv_2', name: 'iPhone 14 Pro Battery', sku: 'IP14P-BAT', quantityOrdered: 5, quantityReceived: 5, cost: 42.00 },
        ],
        status: POStatus.RECEIVED,
        createdAt: new Date('2023-10-15'),
        totalCost: 1660.00,
    },
    { 
        id: 'po_2', 
        supplier: DUMMY_SUPPLIERS[1], 
        items: [
            { itemId: 'inv_3', name: 'Galaxy S23 Ultra Screen', sku: 'S23U-SCR', quantityOrdered: 5, quantityReceived: 2, cost: 175.00 },
        ],
        status: POStatus.PARTIALLY_RECEIVED,
        createdAt: new Date('2023-10-22'),
        totalCost: 875.00,
    }
];

export const DUMMY_EXPENSES: Expense[] = [
    { id: 'exp_1', date: new Date('2023-10-25'), category: ExpenseCategory.RENT, description: 'October Rent', amount: 2500.00 },
    { id: 'exp_2', date: new Date('2023-10-20'), category: ExpenseCategory.PARTS, description: 'Part order from Global Phone Parts', amount: 850.75 },
    { id: 'exp_3', date: new Date('2023-10-15'), category: ExpenseCategory.UTILITIES, description: 'Electricity Bill', amount: 150.25 },
];

export const DUMMY_GIFT_CARDS: GiftCard[] = [
    { id: 'GC-2023-ABCD1234', initialValue: 100, balance: 50, status: 'active', createdAt: new Date('2023-09-01') },
    { id: 'GC-2023-EFGH5678', initialValue: 50, balance: 0, status: 'depleted', createdAt: new Date('2023-08-15') },
];

export const DUMMY_APPOINTMENTS: Appointment[] = [
    {
        id: 'appt_1',
        customer: DUMMY_CUSTOMERS[3], // Diana Miller
        start: new Date(new Date().setDate(new Date().getDate() + 1)),
        end: new Date(new Date(new Date().setDate(new Date().getDate() + 1)).setHours(new Date().getHours() + 1)),
        title: 'iPhone 15 Pro screen replacement',
        status: AppointmentStatus.SCHEDULED,
    },
    {
        id: 'appt_2',
        customer: DUMMY_CUSTOMERS[4], // Ethan Davis
        start: new Date(new Date().setDate(new Date().getDate() - 1)),
        end: new Date(new Date(new Date().setDate(new Date().getDate() - 1)).setHours(new Date().getHours() + 1)),
        title: 'Laptop diagnostic',
        status: AppointmentStatus.COMPLETED,
    }
];

export const MESSAGE_TEMPLATES: MessageTemplate[] = [
    { id: 'tpl_ready', title: 'Device Ready for Pickup', body: 'Hi [Customer Name], your repair for the [Device Model] is complete and ready for pickup. Your total is $[Ticket Total].' },
    { id: 'tpl_quote', title: 'Quote Ready for Approval', body: 'Hi [Customer Name], your quote for the [Device Model] repair is ready. Please log into the customer portal to review and approve.' },
    { id: 'tpl_parts', title: 'Waiting for Parts', body: 'Hi [Customer Name], we are currently waiting for parts to arrive for your [Device Model] repair. We will notify you once the repair is back in progress.' },
];

export const PC_COMPONENTS: PCComponent[] = [
  // CPUs
  { id: 'cpu_1', category: 'CPU', name: 'Intel Core i5-13600K', specs: '14 Cores, 20 Threads, 5.1GHz Turbo', price: 320, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  { id: 'cpu_2', category: 'CPU', name: 'AMD Ryzen 7 7800X3D', specs: '8 Cores, 16 Threads, 5.0GHz Turbo, 3D V-Cache', price: 450, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  // Motherboards
  { id: 'mobo_1', category: 'Motherboard', name: 'MSI PRO Z790-A WIFI', specs: 'DDR5, LGA 1700, ATX', price: 280, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  { id: 'mobo_2', category: 'Motherboard', name: 'Gigabyte B650 AORUS ELITE AX', specs: 'DDR5, AM5, ATX', price: 230, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  // RAM
  { id: 'ram_1', category: 'RAM', name: 'Corsair Vengeance 32GB (2x16GB)', specs: 'DDR5 6000MHz CL30', price: 120, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  // Storage
  { id: 'stor_1', category: 'Storage', name: 'Samsung 980 Pro 2TB', specs: 'NVMe Gen4 M.2 SSD', price: 130, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  // GPU
  { id: 'gpu_1', category: 'GPU', name: 'NVIDIA GeForce RTX 4070 Ti', specs: '12GB GDDR6X', price: 800, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  // Case
  { id: 'case_1', category: 'Case', name: 'Lian Li Lancool 216', specs: 'Mid-Tower ATX, White', price: 110, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
  // PSU
  { id: 'psu_1', category: 'PSU', name: 'Corsair RM850e', specs: '850W, 80+ Gold, Fully Modular', price: 130, imageUrl: 'https://storage.googleapis.com/aifiles/placeholder.png' },
];


// --- WIDGET DATA FROM USER'S EXAMPLE ---

export const WIDGET_CONFIG = {
    repairOptions: {
        "Phone Repairs": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>`,
            deviceOptions: { "Apple": {}, "Samsung": {}, "Google": {}, "OnePlus": {}, "Oppo": {}, "Xiaomi": {}, "Huawei": {}, "Motorola": {}, "Nokia": {}, "Sony": {}, "Other": {} },
        },
        "Tablet Repairs": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 18h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" transform="rotate(90 12 12)"></path></svg>`,
            deviceOptions: { "Apple iPad": {}, "Samsung Galaxy Tab": {}, "Microsoft Surface": {}, "Amazon Fire": {}, "Lenovo": {}, "Other": {} },
        },
        "Laptop & PC Repairs": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>`,
            deviceOptions: { "Apple": {}, "Dell": {}, "HP": {}, "Lenovo": {}, "Asus": {}, "Acer": {}, "Microsoft": {}, "Razer": {}, "MSI": {}, "Samsung": {}, "Custom PC / Other": {} },
        },
        "Gaming Console Repairs": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>`,
            deviceOptions: { "Sony": {}, "Microsoft": {}, "Nintendo": {}, "Valve": {} },
        },
        "Smart Watch Repairs": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`,
            deviceOptions: { "Apple Watch": {}, "Samsung Watch": {}, "Google Watch": {}, "Fitbit": {}, "Garmin": {}, "Other": {} },
        },
        "Drone Repairs": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M3.478 18.408l3.023-1.008a4.5 4.5 0 004.093-4.094l1.008-3.022m0 0l5.038-5.038a2.121 2.121 0 013 3L14.593 9.988m-2.185-2.185l-3.022 1.008a4.5 4.5 0 00-4.094 4.094L4.286 16.92M19.5 4.5l-3 3"></path></svg>`,
            deviceOptions: { "DJI": {}, "Autel": {}, "Parrot": {}, "Skydio": {}, "Other": {} },
        },
         "Onsite or Remote Assistance": {
            icon: `<svg class="w-12 h-12 mb-3 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a3.004 3.004 0 015.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>`,
            isService: true,
            serviceOptions: ["Software Installation", "Network Troubleshooting", "New Device Setup", "Data Backup & Recovery", "General Tech Support & Tutoring", "Printer Setup"]
        }
    }
};

export const DEVICE_DETAILS = {
    "Apple": { models: [ { name: "iPhone 15 Pro", img: "https://www.apple.com/v/iphone-15-pro/c/images/overview/design/design_display_pro__eqj2tf82cwim_large.jpg" }, { name: "iPhone 15", img: "https://www.apple.com/v/iphone-15/a/images/overview/design/design_display__c85e683r0o2y_large.jpg" }, { name: "iPhone 14 Pro", img: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-14-pro-colors.png" }, { name: "iPhone 14", img: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-14-colors.png" }, { name: "iPhone 13", img: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/iphone13/iphone-13-colors.png" }, { name: "iPhone SE (2022)", img: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/2022/iphone-se-3rd-gen-colors.png" }, { name: "iPhone 12", img: "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/iphone/iphone12/iphone-12-colors.png" } ] },
    "Samsung": { models: [ { name: "Galaxy S24 Ultra", img: "https://image-us.samsung.com/us/smartphones/galaxy-s24-ultra/images/galaxy-s24-ultra-highlights-kv.jpg" }, { name: "Galaxy S24", img: "https://image-us.samsung.com/us/smartphones/galaxy-s24/images/galaxy-s24-highlights-kv.jpg" }, { name: "Galaxy Z Fold 5", img: "https://image-us.samsung.com/us/smartphones/galaxy-z-fold5/images/galaxy-z-fold5-highlights-design-display-s.jpg" }, { name: "Galaxy Z Flip 5", img: "https://image-us.samsung.com/us/smartphones/galaxy-z-flip5/images/galaxy-z-flip5-highlights-design-flex-window-s.jpg" }, { name: "Galaxy S23 FE", img: "https://image-us.samsung.com/us/smartphones/galaxy-s23-fe/images/gallery/mint/gallery-01.jpg" }, { name: "Galaxy A54", img: "https://image-us.samsung.com/us/smartphones/galaxy-a54-5g/gallery/awesome-violet/gallery-01.jpg" } ] },
    "Google": { models: [ { name: "Pixel 8 Pro", img: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/HlGquD5.max-1000x1000.jpg" }, { name: "Pixel 8", img: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/KWPrg52.max-1000x1000.jpg" }, { name: "Pixel Fold", img: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/google_pixel_fold_obsidian_case.max-1000x1000.png" }, { name: "Pixel 7a", img: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/7a-charcoal-01_1.max-1000x1000.png" } ] },
    "OnePlus": { models: [ { name: "OnePlus 12", img: "https://oasis.op-mobile.opera.com/op/discover/watch-w501/imgs/kv/kv-2.png" }, { name: "OnePlus Open", img: "https://oasis.op-mobile.opera.com/op/discover/cph2551/imgs/design/phone-kv-2.png" }, { name: "OnePlus 11", img: "https://oasis.op-mobile.opera.com/op/discover/cph2451/imgs/design/phone-kv-2.png" } ] },
    "Xiaomi": { models: [ { name: "Xiaomi 14 Ultra", img: "https://i02.appmifile.com/images/countries/global/xiaomi-14-ultra/specs-header.jpg" }, { name: "Xiaomi 13T Pro", img: "https://i01.appmifile.com/webfile/globalimg/products/pc/xiaomi-13t-pro/specs01.png" }, { name: "Redmi Note 13 Pro", img: "https://i01.appmifile.com/webfile/globalimg/products/pc/redmi-note-13-pro-5g/specs-header.png" } ] },
    "Apple iPad": { models: [ { name: "iPad Pro 12.9", img: "https://www.apple.com/v/ipad-pro/am/images/overview/design/design_display_12_9__fx2g3eeuh02a_large.jpg" }, { name: "iPad Air", img: "https://www.apple.com/v/ipad-air/r/images/overview/design/design_hero_1__d3m92f1we56q_large.jpg" }, { name: "iPad (10th Gen)", img: "https://www.apple.com/v/ipad-10.9/b/images/overview/design/design_hero__c7cac1g67iuu_large.jpg" }, { name: "iPad Mini", img: "https://www.apple.com/v/ipad-mini/r/images/overview/design/design_finish_hero__frdt362040i2_large.jpg" } ] },
    "Samsung Galaxy Tab": { models: [ { name: "Tab S9 Ultra", img: "https://image-us.samsung.com/us/tablets/galaxy-tab-s9-ultra/images/galaxy-tab-s9-ultra-highlights-kv.jpg" }, { name: "Tab S9 FE", img: "https://image-us.samsung.com/us/tablets/galaxy-tab-s9-fe/gallery/gray/01_gallery.jpg" }, { name: "Tab A9+", img: "https://image-us.samsung.com/us/tablets/galaxy-tab-a9-plus/gallery/graphite/01_gallery.jpg" } ] },
    "Microsoft Surface": { models: [ { name: "Surface Pro 9", img: "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RW10p1c?ver=7170" }, { name: "Surface Go 4", img: "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RW1aR0N?ver=c606" }, { name: "Surface Laptop Studio", img: "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RWUq3x?ver=9318" } ] },
    "Dell": { models: [ { name: "XPS 17", img: "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-17-9730/media-gallery/touch-platinum-silver/notebook-xps-17-9730-t-platinum-silver-gallery-1.psd?fmt=png-alpha" }, { name: "XPS 15", img: "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-15-9530/media-gallery/touch-platinum-silver/notebook-xps-15-9530-t-platinum-silver-gallery-1.psd?fmt=png-alpha" }, { name: "Alienware m18", img: "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/alienware-notebooks/alienware-m18-r1/media-gallery/dark-metallic-moon/notebook-alienware-m18-r1-dark-side-of-the-moon-gallery-1.psd?fmt=png-alpha" } ] },
    "HP": { models: [ { name: "Spectre x360", img: "https://m.media-amazon.com/images/I/718Dk3K23LL._AC_SL1500_.jpg" }, { name: "Envy 16", img: "https://m.media-amazon.com/images/I/71mIfgcODdL._AC_SL1500_.jpg" }, { name: "Omen 17", img: "https://m.media-amazon.com/images/I/71PlJ-ejg8L._AC_SL1500_.jpg" } ] },
    "Lenovo": { models: [ { name: "ThinkPad X1 Carbon", img: "https://p4-ofp.static.pub/fes/cms/2023/01/03/h7b8y616j1k51t6p4h0fmn22vj2d17475850.png" }, { name: "Yoga 9i", img: "https://p1-ofp.static.pub/fes/cms/2022/10/18/3ssy1a7a0b8p1536b56658y9tq2w23577784.png" }, { name: "Legion Pro 7i", img: "https://p1-ofp.static.pub/fes/cms/2022/12/12/j55mmv00n2h0y5l372tqx9wlxz2y23877969.png" } ] },
    "Sony": { models: [ { name: "PlayStation 5", img: "https://m.media-amazon.com/images/I/61t4GqA5DML._SL1500_.jpg" }, { name: "PS5 Slim", img: "https://m.media-amazon.com/images/I/61B6pBFG1VL._SL1500_.jpg" }, { name: "PS VR2", img: "https://m.media-amazon.com/images/I/61A3f5q1xLL._SL1500_.jpg" }, { name: "PlayStation 4 Pro", img: "https://m.media-amazon.com/images/I/41GGPRqTZtL._SL1000_.jpg" } ] },
    "Microsoft": { models: [ { name: "Xbox Series X", img: "https://m.media-amazon.com/images/I/61JGKhx+6eL._SL1500_.jpg" }, { name: "Xbox Series S", img: "https://m.media-amazon.com/images/I/71NBQ2a52CL._SL1500_.jpg" }, { name: "Xbox One X", img: "https://m.media-amazon.com/images/I/61ux1cU49GL._SL1500_.jpg" } ] },
    "Nintendo": { models: [ { name: "Switch OLED", img: "https://m.media-amazon.com/images/I/71m5Bzkx48L._SL1500_.jpg" }, { name: "Switch", img: "https://m.media-amazon.com/images/I/61-PblYntsL._SL1500_.jpg" }, { name: "Switch Lite", img: "https://m.media-amazon.com/images/I/71qmF0FHj9L._SL1500_.jpg" } ] },
    "Valve": { models: [ { name: "Steam Deck OLED", img: "https://cdn.akamai.steamstatic.com/steamdeck/images/gallery/oled/steam-deck-oled-1.jpg" }, { name: "Steam Deck LCD", img: "https://cdn.akamai.steamstatic.com/steamdeck/images/gallery/steam-deck-1.jpg" } ] },
    "Apple Watch": { models: [ { name: "Watch Ultra 2", img: "https://www.apple.com/v/apple-watch-ultra-2/c/images/overview/design/design_hero__ebkb7na89fie_large.jpg" }, { name: "Watch Series 9", img: "https://www.apple.com/v/apple-watch-series-9/e/images/overview/design/design_hero__c58lti2llw2y_large.jpg" }, { name: "Watch SE", img: "https://www.apple.com/v/apple-watch-se/n/images/overview/design/design_hero__g5r1hb33s92e_large.jpg" } ] },
    "Samsung Watch": { models: [ { name: "Galaxy Watch 6", img: "https://image-us.samsung.com/us/watches/galaxy-watch6/images/galaxy-watch6-highlights-kv-s.jpg" }, { name: "Galaxy Watch 5 Pro", img: "https://image-us.samsung.com/us/watches/galaxy-watch5-pro/gallery/Gallery_Color_Titanium_1.jpg" } ] },
    "Google Watch": { models: [ { name: "Pixel Watch 2", img: "https://storage.googleapis.com/gweb-uniblog-publish-prod/images/pw2_lifestyle_hero_2.width-1000.height-1000.format-webp.webp" } ] },
    "DJI": { models: [ { name: "Mavic 3 Pro", img: "https://m.media-amazon.com/images/I/71Q0y+8vSQL._AC_SL1500_.jpg" }, { name: "Air 3", img: "https://m.media-amazon.com/images/I/71-4iV-Jq-L._AC_SL1500_.jpg" }, { name: "Mini 4 Pro", img: "https://m.media-amazon.com/images/I/71Xm1QfNE8L._AC_SL1500_.jpg" } ] },
    "Other": { models: [{ name: "Other / Not Listed", img: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Device" }] }
};

export const DEVICE_PARTS = {
    "default": [
        { name: "Screen Assembly", img: "https://www.fixez.com/cdn/shop/products/iphone-x-screen-replacement-1.jpg?v=1675806316", price: 129.99 },
        { name: "Battery", img: "https://images-na.ssl-images-amazon.com/images/I/71maAbaV2mL._AC_SL1500_.jpg", price: 69.99 },
        { name: "Charging Port", img: "https://www.fixez.com/cdn/shop/files/samsung-galaxy-s22-ultra-charging-port-flex-cable-replacement-1.jpg?v=1690462058", price: 59.99 },
        { name: "Back Glass / Housing", img: "https://m.media-amazon.com/images/I/61e0S2y-FIL._AC_SL1500_.jpg", price: 89.99 },
        { name: "Rear Camera", img: "https://www.fixez.com/cdn/shop/products/iphone-14-pro-max-rear-camera-replacement-1.jpg?v=1675806440", price: 99.99 },
        { name: "Front Camera / Sensor", img: "https://www.fixez.com/cdn/shop/products/iphone-13-front-facing-camera-and-sensor-assembly-replacement.jpg?v=1675806385", price: 49.99 },
        { name: "Earpiece Speaker", img: "https://www.fixez.com/cdn/shop/products/iphone-12-pro-earpiece-speaker-replacement-1_1.jpg?v=1675806362", price: 39.99 },
        { name: "Loudspeaker", img: "https://www.fixez.com/cdn/shop/products/iphone-14-loudspeaker-replacement-1.jpg?v=1675806411", price: 39.99 },
        { name: "Part Not Listed", img: "https://placehold.co/400x400/FFFFFF/000000?text=Other+Part", price: 0 }
    ]
};