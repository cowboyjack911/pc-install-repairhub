

import { User as FirebaseUser } from './services/firebaseService';

// Fix: Add Omit type definition for older TypeScript versions.
export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;

export type User = FirebaseUser & { role?: 'Admin' | 'Manager' | 'Technician' };

export enum TicketStatus {
  NEW = 'New',
  IN_PROGRESS = 'In Progress',
  WAITING_for_PARTS = 'Waiting for Parts',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled',
  SAVED = 'Saved',
  WAITING_FOR_ARRIVAL = 'Waiting for Arrival',
  QUOTE_PENDING = 'Quote Pending',
}

export type NotificationPreferences = Record<
  TicketStatus,
  { email: boolean; sms: boolean }
>;


export interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  notificationPreferences?: NotificationPreferences;
  storeCredit?: number;
}
export type ProductCategory = 'Repairs' | 'Unlocking' | 'Products' | 'Miscellaneous' | 'Bill Payment';
export interface Product {
    id: string;
    name: string;
    category: ProductCategory;
    price?: number; // Price might not be fixed for repairs
    cost?: number; // Cost of the product itself for profitability tracking
    // Fix: Changed type from React.FC to React.ElementType to resolve type conflict errors.
    icon: React.ElementType;
}

export interface UsedPart {
  itemId: string;
  name: string;
  sku: string;
  quantityUsed: number;
  cost: number; // The cost of one unit of this part
}

export interface CartItem extends Product {
    cartItemId: string; // Unique ID for this specific item in the cart
    quantity: number;
    unitPrice: number;
    tax: number;
    cost: number; // Total cost of the item (cost * quantity)
    // Repair-specific details
    deviceMake?: string;
    deviceModel?: string;

    imei?: string;
    issue?: string;
    passcode?: string;
    usedParts?: UsedPart[];
    isGiftCard?: boolean; // Flag to identify this item as a gift card sale
    giftCardValue?: number; // The value being loaded onto the gift card
}

export interface ShippingAddress {
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface PaymentDetails {
  method: string;
  amountTendered?: number;
  changeGiven?: number;
  transactionId: string;
  giftCardCode?: string; // Code of the gift card used for payment
  giftCardAmountUsed?: number; // Amount redeemed from the gift card
}

export interface Note {
    id: string;
    content: string;
    createdAt: Date;
}

export interface Ticket {
  id: string;
  customer: Customer;
  items: CartItem[];
  status: TicketStatus;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  totalCost: number;
  createdAt: Date;
  notes: Note[];
  shippingAddress?: ShippingAddress;
  paymentDetails?: PaymentDetails;
  assignedTechnicianId?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  quantity: number;
  cost: number;
  price?: number;
  category?: string;
  reorderPoint?: number;
  lastReceivedDate?: Date;
}

export interface DashboardData {
  kpis: {
    todaysRevenue: number;
    todaysProfit: number;
    pendingRepairs: number;
    completedThisWeek: number;
    totalCustomers: number;
    lowStockItems: number;
  };
  salesLast7Days: { date: string; revenue: number }[];
  recentActivity: Ticket[];
}

export interface BusinessInfo {
  name: string;
  tagline: string;
  logoUrl?: string;
}

export interface DeviceModel {
  id: string;
  name: string;
  imageUrl?: string;
}

export interface Manufacturer {
  id: string;
  name: string;
  models: DeviceModel[];
}

export interface RepairType {
  id: string;
  name: string;
  basePrice: number;
  imageUrl?: string;
}

export interface TaxRule {
  id: string;
  name: string;
  rate: number; // as a percentage, e.g., 5 for 5%
  isEnabled: boolean;
}

export interface TaxSettings {
  baseRate: number; // as a percentage, e.g., 10 for 10%
  rules: TaxRule[];
}

export interface PaymentMethodSettings {
  cash: boolean;
  card: boolean;
  afterpay: boolean;
  square: boolean;
  storeCredit: boolean;
}

export type Discount = {
  type: 'percentage' | 'fixed';
  value: number;
} | null;

export interface Supplier {
  id: string;
  name: string;
  contactPerson?: string;
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
}

export enum POStatus {
    DRAFT = 'Draft',
    ORDERED = 'Ordered',
    PARTIALLY_RECEIVED = 'Partially Received',
    RECEIVED = 'Received',
    CANCELLED = 'Cancelled',
}

export interface POItem {
    itemId: string;
    name: string;
    sku: string;
    quantityOrdered: number;
    quantityReceived: number;
    cost: number;
}

export interface PurchaseOrder {
    id: string;
    supplier: Supplier;
    items: POItem[];
    status: POStatus;
    createdAt: Date;
    totalCost: number;
}

export enum ExpenseCategory {
    RENT = 'Rent',
    UTILITIES = 'Utilities',
    MARKETING = 'Marketing',
    SALARIES = 'Salaries',
    SUPPLIES = 'Supplies',
    PARTS = 'Parts',
    OTHER = 'Other',
}

export interface Expense {
    id: string;
    date: Date;
    category: ExpenseCategory;
    description: string;
    amount: number;
}

export interface GiftCard {
  id: string; // The unique gift card code
  initialValue: number;
  balance: number;
  status: 'active' | 'depleted';
  createdAt: Date;
}

export enum AppointmentStatus {
    SCHEDULED = 'Scheduled',
    COMPLETED = 'Completed',
    CANCELLED = 'Cancelled',
    NO_SHOW = 'No Show',
}

export interface Appointment {
    id: string;
    customer: Customer;
    start: Date;
    end: Date;
    title: string;
    notes?: string;
    status: AppointmentStatus;
}

export interface MessageTemplate {
    id: string;
    title: string;
    body: string;
}

export interface SuggestedPart {
  partName: string;
  sku: string;
  reason: string;
}

export interface DiagnosticResult {
  potentialCauses: string[];
  suggestedParts: SuggestedPart[];
  estimatedDifficulty: string;
}

export interface PCComponent {
  id: string;
  category: 'CPU' | 'Motherboard' | 'RAM' | 'Storage' | 'GPU' | 'Case' | 'PSU';
  name: string;
  specs: string;
  price: number;
  imageUrl: string;
}

export type PCBuildConfiguration = Partial<Record<PCComponent['category'], PCComponent>>;

export interface NavItem {
    id: string;
    label: string;
    icon: React.ElementType;
    view?: string;
    subItems?: NavItem[];
    isNew?: boolean;
    isPrimary?: boolean;
    description?: string;
}