

import React, { useState, useMemo, useEffect } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { CartItem, PaymentMethodSettings, PaymentDetails, Discount, TaxSettings } from './types';
import CloseIcon from './components/icons/CloseIcon';
import { processPayment } from './services/paymentService';

import CashIcon from './components/icons/CashIcon';
import CreditCardIcon from './components/icons/CreditCardIcon';
import AfterpayIcon from './components/icons/AfterpayIcon';
import SquareIcon from './components/icons/SquareIcon';
import StoreCreditIcon from './components/icons/StoreCreditIcon';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  // Fix: Add discount and taxSettings to props.
  discount: Discount;
  taxSettings: TaxSettings;
  paymentMethods: PaymentMethodSettings;
  onProcessPayment: (paymentDetails: PaymentDetails) => void;
}

const paymentOptionsConfig = {
    cash: { name: 'Cash', icon: CashIcon },
    card: { name: 'Card', icon: CreditCardIcon },
    afterpay: { name: 'Afterpay', icon: AfterpayIcon },
    square: { name: 'Square', icon: SquareIcon },
    storeCredit: { name: 'Store Credit', icon: StoreCreditIcon },
};


const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, cart, discount, taxSettings, paymentMethods, onProcessPayment }) => {
    const [selectedMethod, setSelectedMethod] = useState<string | null>(null);
    const [amountTendered, setAmountTendered] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const availableMethods = useMemo(() => {
        return Object.entries(paymentMethods)
            .filter(([, isEnabled]) => isEnabled)
            .map(([key]) => key);
    }, [paymentMethods]);

    // Effect to select the first available method by default when modal opens
    useEffect(() => {
        if (isOpen && availableMethods.length > 0) {
            setSelectedMethod(availableMethods[0]);
        }
    }, [isOpen, availableMethods]);

    // Fix: Calculate total using discount and tax settings.
    const { total } = useMemo(() => {
        const subtotal = cart.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
        const discountAmount = discount
            ? discount.type === 'fixed'
                ? Math.min(discount.value, subtotal)
                : subtotal * (discount.value / 100)
            : 0;
        const taxableAmount = subtotal - discountAmount;
        const totalTaxRate = taxSettings.baseRate + taxSettings.rules.filter(r => r.isEnabled).reduce((sum, r) => sum + r.rate, 0);
        const tax = taxableAmount * (totalTaxRate / 100);
        const calculatedTotal = taxableAmount + tax;
        return { total: calculatedTotal };
    }, [cart, discount, taxSettings]);

    const tenderedValue = parseFloat(amountTendered) || 0;
    const changeDue = selectedMethod === 'cash' && tenderedValue > 0 ? tenderedValue - total : 0;

    const handleProcessClick = async () => {
        if (!selectedMethod) {
            setError("Please select a payment method.");
            return;
        }
        setIsLoading(true);
        setError(null);

        try {
            const response = await processPayment(total, selectedMethod, tenderedValue);
            const paymentDetails: PaymentDetails = {
                method: selectedMethod,
                amountTendered: selectedMethod === 'cash' ? tenderedValue : total,
                changeGiven: changeDue > 0 ? changeDue : 0,
                transactionId: response.transactionId,
            };
            onProcessPayment(paymentDetails);
        } catch (err: any) {
            setError(err.message || "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleClose = () => {
        // Reset state on close
        setAmountTendered('');
        setIsLoading(false);
        setError(null);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
            <div className="bg-dark-panel rounded-2xl shadow-2xl w-full max-w-lg">
                <header className="flex items-center justify-between p-4 border-b border-dark-border">
                    <h2 className="text-xl font-bold text-dark-text-primary">Checkout</h2>
                    <button type="button" onClick={handleClose} className="text-dark-text-tertiary hover:text-white">
                        <CloseIcon className="h-6 w-6" />
                    </button>
                </header>

                <main className="p-6">
                    <div className="bg-dark-bg p-4 rounded-lg text-center mb-6">
                        <p className="text-sm text-dark-text-secondary">Amount Due</p>
                        <p className="text-4xl font-bold text-brand-green tracking-tight">${total.toFixed(2)}</p>
                    </div>

                    <div>
                        <h3 className="text-base font-semibold text-dark-text-primary mb-3">Select Payment Method</h3>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            {availableMethods.map(methodKey => {
                                const config = paymentOptionsConfig[methodKey as keyof typeof paymentOptionsConfig];
                                if (!config) return null;
                                const Icon = config.icon;
                                return (
                                    <button 
                                        key={methodKey}
                                        onClick={() => setSelectedMethod(methodKey)}
                                        className={`p-3 rounded-lg border-2 flex flex-col items-center justify-center transition-all ${selectedMethod === methodKey ? 'bg-brand-green/10 border-brand-green' : 'bg-dark-panel-light border-dark-border hover:border-dark-text-tertiary'}`}
                                    >
                                        <Icon className="h-7 w-7 text-dark-text-primary mb-2" />
                                        <span className="text-sm font-medium text-dark-text-primary">{config.name}</span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                    
                    {selectedMethod === 'cash' && (
                        <div className="mt-6">
                            <label htmlFor="amountTendered" className="block text-sm font-medium text-dark-text-secondary">Amount Tendered</label>
                            <input
                                type="number"
                                id="amountTendered"
                                value={amountTendered}
                                onChange={e => setAmountTendered(e.target.value)}
                                className="mt-1 block w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green text-white"
                                placeholder="0.00"
                                step="0.01"
                            />
                             {changeDue > 0 && (
                                <div className="mt-3 text-center bg-dark-bg p-3 rounded-lg">
                                    <p className="text-sm text-dark-text-secondary">Change Due</p>
                                    <p className="text-2xl font-bold text-dark-text-primary">${changeDue.toFixed(2)}</p>
                                </div>
                            )}
                        </div>
                    )}
                </main>
                
                <footer className="p-4 bg-dark-panel-light/50 rounded-b-2xl">
                     {error && <p className="text-red-400 text-sm text-center mb-3">{error}</p>}
                    <button
                        onClick={handleProcessClick}
                        disabled={isLoading}
                        className="w-full flex items-center justify-center gap-3 px-4 py-3 text-base font-bold text-dark-bg bg-brand-green border border-transparent rounded-md shadow-sm hover:bg-brand-green-darker disabled:bg-gray-500 disabled:cursor-wait"
                    >
                         {isLoading && <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-dark-bg"></div>}
                         <span>{isLoading ? 'Processing...' : `Pay $${total.toFixed(2)}`}</span>
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default CheckoutModal;