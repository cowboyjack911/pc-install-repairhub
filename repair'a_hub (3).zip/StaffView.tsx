














import React, { useState, useMemo, useEffect } from 'react';
// Fix: Import NavItem from types.ts where it is defined.
// FIX: Omit is a built-in type and does not need to be imported.
import { Ticket, TicketStatus, Customer, InventoryItem, DashboardData, BusinessInfo, TaxSettings, PaymentMethodSettings, Supplier, PurchaseOrder, Note, Expense, GiftCard, Appointment, NavItem, CartItem, User, MessageTemplate } from './types';
import TicketManagement from './components/TicketManagement';
import InventoryManagement from './components/InventoryManagement';
import DashboardView from './components/DashboardView';
import { sendNotification } from './services/notificationService';
import AddQuoteModal from './components/AddQuoteModal';
// Fix: Remove NavItem import from here as it is not exported from this module.
import { SIDEBAR_NAV_ITEMS } from './constants/navigation';
import WorkbenchView from './components/WorkbenchView';
import Sidebar from './components/layout/Sidebar';
import POSView from './POSView';
import IntegrationsView from './components/IntegrationsView';
import GeneralSettings from './components/settings/GeneralSettings';
import SettingsPlaceholder from './components/settings/SettingsPlaceholder';
import SettingsView from './components/settings/SettingsView';
import TaxSettingsComponent from './components/settings/TaxSettings';
import PaymentMethodsSettings from './components/settings/PaymentMethodsSettings';
import CustomersView from './components/CustomersView';
import SupplierManagement from './components/settings/SupplierManagement';
import PurchaseOrdersView from './components/PurchaseOrdersView';
import ExpenseManagement from './components/settings/ExpenseManagement';
import ReportsView from './components/reports/ReportsView';
import GiftCardManagement from './components/settings/GiftCardManagement';
import TicketInvoice from './components/printable/TicketInvoice';
import AppointmentsView from './components/appointments/AppointmentsView';
import MessageCustomerModal from './components/tickets/MessageCustomerModal';
import MessagingView from './components/MessagingView';
import UserIcon from './components/icons/UserIcon';
import LogoutIcon from './components/icons/LogoutIcon';
import Bars3Icon from './components/icons/Bars3Icon';
import RepairWidget from './components/RepairWidget';
import EmailNotificationsSettings from './components/settings/EmailNotificationsSettings';
import OrderStatusSettings from './components/settings/OrderStatusSettings';


export type View = 'dashboard' | 'pos' | 'tickets' | 'inventory' | 'settings' | 'workbench' | 'integrations' | 'customers' | 'purchase-orders' | 'reports' | 'appointments';

interface StaffViewProps {
  user: User;
  users: User[];
  onLogout: () => void;
  businessInfo: BusinessInfo;
  onUpdateBusinessInfo: (newInfo: BusinessInfo) => void;
  tickets: Ticket[];
  customers: Customer[];
  inventoryItems: InventoryItem[];
  setTickets: React.Dispatch<React.SetStateAction<Ticket[]>>;
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  setInventoryItems: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
  taxSettings: TaxSettings;
  onUpdateTaxSettings: (settings: TaxSettings) => void;
  paymentMethodSettings: PaymentMethodSettings;
  onUpdatePaymentMethodSettings: (settings: PaymentMethodSettings) => void;
  onAddNewCustomer: (customerData: Omit<Customer, 'id'>) => Customer;
  onUpdateCustomer: (customer: Customer) => void;
  onDeleteCustomer: (customerId: string) => void;
  suppliers: Supplier[];
  onAddSupplier: (supplierData: Omit<Supplier, 'id'>) => void;
  onUpdateSupplier: (supplier: Supplier) => void;
  onDeleteSupplier: (supplierId: string) => void;
  purchaseOrders: PurchaseOrder[];
  onAddPurchaseOrder: (poData: Omit<PurchaseOrder, 'id'>) => void;
  onReceivePOItems: (poId: string, receivedQuantities: Record<string, number>) => void;
  expenses: Expense[];
  onAddExpense: (expenseData: Omit<Expense, 'id'>) => void;
  onUpdateExpense: (expense: Expense) => void;
  onDeleteExpense: (expenseId: string) => void;
  giftCards: GiftCard[];
  onAddGiftCard: (value: number) => void;
  onRedeemGiftCard: (code: string, amountUsed: number) => void;
  onAdjustStock: (itemId: string, newQuantity: number, reason: string) => void;
  appointments: Appointment[];
  onAddAppointment: (appointmentData: Omit<Appointment, 'id'>) => void;
  onUpdateAppointment: (appointment: Appointment) => void;
  onDeleteAppointment: (appointmentId: string) => void;
  messageTemplates: MessageTemplate[];
  onAddMessageTemplate: (templateData: Omit<MessageTemplate, 'id'>) => void;
  onUpdateMessageTemplate: (template: MessageTemplate) => void;
  onDeleteMessageTemplate: (templateId: string) => void;
}

const findNavItemByView = (viewName: string, items: NavItem[]): NavItem | null => {
    for (const item of items) {
        if (item.view === viewName) {
            return item;
        }
        if (item.subItems) {
            const found = findNavItemByView(viewName, item.subItems);
            if (found) {
                return found;
            }
        }
    }
    return null;
};


export default function StaffView({ 
  user, users, onLogout, businessInfo, onUpdateBusinessInfo, tickets, customers, inventoryItems, 
  setTickets, setCustomers, setInventoryItems, taxSettings, onUpdateTaxSettings,
  paymentMethodSettings, onUpdatePaymentMethodSettings,
  onAddNewCustomer, onUpdateCustomer, onDeleteCustomer,
  suppliers, onAddSupplier, onUpdateSupplier, onDeleteSupplier,
  purchaseOrders, onAddPurchaseOrder, onReceivePOItems,
  expenses, onAddExpense, onUpdateExpense, onDeleteExpense,
  giftCards, onAddGiftCard, onRedeemGiftCard, onAdjustStock,
  appointments, onAddAppointment, onUpdateAppointment, onDeleteAppointment,
  messageTemplates, onAddMessageTemplate, onUpdateMessageTemplate, onDeleteMessageTemplate
}: StaffViewProps) {
  const [activeView, setActiveView] = useState<string>('pos');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [quotingTicketId, setQuotingTicketId] = useState<string | null>(null);
  const [printableTicket, setPrintableTicket] = useState<Ticket | null>(null);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [messagingTicket, setMessagingTicket] = useState<Ticket | null>(null);
  const [isRepairWidgetOpen, setIsRepairWidgetOpen] = useState(false);
  

  const technicians = useMemo(() => users.filter(u => u.role === 'Technician'), [users]);

  const sidebarNavItems = useMemo(() => {
    const userRole = user.role || 'Technician';
    if (userRole === 'Admin') {
        return SIDEBAR_NAV_ITEMS;
    }
    if (userRole === 'Manager') {
        return SIDEBAR_NAV_ITEMS.filter(item => item.id !== 'settings' && item.view !== 'integrations');
    }
    // Technician
    const allowedTopLevel = new Set(['pos', 'repairs_group', 'workbench', 'customers_group', 'inventory_group', 'appointments']);
    const technicianNav = SIDEBAR_NAV_ITEMS.filter(item => allowedTopLevel.has(item.id) || allowedTopLevel.has(item.view || ''));
    // Ensure sub-items are also filtered if needed, though in this case they are all allowed for technicians.
    return technicianNav;
  }, [user.role]);


  useEffect(() => {
    if (printableTicket) {
      setTimeout(() => {
        window.print();
        setPrintableTicket(null);
      }, 100); // Small delay to ensure render before print dialog
    }
  }, [printableTicket]);

  const activeNavItem = useMemo(() => findNavItemByView(activeView, SIDEBAR_NAV_ITEMS), [activeView]);

  const handleSidebarNavigate = (view: string) => {
      setActiveView(view);
      setIsSidebarOpen(false);
  };

  const handleOpenQuoteModal = (ticketId: string) => {
    setQuotingTicketId(ticketId);
    setIsQuoteModalOpen(true);
  };

  const handleSaveQuote = (ticketId: string, price: number) => {
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        const subtotal = price;
        const tax = subtotal * 0.1;
        const total = subtotal + tax;
        const updatedTicket = { ...t, status: TicketStatus.QUOTE_PENDING, subtotal, tax, total };
        sendNotification(updatedTicket.customer, updatedTicket.status);
        return updatedTicket;
      }
      return t;
    }));
    setIsQuoteModalOpen(false);
    setQuotingTicketId(null);
  };

 const handleSaveTicket = (newTicket: Ticket) => {
    setTickets(prevTickets => [newTicket, ...prevTickets].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()));
    sendNotification(newTicket.customer, newTicket.status);
    alert("New repair ticket created successfully!");
  };


  const handleCompleteSale = (completedTicket: Ticket) => {
    // Add ticket to state
    setTickets(prevTickets => [completedTicket, ...prevTickets].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()));
    
    // Check for gift card sales
    completedTicket.items.forEach(item => {
        if (item.isGiftCard && item.giftCardValue) {
            onAddGiftCard(item.giftCardValue);
        }
    });

    // Check for gift card redemptions
    if (completedTicket.paymentDetails?.giftCardCode && completedTicket.paymentDetails.giftCardAmountUsed) {
        onRedeemGiftCard(completedTicket.paymentDetails.giftCardCode, completedTicket.paymentDetails.giftCardAmountUsed);
    }
  };

  const handleUpdateTicketStatus = (ticketId: string, status: TicketStatus) => {
    const ticketToUpdate = tickets.find(t => t.id === ticketId);
    if (!ticketToUpdate) return;

    if (ticketToUpdate.status === status) return;

    const performStatusUpdate = () => {
      setTickets(prev => prev.map(t => (t.id === ticketId ? { ...t, status } : t)));
      sendNotification(ticketToUpdate.customer, status);
    };

    if (status === TicketStatus.COMPLETED) {
      let updatedInventory = [...inventoryItems];
      let canComplete = true;

      for (const item of ticketToUpdate.items) {
        if (!item.usedParts) continue;
        for (const part of item.usedParts) {
          const invItem = updatedInventory.find(i => i.id === part.itemId);
          if (!invItem || invItem.quantity < part.quantityUsed) {
            alert(`Cannot complete ticket. Insufficient stock for ${part.name} (SKU: ${part.sku}).\nRequired: ${part.quantityUsed}, In Stock: ${invItem?.quantity || 0}`);
            canComplete = false;
            break;
          }
        }
        if (!canComplete) break;
      }
      
      if (canComplete) {
        for (const item of ticketToUpdate.items) {
          if (!item.usedParts) continue;
          for (const part of item.usedParts) {
            updatedInventory = updatedInventory.map(invItem => 
              invItem.id === part.itemId 
                ? { ...invItem, quantity: invItem.quantity - part.quantityUsed } 
                : invItem
            );
          }
        }
        setInventoryItems(updatedInventory);
        performStatusUpdate();
        alert('Ticket marked as complete and inventory has been updated.');
      }
    } else {
      performStatusUpdate();
    }
  };
  
  const handleAssignTechnician = (ticketId: string, technicianId: string) => {
    setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, assignedTechnicianId: technicianId } : t));
  };
  
  const handleAddNoteToTicket = (ticketId: string, noteContent: string) => {
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        const newNote: Note = {
          id: `note_${crypto.randomUUID()}`,
          content: noteContent,
          createdAt: new Date(),
        };
        return { ...t, notes: [...t.notes, newNote] };
      }
      return t;
    }));
  };

  const handleOpenMessageModal = (ticket: Ticket) => {
    setMessagingTicket(ticket);
    setIsMessageModalOpen(true);
  };

  const handleSendMessage = (ticketId: string, method: 'SMS' | 'Email', message: string) => {
    const ticket = tickets.find(t => t.id === ticketId);
    if (!ticket) return;

    const recipient = method === 'SMS' ? ticket.customer.phone : ticket.customer.email;
    if (!recipient) {
      alert(`Customer does not have a valid ${method} contact.`);
      return;
    }
    
    // Simulate sending
    console.log(`[SIMULATED ${method} to ${recipient}]: ${message}`);

    // Add as a note
    const noteContent = `[SIMULATED ${method} to ${recipient}]: ${message}`;
    handleAddNoteToTicket(ticketId, noteContent);
    setIsMessageModalOpen(false);
  };

  const handleAddInventoryItem = (itemData: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = {
      ...itemData,
      id: `inv_${crypto.randomUUID()}`,
    };
    setInventoryItems(prev => [newItem, ...prev]);
  };

  const handleUpdateInventoryItem = (updatedItem: InventoryItem) => {
    setInventoryItems(prev => prev.map(item => (item.id === updatedItem.id ? updatedItem : item)));
  };

  const handleDeleteInventoryItem = (itemId: string) => {
    if(window.confirm('Are you sure you want to delete this item?')) {
      setInventoryItems(prev => prev.filter(item => item.id !== itemId));
    }
  };
  
  const handleBulkImport = (newItems: Omit<InventoryItem, 'id'>[]) => {
    const itemsWithIds = newItems.map(item => ({
      ...item,
      id: `inv_${crypto.randomUUID()}`
    }));
    setInventoryItems(prev => [...itemsWithIds, ...prev]);
    alert(`${itemsWithIds.length} items have been imported successfully.`);
  };

  const dashboardData = useMemo<DashboardData>(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(today.getDate() - 7);

    const todaysCompletedTickets = tickets.filter(
      t => t.status === TicketStatus.COMPLETED && new Date(t.createdAt).getTime() >= today.getTime()
    );

    const todaysRevenue = todaysCompletedTickets.reduce((sum, t) => sum + t.total, 0);
    const todaysCost = todaysCompletedTickets.reduce((sum, t) => sum + t.totalCost, 0);
    const todaysTax = todaysCompletedTickets.reduce((sum, t) => sum + t.tax, 0);
    const todaysProfit = todaysRevenue - todaysCost - todaysTax;

    const pendingRepairs = tickets.filter(t => [TicketStatus.NEW, TicketStatus.IN_PROGRESS, TicketStatus.WAITING_for_PARTS, TicketStatus.WAITING_FOR_ARRIVAL, TicketStatus.QUOTE_PENDING].includes(t.status)).length;

    const completedThisWeek = tickets.filter(t => t.status === TicketStatus.COMPLETED && t.createdAt >= sevenDaysAgo).length;
    
    const lowStockItems = inventoryItems.filter(item => item.quantity <= (item.reorderPoint || 0)).length;

    const salesLast7Days = Array.from({ length: 7 }).map((_, i) => {
        const date = new Date();
        date.setDate(today.getDate() - i);
        const revenue = tickets
            .filter(t => {
                const ticketDate = new Date(t.createdAt);
                return t.status === TicketStatus.COMPLETED &&
                       ticketDate.getFullYear() === date.getFullYear() &&
                       ticketDate.getMonth() === date.getMonth() &&
                       ticketDate.getDate() === date.getDate();
            })
            .reduce((sum, t) => sum + t.total, 0);
        return { date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), revenue };
    }).reverse();

    return {
      kpis: {
        todaysRevenue,
        todaysProfit,
        pendingRepairs,
        completedThisWeek,
        totalCustomers: customers.length,
        lowStockItems,
      },
      salesLast7Days,
      recentActivity: tickets.slice(0, 5),
    };
  }, [tickets, customers, inventoryItems]);
  
  const renderContent = () => {
    switch (activeView) {
      // Main Views
      case 'dashboard':
        return <DashboardView data={dashboardData} />;
      case 'pos':
        return <POSView 
            onSaveTicket={handleSaveTicket}
            onCompleteSale={handleCompleteSale}
            customers={customers}
            tickets={tickets}
            onAddNewCustomer={onAddNewCustomer}
            inventoryItems={inventoryItems}
            paymentMethodSettings={paymentMethodSettings}
            taxSettings={taxSettings}
            onUpdateCustomer={onUpdateCustomer}
            giftCards={giftCards}
            onPrintTicket={setPrintableTicket}
          />;
      case 'tickets':
        return <TicketManagement
            tickets={tickets}
            onUpdateStatus={handleUpdateTicketStatus}
            onAddQuote={handleOpenQuoteModal}
            onAddTicket={() => setIsRepairWidgetOpen(true)}
            onAddNote={handleAddNoteToTicket}
            onPrintTicket={setPrintableTicket}
            onSendMessage={handleOpenMessageModal}
            user={user}
            technicians={technicians}
            onAssignTechnician={handleAssignTechnician}
          />;
      case 'customers':
        return <CustomersView
            customers={customers}
            tickets={tickets}
            onAddNewCustomer={onAddNewCustomer}
            onUpdateCustomer={onUpdateCustomer}
            onDeleteCustomer={onDeleteCustomer}
          />;
      case 'inventory':
        return <InventoryManagement 
            items={inventoryItems}
            onAddItem={handleAddInventoryItem}
            onUpdateItem={handleUpdateInventoryItem}
            onDeleteItem={handleDeleteInventoryItem}
            onBulkImport={handleBulkImport}
            onAdjustStock={onAdjustStock}
          />;
      case 'purchase-orders':
        return <PurchaseOrdersView 
          purchaseOrders={purchaseOrders}
          suppliers={suppliers}
          inventoryItems={inventoryItems}
          onAddPurchaseOrder={onAddPurchaseOrder}
          onReceiveItems={onReceivePOItems}
        />;
      case 'reports':
        return <ReportsView tickets={tickets} expenses={expenses} users={users} inventoryItems={inventoryItems} customers={customers}/>;
      case 'appointments':
        return <AppointmentsView
            appointments={appointments}
            customers={customers}
            onAddAppointment={onAddAppointment}
            onUpdateAppointment={onUpdateAppointment}
            onDeleteAppointment={onDeleteAppointment}
        />;
      case 'workbench':
        return <WorkbenchView
            tickets={tickets}
            onUpdateStatus={handleUpdateTicketStatus}
            onAddQuote={handleOpenQuoteModal}
            onAddNote={handleAddNoteToTicket}
            onPrintTicket={setPrintableTicket}
            onSendMessage={handleOpenMessageModal}
            user={user}
            technicians={technicians}
            onAssignTechnician={handleAssignTechnician}
        />;
      case 'messaging':
        return <MessagingView />;
      
      // Standalone pages that were previously under settings
      case 'integrations':
        return <IntegrationsView />;

      // The new top-level settings page
      case 'settings':
        return <SettingsView onNavigate={setActiveView} />;

      // Specific Settings Pages that are built
      case 'settings.general':
        return <GeneralSettings businessInfo={businessInfo} onUpdate={onUpdateBusinessInfo} />;
      case 'settings.tax':
        return <TaxSettingsComponent settings={taxSettings} onUpdate={onUpdateTaxSettings} />;
      case 'settings.payment':
        return <PaymentMethodsSettings settings={paymentMethodSettings} onUpdate={onUpdatePaymentMethodSettings} />;
      case 'settings.suppliers':
        return <SupplierManagement 
          suppliers={suppliers} 
          onAdd={onAddSupplier} 
          onUpdate={onUpdateSupplier} 
          onDelete={onDeleteSupplier} 
        />;
      case 'settings.expense':
        return <ExpenseManagement 
          expenses={expenses}
          onAdd={onAddExpense}
          onUpdate={onUpdateExpense}
          onDelete={onDeleteExpense}
        />;
       case 'settings.gift_cards':
        return <GiftCardManagement giftCards={giftCards} />;
      case 'settings.email':
        return <EmailNotificationsSettings 
            templates={messageTemplates}
            onAdd={onAddMessageTemplate}
            onUpdate={onUpdateMessageTemplate}
            onDelete={onDeleteMessageTemplate}
        />;
      case 'settings.status.ticket':
        return <OrderStatusSettings />;

      // All other settings pages will get the placeholder for now.
      default:
        // This regex check will catch all other 'settings.x.y' views
        if (activeView && activeView.startsWith('settings.')) {
          return <SettingsPlaceholder />;
        }
        // Fallback for any unknown view
        return <DashboardView data={dashboardData} />;
    }
  };

  if (printableTicket) {
    return (
      <div id="printable-invoice">
        <TicketInvoice ticket={printableTicket} businessInfo={businessInfo} />
      </div>
    );
  }

  return (
    <>
      <div className="flex h-screen bg-dark-bg text-dark-text-primary font-sans">
        {/* Sidebar Overlay */}
        {isSidebarOpen && (
            <div 
                className="fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity"
                onClick={() => setIsSidebarOpen(false)}
            ></div>
        )}

        {/* Sidebar */}
        <div className={`fixed top-0 left-0 h-full z-40 transition-transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
            <Sidebar 
                businessInfo={businessInfo}
                activeItemId={activeView}
                onNavigate={handleSidebarNavigate}
                onClose={() => setIsSidebarOpen(false)}
                navItems={sidebarNavItems}
            />
        </div>
        
        <div className="flex-1 flex flex-col overflow-hidden w-full">
            <header className="flex-shrink-0 bg-dark-panel h-16 flex items-center justify-between px-4 sm:px-6 lg:px-8 border-b border-dark-border">
                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setIsSidebarOpen(true)} 
                        className="p-2 -ml-2 rounded-md text-dark-text-tertiary hover:text-white hover:bg-dark-panel-light"
                        aria-label="Open menu"
                    >
                        <Bars3Icon className="w-6 h-6" />
                    </button>
                    <h1 className="text-2xl font-bold text-gray-100">{activeNavItem?.label || 'Point of Sale'}</h1>
                </div>
                <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2 p-2 rounded-md">
                       <UserIcon className="w-6 h-6 text-dark-text-secondary" />
                       <span className="text-sm font-medium text-dark-text-primary hidden sm:block">{user.displayName} ({user.role})</span>
                    </div>
                    <button 
                      onClick={onLogout} 
                      className="p-2 rounded-full text-dark-text-tertiary hover:text-white hover:bg-dark-panel-light"
                      aria-label="Log Out"
                    >
                      <LogoutIcon className="h-6 w-6" />
                    </button>
                </div>
            </header>
            <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
                {renderContent()}
            </main>
        </div>
    </div>
    <AddQuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        onSave={handleSaveQuote}
        ticketId={quotingTicketId}
    />
    <RepairWidget
      isOpen={isRepairWidgetOpen}
      onClose={() => setIsRepairWidgetOpen(false)}
      onSave={handleSaveTicket}
      customers={customers}
      onAddNewCustomer={onAddNewCustomer}
      inventoryItems={inventoryItems}
    />
    <MessageCustomerModal
        isOpen={isMessageModalOpen}
        onClose={() => setIsMessageModalOpen(false)}
        ticket={messagingTicket}
        onSend={handleSendMessage}
    />
    </>
  );
}