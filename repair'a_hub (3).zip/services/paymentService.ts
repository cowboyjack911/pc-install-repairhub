import { CartItem } from '../types';

export const processPayment = (
  total: number, 
  method: string, 
  amountTendered?: number
): Promise<{ success: boolean; transactionId: string; message: string }> => {
  console.log(`Processing payment of $${total.toFixed(2)} via ${method}`);
  
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (method === 'cash' && amountTendered && amountTendered < total) {
        reject({
          success: false,
          transactionId: '',
          message: 'Insufficient cash tendered.',
        });
      } else {
        resolve({
          success: true,
          transactionId: `txn_${crypto.randomUUID()}`,
          message: 'Payment processed successfully.',
        });
      }
    }, 1500); // Simulate network delay
  });
};
