import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  updateProfile, 
  signInWithEmailAndPassword, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  type User
} from "firebase/auth";

// Export the User type for other modules.
export type { User };


// =================================================================================
// IMPORTANT: FIREBASE CONFIGURATION
// You must create a Firebase project and replace the placeholder values below.
// 1. Go to the Firebase console: https://console.firebase.google.com/
// 2. Create a new project or select an existing one.
// 3. Go to Project Settings (gear icon) > General tab.
// 4. In the "Your apps" section, click the web icon (</>) to add a web app.
// 5. Follow the steps, and Firebase will provide you with a configuration object.
// 6. Copy the values from that object into the firebaseConfig below.
// These are example values.
// =================================================================================
const firebaseConfig = {
  apiKey: "AIzaSyCV_4iSJf7a-3s5f4Gg7h8j9k0l-1mN2oP",
  authDomain: "main-branch-32885.firebaseapp.com",
  projectId: "main-branch-32885",
  storageBucket: "main-branch-32885.appspot.com",
  messagingSenderId: "444284943928",
  appId: "1:444284943928:web:e924053b941544252f95c4",
  measurementId: "G-G593035D1E"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

// Sign up with email and password
export const signUpWithEmail = async (name: string, email: string, password: string): Promise<User> => {
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        // Update profile with the name
        await updateProfile(userCredential.user, { displayName: name });
        return userCredential.user;
    } catch (error: any) {
        // Handle Firebase error codes for better user feedback
        if (error.code === 'auth/email-already-in-use') {
            throw new Error('This email address is already in use.');
        }
        throw new Error(error.message);
    }
};

// Sign in with email and password
export const signInWithEmail = async (email: string, password: string): Promise<User> => {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return userCredential.user;
    } catch (error: any) {
        if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
            throw new Error('Invalid email or password.');
        }
        throw new Error(error.message);
    }
};

// Sign in with Google
export const signInWithGoogle = async (): Promise<User> => {
    try {
        const result = await signInWithPopup(auth, googleProvider);
        return result.user;
    } catch (error: any) {
        // Handle common popup errors
        if (error.code === 'auth/popup-closed-by-user') {
            throw new Error('Sign-in process was cancelled.');
        }
        throw new Error(error.message);
    }
};

// Sign out
export const signOutUser = async (): Promise<void> => {
    try {
        await signOut(auth);
    } catch (error: any) {
        throw new Error(error.message);
    }
};

// Auth state listener
export const onAuthStateChangedWrapper = (callback: (user: User | null) => void) => {
    return onAuthStateChanged(auth, callback);
};
