import { Customer, TicketStatus } from '../types';

export const sendNotification = (customer: Customer, status: TicketStatus) => {
  if (!customer.notificationPreferences) {
    console.log(`Notification check for ${customer.name}: No preferences set.`);
    return;
  }

  const prefs = customer.notificationPreferences[status];
  if (!prefs) return;

  const message = `Hi ${customer.name.split(' ')[0]}, your repair ticket status has been updated to: ${status}.`;

  if (prefs.email && customer.email) {
    console.log(`[SIMULATED EMAIL]
TO: ${customer.email}
SUBJECT: Your Repair Status Update
---
${message}`);
  }

  if (prefs.sms && customer.phone) {
    console.log(`[SIMULATED SMS]
TO: ${customer.phone}
---
${message}`);
  }
};
