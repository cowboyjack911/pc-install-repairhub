

import React, { useState, useMemo } from 'react';
// FIX: Omit is a built-in type and does not need to be imported.
import { Product, Manufacturer, CartItem, InventoryItem, ProductCategory } from '../types';
import { PRODUCTS, MANUFACTURERS_BY_CATEGORY, POS_CATEGORIES } from '../constants';
import ItemGrid from './ItemGrid';
import SearchIcon from './icons/SearchIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';
import BarcodeIcon from './icons/BarcodeIcon';

// FIX: Removed unused `onAddRepairToCart` prop from interface.
interface BookingViewProps {
    quickAddProducts: Product[];
    onProductAdd: (product: Product) => void;
    inventoryItems: InventoryItem[];
    onSaveTicket: () => void;
    onCheckout: () => void;
    onClearCart: () => void;
}

const BookingView: React.FC<BookingViewProps> = ({ 
    quickAddProducts, onProductAdd, 
    inventoryItems, onSaveTicket, onCheckout, onClearCart
}) => {
    const [activeCategory, setActiveCategory] = useState<ProductCategory>('Repairs');
    const [breadcrumbs, setBreadcrumbs] = useState<string[]>([]);
    
    const handleCategoryClick = (category: ProductCategory) => {
        setActiveCategory(category);
        setBreadcrumbs([]);
    }

    const itemsToShow = useMemo(() => {
        if (activeCategory === 'Repairs') {
            return PRODUCTS;
        }
        return quickAddProducts.filter(p => p.category === activeCategory);
    }, [activeCategory]);
    
    return (
        <div className="p-4 h-full flex flex-col">
            {/* Search Bar */}
            <div className="flex gap-2 items-center mb-4 flex-shrink-0">
                <div className="relative flex-grow">
                    <SearchIcon className="h-5 w-5 text-dark-text-tertiary absolute left-3 top-1/2 -translate-y-1/2" />
                    {/* Barcode scanners often act as a keyboard. The input is ready for scanner input. */}
                    <input 
                        placeholder="Enter item name, SKU or scan barcode"
                        className="w-full bg-dark-bg border-dark-border rounded-md pl-10 pr-10 py-2.5 text-sm focus:ring-brand-green focus:border-brand-green"
                    />
                    <BarcodeIcon className="h-6 w-6 text-dark-text-tertiary absolute right-3 top-1/2 -translate-y-1/2" />
                </div>
                <button className="bg-brand-teal text-white font-semibold px-4 py-2.5 rounded-md text-sm hover:bg-teal-700 transition-colors">Advance Search</button>
                <select className="bg-dark-bg border-dark-border rounded-md text-sm py-2.5 focus:ring-brand-green focus:border-brand-green">
                    <option>All</option>
                </select>
            </div>

            {/* Category Tabs */}
            <div className="flex border-b border-dark-border mb-4 flex-shrink-0">
                 {POS_CATEGORIES.map(cat => (
                     <button key={cat.id} onClick={() => handleCategoryClick(cat.id)} className={`px-4 py-2 text-sm font-semibold transition-colors ${activeCategory === cat.id ? 'text-brand-teal border-b-2 border-brand-teal' : 'text-dark-text-secondary hover:text-white'}`}>
                        {cat.label}
                     </button>
                 ))}
            </div>
            
            {/* Breadcrumbs */}
            <div className="flex items-center gap-1 text-sm text-dark-text-secondary mb-4 flex-shrink-0">
                <button className="hover:text-white">{activeCategory}</button>
                {breadcrumbs.map((crumb, index) => (
                    <React.Fragment key={index}>
                        <ChevronRightIcon className="w-4 h-4" />
                        <button className="hover:text-white">{crumb}</button>
                    </React.Fragment>
                ))}
            </div>

            {/* Item Grid (scrollable) */}
            <div className="flex-grow overflow-y-auto -mr-4 pr-4">
                <ItemGrid items={itemsToShow} onItemSelect={onProductAdd} />
            </div>

            {/* Footer Actions */}
            <div className="pt-4 mt-auto border-t border-dark-border grid grid-cols-3 gap-3 flex-shrink-0">
                <div className="col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <button className="bg-dark-panel-light text-dark-text-primary text-sm font-semibold p-3 rounded-md hover:bg-dark-border transition-colors">View Tickets</button>
                    <button className="bg-dark-panel-light text-dark-text-primary text-sm font-semibold p-3 rounded-md hover:bg-dark-border transition-colors">View Invoices</button>
                    <button className="bg-dark-panel-light text-dark-text-primary text-sm font-semibold p-3 rounded-md hover:bg-dark-border transition-colors">Create Estimate</button>
                    <button className="bg-dark-panel-light text-dark-text-primary text-sm font-semibold p-3 rounded-md hover:bg-dark-border transition-colors">Warranty Claim</button>
                    <button className="bg-dark-panel-light text-dark-text-primary text-sm font-semibold p-3 rounded-md hover:bg-dark-border transition-colors">+ More Actions</button>
                    <button onClick={onClearCart} className="bg-red-500/20 text-red-400 text-sm font-semibold p-3 rounded-md hover:bg-red-500/30 transition-colors">Cancel</button>
                </div>
                <div className="col-span-1 flex flex-col gap-3">
                     <button onClick={onSaveTicket} className="w-full h-full bg-dark-accent-blue text-white font-bold rounded-md hover:bg-blue-700 transition-colors">Create Ticket</button>
                     <button onClick={onCheckout} className="w-full h-full bg-brand-teal text-white font-bold rounded-md hover:bg-teal-700 transition-colors">Checkout</button>
                </div>
            </div>
        </div>
    );
};

export default BookingView;