import React, { useState } from 'react';
import { BusinessInfo } from './types';
import Logo from './components/Logo';
import { signInWithEmail, signUpWithEmail, signInWithGoogle } from './services/firebaseService';
import GoogleIcon from './components/icons/GoogleIcon';

interface LoginViewProps {
  businessInfo: BusinessInfo;
}

const LoginView: React.FC<LoginViewProps> = ({ businessInfo }) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (activeTab === 'signin') {
        await signInWithEmail(email, password);
      } else {
        await signUpWithEmail(name, email, password);
      }
      // onAuthStateChanged in App.tsx will handle the redirect
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await signInWithGoogle();
    } catch (err: any) {
       setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg text-dark-text-primary flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <Logo businessInfo={businessInfo} />
        </div>
        
        <div className="bg-dark-panel p-6 rounded-lg shadow-2xl">
          <div className="flex border-b border-dark-border mb-6">
            <button
              onClick={() => setActiveTab('signin')}
              className={`w-1/2 py-3 text-sm font-bold transition-colors ${activeTab === 'signin' ? 'text-brand-green border-b-2 border-brand-green' : 'text-dark-text-tertiary hover:text-white'}`}
            >
              Sign In
            </button>
            <button
              onClick={() => setActiveTab('signup')}
              className={`w-1/2 py-3 text-sm font-bold transition-colors ${activeTab === 'signup' ? 'text-brand-green border-b-2 border-brand-green' : 'text-dark-text-tertiary hover:text-white'}`}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleFormSubmit} className="space-y-4">
            {activeTab === 'signup' && (
              <div>
                <label htmlFor="name" className="sr-only">Name</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Full Name"
                  className="w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green"
                  required
                />
              </div>
            )}
            <div>
              <label htmlFor="email" className="sr-only">Email</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address"
                className="w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green"
                required
              />
            </div>
            <div>
              <label htmlFor="password" aria-label="Password"></label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full bg-dark-bg border-dark-border rounded-md shadow-sm focus:border-brand-green focus:ring-brand-green"
                required
                minLength={6}
              />
            </div>

            {error && <p className="text-red-400 text-sm text-center">{error}</p>}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-bold text-dark-bg bg-brand-green hover:bg-brand-green-darker focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-panel focus:ring-brand-green disabled:bg-gray-500 disabled:cursor-wait"
            >
              {isLoading ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-dark-bg"></div> : (activeTab === 'signin' ? 'Sign In' : 'Create Account')}
            </button>
          </form>

          <div className="mt-6 relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-dark-border" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-dark-panel text-dark-text-tertiary">Or continue with</span>
            </div>
          </div>

          <div className="mt-6">
            <button
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full inline-flex justify-center items-center py-2.5 px-4 border border-dark-border rounded-md shadow-sm bg-dark-panel-light text-sm font-medium text-white hover:bg-dark-border focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-panel focus:ring-brand-green"
            >
              <GoogleIcon className="w-5 h-5 mr-3" />
              Sign in with Google
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginView;