

import { NavItem } from '../types';

// Main Navigation Icons
import HomeIcon from '../components/icons/HomeIcon';
import PointOfSaleIcon from '../components/icons/PointOfSaleIcon';
import TicketIcon from '../components/icons/TicketIcon';
import ArchiveBoxIcon from '../components/icons/ArchiveBoxIcon';
import WrenchScrewdriverIcon from '../components/icons/WrenchScrewdriverIcon';
import ShoppingCartIcon from '../components/icons/ShoppingCartIcon';
import ChartPieIcon from '../components/icons/ChartPieIcon';
import CalendarDaysIcon from '../components/icons/CalendarDaysIcon';
import ChatBubbleLeftRightIcon from '../components/icons/ChatBubbleLeftRightIcon';

// Settings Icons
import CogIcon from '../components/icons/CogIcon';
import UsersIcon from '../components/icons/UsersIcon';
import UserCircleIcon from '../components/icons/UserCircleIcon';
import BuildingStoreIcon from '../components/icons/BuildingStoreIcon';
import DevicesIcon from '../components/icons/DevicesIcon';
import PlugConnectedIcon from '../components/icons/PlugConnectedIcon';
import MailBoltIcon from '../components/icons/MailBoltIcon';
import Receipt2Icon from '../components/icons/Receipt2Icon';
import ToolIcon from '../components/icons/ToolIcon';
import CashIcon from '../components/icons/CashIcon';
import TaxIcon from '../components/icons/TaxIcon';
import CashRegisterIcon from '../components/icons/CashRegisterIcon';
import MessagesIcon from '../components/icons/MessagesIcon';
import ReceiptTaxIcon from '../components/icons/ReceiptTaxIcon';
import TruckDeliveryIcon from '../components/icons/TruckDeliveryIcon';
import PackageIcon from '../components/icons/PackageIcon';
import CreditCardIcon from '../components/icons/CreditCardIcon';
import GiftCardIcon from '../components/icons/GiftCardIcon';

export const SIDEBAR_NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: HomeIcon, view: 'dashboard' },
  { id: 'pos', label: 'Point of Sale', icon: PointOfSaleIcon, view: 'pos' },
  {
    id: 'repairs_group',
    label: 'Repairs',
    icon: WrenchScrewdriverIcon,
    subItems: [
        { id: 'tickets', label: 'Manage Tickets', icon: TicketIcon, view: 'tickets' },
        { id: 'workbench', label: 'Workbench', icon: WrenchScrewdriverIcon, view: 'workbench' },
        { id: 'appointments', label: 'Appointments', icon: CalendarDaysIcon, view: 'appointments', isNew: true },
    ]
  },
  {
    id: 'inventory_group',
    label: 'Inventory',
    icon: ArchiveBoxIcon,
    subItems: [
        { id: 'inventory', label: 'Manage Inventory', icon: ArchiveBoxIcon, view: 'inventory' },
        { id: 'purchase-orders', label: 'Purchase Orders', icon: ShoppingCartIcon, view: 'purchase-orders' },
    ]
  },
  {
    id: 'customers_group',
    label: 'Customers',
    icon: UsersIcon,
    subItems: [
        { id: 'customers', label: 'Manage Customers', icon: UsersIcon, view: 'customers' },
    ]
  },
  {
    id: 'reports_group',
    label: 'Reports',
    icon: ChartPieIcon,
    subItems: [
        { id: 'reports', label: 'View Reports', icon: ChartPieIcon, view: 'reports' },
    ]
  },
  {
    id: 'expense_group',
    label: 'Expense',
    icon: CashIcon,
    subItems: [
        { id: 'expense_management', label: 'Manage Expense', icon: CashIcon, view: 'settings.expense' },
    ]
  },
  { id: 'messaging', label: 'Messaging', icon: ChatBubbleLeftRightIcon, view: 'messaging', isNew: true },
  { id: 'integrations', label: 'Integrations', icon: PlugConnectedIcon, view: 'integrations' },
  {
    id: 'settings',
    label: 'Settings',
    icon: CogIcon,
    view: 'settings',
    subItems: [
        {
            id: 'your_profile',
            label: 'Your profile',
            icon: UserCircleIcon,
            view: 'settings.profile.update',
            description: 'Manage your personal account details and password.',
        },
        {
            id: 'store_settings',
            label: 'Store settings',
            icon: BuildingStoreIcon,
            view: 'settings.general',
            description: 'Update your business name, logo, and contact info.',
        },
        {
            id: 'hardware_settings',
            label: 'Hardware settings',
            icon: DevicesIcon,
            view: 'settings.hardware.qz',
            description: 'Configure printers, cash drawers, and other peripherals.',
        },
        { 
            id: 'mail_in', 
            label: 'Mail-in', 
            icon: MailBoltIcon, 
            view: 'settings.mailin',
            description: 'Configure settings for mail-in repairs and shipping.'
        },
        { 
            id: 'suggestive_alerts', 
            label: 'Suggestive sale alerts', 
            icon: Receipt2Icon, 
            view: 'settings.alerts', 
            isNew: true,
            description: 'Set up prompts for upselling accessories and services.'
        },
        {
            id: 'module_config',
            label: 'Module configuration',
            icon: ToolIcon,
            view: 'settings.config.pos',
            description: 'Enable or disable specific features and modules.'
        },
        { 
            id: 'tax_config', 
            label: 'Tax configuration', 
            icon: TaxIcon, 
            view: 'settings.tax',
            description: 'Set up tax rates and rules for your location.'
        },
        {
            id: 'gift_cards',
            label: 'Gift Cards',
            icon: GiftCardIcon,
            view: 'settings.gift_cards',
            description: 'Manage and track issued gift cards.',
        },
        { 
            id: 'cash_register', 
            label: 'Cash register', 
            icon: CashRegisterIcon, 
            view: 'settings.cash_register',
            description: 'Manage cash register settings and end-of-day reports.'
        },
        { 
            id: 'email_notifications', 
            label: 'Email & notifications', 
            icon: MessagesIcon, 
            view: 'settings.email',
            description: 'Customize email templates and notification triggers.'
        },
        { 
            id: 'vat_margin', 
            label: 'VAT margin', 
            icon: ReceiptTaxIcon, 
            view: 'settings.vat',
            description: 'Configure VAT margin schemes for applicable items.'
        },
        { 
            id: 'suppliers', 
            label: 'Suppliers', 
            icon: TruckDeliveryIcon, 
            view: 'settings.suppliers',
            description: 'Manage your parts and product supplier information.'
        },
        {
            id: 'orders_status',
            label: 'Orders status',
            icon: PackageIcon,
            view: 'settings.status.ticket',
            description: 'Customize ticket and order status labels and workflows.'
        },
        { 
            id: 'payment_methods', 
            label: 'Payment methods', 
            icon: CreditCardIcon, 
            view: 'settings.payment',
            description: 'Configure accepted payment types like cash, card, etc.'
        },
    ]
  },
];